<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/event.php';
include_once '../../objects/event_detail.php';

$database = new Database();
$db = $database->getConnection();
 
$event = new Event($db);
$event_detail = new EventDetail($db);
$data = json_decode(file_get_contents("php://input"));

$event->id = $data->id;
$event_detail->event_id = $data->id;

$event->getOneEvent();

$event_details = array();

$stmt = $event_detail->getEventDetail();
$num = $stmt->rowCount();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
		$d=array(
            "description" => $description,
            "target" => number_format($target),
            "actual" => number_format($actual)
        );
        array_push($event_details, $d);
    }
}

$p = array(    
    "id" => $event->id,
    "name" => $event->name,
    "voucher_no" => $event->voucher_no,
    "date" => $event->date,
    "done" => $event->done,
    "event_details" => $event_details
);

echo json_encode($p);

?>