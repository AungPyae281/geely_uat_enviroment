<?php
class EventDetail{ 
	private $conn;
	private $table_name = "event_detail";
 
    public $id;	
	public $event_id;
	public $description;
	public $target;
	public $actual;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET event_id=:event_id, description=:description, target=:target, actual=:actual";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":event_id", $this->event_id);
		$stmt->bindParam(":description", $this->description); 
		$stmt->bindParam(":target", $this->target);
		$stmt->bindParam(":actual", $this->actual);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE event_id=:event_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":event_id", $this->event_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getEventDetail(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE event_id=:event_id";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":event_id", $this->event_id);
		$stmt->execute();
		return $stmt;
	}

	function getOneExpense(){
		$query = "SELECT * FROM " . $this->table_name . " where event_id=:event_id";
		$stmt = $this->conn->prepare( $query );
		if($this->event_id) $stmt->bindParam(":event_id", $this->event_id);
		$stmt->execute();
		return $stmt;
	}

	function updateFromLeadEntry(){
		$condition = "";

		if($this->description){
			$condition .= " `actual` =`actual`+1";
		}

		$query = "UPDATE " . $this->table_name . " SET " . $condition .  " WHERE `event_id`=:event_id AND description=:description ";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":event_id", $this->event_id);
        $stmt->bindParam(":description", $this->description);

		if($stmt->execute()){
			return true;
		}else{
			return false;
		}
	}

	function updateAttendanceFromLeadEntry(){
		$query = "UPDATE " . $this->table_name . " SET  `actual` =`actual`+1 WHERE `event_id`=:event_id AND description='Number of Attendance (or) Walk in'";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":event_id", $this->event_id);

		if($stmt->execute()){
			return true;
		}else{
			return false;
		}
	}

	function updateTestDriveCount(){
		$query = "UPDATE " . $this->table_name . " SET  `actual` =`actual`+1 WHERE `event_id`=:event_id AND description='Number of test drive'";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":event_id", $this->event_id);

		if($stmt->execute()){
			return true;
		}else{
			return false;
		}
	}
}
