<?php
class MCategory{
    // database connection and table name
	private $conn;
	private $table_name = "m_category";

    // object properties
    public $id;	
	public $category;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY category";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `category` = :category LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->category = htmlspecialchars(strip_tags($this->category)); 
		$stmt->bindParam(":category", $this->category); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$this->id = htmlspecialchars(strip_tags($this->id));
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET category=:category"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":category", $this->category); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
	
}
