<?php
class MStockIn{

    private $conn;
    private $table_name = "m_stock_in";
    //field list start
    public $id; 
    public $stock_in_date;  
    public $store;  
    public $stock_in_by;
    public $stock_in_receive_by;
    public $item_id;
    public $item_name;  
    public $capital_price; 
    public $quantity; 
    public $entry_date_time;
    //field list end

    //condition start
    public $df;
    public $dt;
    public $size;
    //condition end
    
    public function __construct($db){
        $this->conn = $db;
    }


    function create(){
        $query = "INSERT INTO " . $this->table_name . " SET stock_in_date=:stock_in_date, store=:store, item_id=:item_id, item_name=:item_name, quantity=:quantity, capital_price=:capital_price, stock_in_by=:stock_in_by, stock_in_receive_by=:stock_in_receive_by, entry_date_time=:entry_date_time";
        $stmt = $this->conn->prepare($query);

        
        $this->capital_price=htmlspecialchars(strip_tags($this->capital_price));

        $stmt->bindParam(":stock_in_date", $this->stock_in_date);
        $stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
        $stmt->bindParam(":item_name", $this->item_name);
        $stmt->bindParam(":quantity", $this->quantity);
        $stmt->bindParam(":capital_price", $this->capital_price);
        $stmt->bindParam(":stock_in_by", $this->stock_in_by);
        $stmt->bindParam(":stock_in_receive_by", $this->stock_in_receive_by);
        $stmt->bindParam(":entry_date_time", $this->entry_date_time);

        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }    
        return false;
    }

    function delete(){
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(1, $this->id);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function getOneRow(){
        $query = "SELECT * FROM " . $this->table_name . "  WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->store = $row['store'];
        $this->item_id = $row['item_id'];
        $this->item_name = $row['item_name'];
        $this->quantity = $row['quantity'];
        $this->capital_price = $row['capital_price'];
    }

    function getAllRows(){
        $condition = "";
        if($this->stock_in_date){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " stock_in_date =:stock_in_date";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }
        $query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY id DESC ";
        $stmt = $this->conn->prepare($query);
        $this->stock_in_date=htmlspecialchars(strip_tags($this->stock_in_date));

        if($this->stock_in_date) $stmt->bindParam(":stock_in_date", $this->stock_in_date);

        $stmt->execute();
        return $stmt;
    }   

    function search(){
        $condition = "";
        if($this->df){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " m_stock_in.stock_in_date >=:df ";
        }

        if($this->dt){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " m_stock_in.stock_in_date <=:dt ";
        }

        if($this->item_name){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " (m_stock_in.item_name LIKE  :item_name '%' or m_stock_in.item_name LIKE '%' :item_name '%' or m_stock_in.item_name Like '%' :item_name ) ";
        }

        if($this->stock_in_by){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " (stock_in_by LIKE  :stock_in_by '%' or stock_in_by LIKE '%' :stock_in_by '%' or stock_in_by Like '%' :stock_in_by ) ";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT * FROM m_stock_in JOIN m_item ON m_stock_in.item_id=m_item.id " . $condition . " order by stock_in_date";
        $stmt = $this->conn->prepare($query);
        $this->df=htmlspecialchars(strip_tags($this->df));
        $this->dt=htmlspecialchars(strip_tags($this->dt));
        $this->item_name=htmlspecialchars(strip_tags($this->item_name));
        $this->stock_in_by=htmlspecialchars(strip_tags($this->stock_in_by));
        
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->item_name) $stmt->bindParam(":item_name", $this->item_name);
        if($this->stock_in_by) $stmt->bindParam(":stock_in_by", $this->stock_in_by);

        $stmt->execute();
        return $stmt;
    }
}
