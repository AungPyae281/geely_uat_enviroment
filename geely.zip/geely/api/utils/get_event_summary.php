<?php
	header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../config/database.php';
	include_once '../objects/event.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$event = new Event($db);

	$data = json_decode(file_get_contents("php://input"));

	$event->name = $data->name;

	$descriptions = array();
	$targets = array();
	$actuals = array();

	$stmt = $event->summaryEvents();	
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		extract($row);
		array_push($descriptions,$description);
		array_push($targets, (int)$target);
		array_push($actuals, (int)$actual);
	}

	$percentages = [];

	// Calculate percentages
	for ($i = 0; $i < count($targets); $i++) {
	    // Calculate percentage
	    $percentage = ($actuals[$i] / $targets[$i]) * 100;
	    
	    // Round to 2 decimal places
	    $percentage = round($percentage, 2);
	    
	    // Store the percentage in the result array
	    $percentages[] = $percentage;
	}

	$arr=array(
		"description" => $descriptions,
		"target" => $targets,
		"actual" => $actuals,
		"achievements" => $percentages
	);

	echo json_encode($arr);

?>