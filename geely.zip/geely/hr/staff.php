<?php include '../header.php'; ?>
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.col-form-label{
		padding-top: 4px !important;
	} 
	.toggle{
		min-height: 31px !important;
	}
	select{
		font-size: 14px !important;
		padding-top: 1px !important;
	}
	.timepickerIn, .timepickerOut{
		background-color: #fff !important;
	}
	.pAdding{
		padding-right: 6px;
		padding-left: 6px;
	}
	.none{
		display: none;
	}
</style>

<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Staff - <?= ((isset($_GET['id']))?"Edit":"Entry") ?></h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body" style="padding-top: 10px;">
								<div class="row">
									<div class="col-md-5">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Staff ID<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtStaffIDNO">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date Of Birth<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-2">
												<select class="form-control" id="cboDays"></select>
											</div>
											<div class="col-md-3">
												<select class="form-control" id="cboMonths">
													<option value="">Month</option>
													<option value="01">Jan</option>
													<option value="02">Feb</option>
													<option value="03">Mar</option>
													<option value="04">Apr</option>
													<option value="05">May</option>
													<option value="06">Jun</option>
													<option value="07">Jul</option>
													<option value="08">Aug</option>
													<option value="09">Sep</option>
													<option value="10">Oct</option>
													<option value="11">Nov</option>
													<option value="12">Dec</option>
												</select>
											</div>
											<div class="col-md-3">
												<select class="form-control" id="cboYears"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-2">
												<select class="form-control" id="cboCode">
													<option value=""></option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
													<option value="4">4</option>
													<option value="5">5</option>
													<option value="6">6</option>
													<option value="7">7</option>
													<option value="8">8</option>
													<option value="9">9</option>
													<option value="10">10</option>
													<option value="11">11</option>
													<option value="12">12</option>
													<option value="13">13</option>
													<option value="14">14</option>
												</select>
											</div>
											<div class="col-md-2" style="padding-left: 0px;padding-right: 0px;">
												<select class="form-control" id="cboTownshipCode"></select>
											</div>
											<div class="col-md-2">
												<select class="form-control" id="cboNRCType">
													<option value=""></option>
													<option value="(N)">(N)</option>
													<option value="(P)">(P)</option>
													<option value="(A)">(A)</option>
												</select>
											</div>
											<div class="col-md-2">
												<input type="text" class="form-control" id="txtNRCNo" maxlength="6" onkeypress="return isNumber(event)" style="text-align: right;"/>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Gender:</label>
											<div class="col-md-8" style="padding-top: 6px;">
												<label class="control-label col-md-3">
													<input id="optMale" name="optGender" value="0" type="radio" checked>
													Male
												</label>
												<label class="control-label col-md-3">
													<input id="optFemale" name="optGender" value="1" type="radio">
													Female
												</label>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Marital Status:</label>
											<div class="col-md-8" style="padding-top: 6px;">
												<label class="control-label col-md-3">
													<input id="optSingle" name="optMaritalStatus" value="0" type="radio" checked>
													Single
												</label>
												<label class="control-label col-md-3">
													<input id="optMarried" name="optMaritalStatus" value="1" type="radio">
													Married
												</label>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Phone<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPhone" onkeypress="return isNumber(event)">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">E-mail<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtEmail">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Contact Address<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtContactAddress" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Permanent Address<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtPermanentAddress" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Signature & ID<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-4">
												<input style="display:none" name="fileSig" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
												<img id="previewing" name="previewing" src="<?=$app_url;?>img/signature.png" style="height:128px; width:128px;cursor:pointer;" onclick="HandleBrowseClickSig('input-image-hidden');" title="Click to Change the Photo." class="profile-user-img img-responsive" alt="User profile picture">
											</div>
											<div class="col-md-4">
												<input style="display:none" name="fileID" id="input-image-card-hidden" onchange="document.getElementById('card').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
												<img id="card" name="previewing" src="<?=$app_url;?>img/id_card.png" style="height:128px; width:128px;cursor:pointer;" onclick="HandleBrowseClickID('input-image-card-hidden');" title="Click to Change the Photo." class="profile-user-img img-responsive" alt="User profile picture">
											</div>
										</div>
									</div>
									<div class="col-md-1"></div>
									<div class="col-md-5">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Join Date:</label>
											<div class="col-md-8">
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Department<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboDepartment" style=" display: inline-block !important;"></select>
											</div>
										</div>	
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Position<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPosition" style=" display: inline-block !important;"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Reporting To:</label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtReportingToName" value='' data-id='' class="form-control" disabled>
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllIncharge()" id="btnIncharge">. . .</button>
													</span>         
												</div> 
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Reporting To Position:</label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtReportingToPosition" value='' class="form-control" disabled>
												</div> 
											</div>
										</div>
										<fieldset style="background-color: #f9f5f5;" id="AssignWorkingDays">
											<legend style="background-color: #dbd9d9;color: white;padding: 5px 10px;font-size: 15px !important;">Assigned Working Hours:</legend>
										</fieldset>
									</div>
								</div>
							</div>
							<div class="form-group row" style="margin-top: 0px;">
								<div class="col-md-9"></div>
								<?php if($id==""){ ?>
								<div class="col-md-2" style="padding-right: 22px;">
									<button type="button" class="btn btn-success btn-block" id="btnSubmit">Save</button>
								</div>
								<?php }else{ ?>
								<div class="col-md-2" style="padding-right: 22px;">
									<button type="button" class="btn btn-primary btn-block" id="btnSubmit">Update</button>
								</div>
								<?php } ?>
							</div>	
						</div>
						<div class="col-md-1"></div>
					</div> 
				</div>
			</form>

			<center>
				<div class="modal fade" id="myModalIncharge">
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 70%; top: 30px;">
							<div class="modal-header">
								<h4 class="modal-title">Reporting To List <span id="total_records" style="font-weight:bold;"> </span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<table id="myTable" class="table table-bordered table-hover">
									<thead style="background-color: #ecedee;">
										<tr>
											<th style="width: 6%;">ID No.</th>
											<th>Name</th>
											<th>Department</th>
											<th>Position</th>
											<th>Phone</th>
											<th style="display: none;">ID</th>
										</tr>
									</thead>
									<tbody style="cursor: pointer;"></tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</center>

		</div>
	</div>
</div> 
</div>
</section>
</div>

<?php include '../footer.php'; ?>

<script>
	var id = '<?= $id ?>';
	var dayOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	var parent_id = "0";

	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function () {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		$(".toggle").css("height", "31.6px");
		$(".toggle").css("margin-right", "0px");
		fillNumbers(); 
		fillAssignedDayOfWeek();
		if(id){ 
			getOneStaff();
		}else{
			getAllDepartment();
		}
	});	

	$("#cboCode").change(function(){    
		getNRCbySDCode();
	});  

	$("#cboDepartment").change(function(){
		getPositionbyDepartment();
	});

	$("#btnSubmit").click(function(){
		submitTF = true;
		$("#frmEntry").submit();
		submitTF = false;
	});

	function HandleBrowseClickSig(input_image){
		var fileinputImg = document.getElementById(input_image);
		fileinputImg.click();
	} 

	function HandleBrowseClickID(input_image){
		var fileinputNRCF = document.getElementById(input_image);
		fileinputNRCF.click();
	} 

	function fillNumbers(){
		$("#cboDays").find("option").remove();
		$("#cboYears").find("option").remove();
		$("#cboDays").append("<option value=''>Day</option>");
		for (var a = 1; a <= 31; a++){
			if(a==1 || a==2 || a==3 || a==4 || a==5 || a==6 || a==7 || a==8 || a==9){
				var aa = '0' + a;
				$("#cboDays").append("<option value= '" + aa + "'>" + a + "</option>");
			}else{
				$("#cboDays").append("<option value= '" + a + "'>" + a + "</option>");
			}
		}
		var d = new Date();
		var yy = d.getFullYear();
		$("#cboYears").append("<option value=''>Year</option>");
		for (var i = yy; i >= 1920; i--){
			$("#cboYears").append("<option value= '" + i + "'>" + i + "</option>");
		}
	}

	function fillAssignedDayOfWeek(){
		$("#AssignWorkingDays").find(".DOW").remove();
		for (var x = 0; x < dayOfWeek.length; x++){
			$("#AssignWorkingDays").append('<div class="row DOW" style="padding-bottom: 9px;"><div class="col-md-1"></div><div class="col-md-3" style="padding-left: 20px;"><div class="icheck-success d-inline"><input type="checkbox" id="chk' + dayOfWeek[x] + '" ' + ((x<7)?'checked':'') + ' onclick="clickOnOff(this)"><label for="chk' + dayOfWeek[x] + '">' + dayOfWeek[x] + '</label></div></div><div class="col-md-8"><div class="form-group row"><div class="col-md-5"><div class="input-group bootstrap-timepicker"><div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;"><i class="far fa-clock"></i></div><input type="text" class="form-control timepickerIn" id="txtTimePickerIn' + dayOfWeek[x] + '" readonly ' + ((x<7)?'':'disabled') + '></div></div><label class="col-md-1 col-form-label" style="text-align: center;">~</label><div class="col-md-5"><div class="input-group bootstrap-timepicker"><div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;"><i class="far fa-clock"></i></div><input type="text" class="form-control timepickerOut" id="txtTimePickerOut' + dayOfWeek[x] + '" readonly ' + ((x<7)?'':'disabled') + '></div></div></div></div></div>');
		}
		$('.timepickerIn').timepicker({
			showInputs: false,
			defaultTime: '08:00 AM'
		});

		$('.timepickerOut').timepicker({
			showInputs: false,
			defaultTime: '05:00 PM'
		});
	}

	function clickOnOff(obj){
		if($(obj).is(':checked')) {
			$("#txtTimePickerIn" + $(obj).attr("id").replace("chk", "")).attr("disabled", false);
			$("#txtTimePickerOut" + $(obj).attr("id").replace("chk", "")).attr("disabled", false);
		}else {
			$("#txtTimePickerIn" + $(obj).attr("id").replace("chk", "")).attr("disabled", true);
			$("#txtTimePickerIn" + $(obj).attr("id").replace("chk", "")).val("08:00 AM");
			$("#txtTimePickerOut" + $(obj).attr("id").replace("chk", "")).attr("disabled", true);
			$("#txtTimePickerOut" + $(obj).attr("id").replace("chk", "")).val("05:00 PM");
		}
	}

	function getNRCbySDCode(tc){
		var states_divisions_code = $("#cboCode").val(); 
		$("#cboTownshipCode").find("option").remove();
		$("#cboTownshipCode").append("<option value = ''></option>");
		$.ajax({
			url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
			type: "POST",
			data: JSON.stringify({ states_divisions_code: states_divisions_code })
		}).done(function(data) {  
			$.each(data.records, function(i, v) {   
				if(v.townships_code==tc){
					$("#cboTownshipCode").append("<option value= '" + v.townships_code + "' selected>" + v.townships_code + "</option>");
				}else{
					$("#cboTownshipCode").append("<option value= '" + v.townships_code + "'>" + v.townships_code + "</option>");
				}
			});
		});
	}  

   	function getAllDepartment(dep, pos){
		$("#cboDepartment").find("option").remove();
		$("#cboDepartment").append("<option value = '' data-id = ''></option>");
		$.ajax({
			url: APP_URL + "api/hr/department/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.department==dep){
					$("#cboDepartment").append("<option value= '" + v.department + "' data-id = '"+ v.id + "' selected>" + v.department + "</option>");
				}else{
					$("#cboDepartment").append("<option value= '" + v.department + "' data-id = '"+ v.id + "'>" + v.department + "</option>");
				}
			});
			getPositionbyDepartment(pos);
		});
	}

	function getPositionbyDepartment(pos){
		$("#cboPosition").find("option").remove();
		$("#cboPosition").append("<option value = '' data-id = ''></option>");
		var department = $("#cboDepartment").val();

		if(department){
			$.ajax({
				type: "POST",
				url: APP_URL + "api/hr/position/get_all_rows_by_department.php",
				data: JSON.stringify({ department: department })
			}).done(function(data) {
				$.each(data.records, function(i, v) {
					if(v.position==pos){
						$("#cboPosition").append("<option value= '" + v.position + "' data-id = '"+ v.id + "' selected>" + v.position + "</option>");
					}else{
						$("#cboPosition").append("<option value= '" + v.position + "' data-id = '"+ v.id + "'>" + v.position + "</option>");
					}
				});
			});
		}
	}

	function getAllIncharge(){
		$("#myModalIncharge").modal('show');
		table = $('#myTable').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/hr/staff/get_all_rows_except_by_self.php?id=" + id,
			"columnDefs": [
	            {
	                "targets": [5],
	                "className": 'none'
	            },
	        ]
		});	
	}

	$('#myTable').on('click', 'tbody td', function(e){
		$(this).css("color","");
		$(this).css("background-color","");
		$(this).parent().css("background-color", "#e3ecf5");
		$(this).parent().css("color", "rgb(34, 126, 140)");

		$("#txtReportingToName").val($(this).parent().find("td").eq(1).text());
		$("#txtReportingToName").attr("data-id", $(this).parent().find("td").eq(5).text());
		$("#txtReportingToPosition").val($(this).parent().find("td").eq(3).text());
		$("#myModalIncharge").modal('hide');
	});

	$("#frmEntry").on('submit',(function(e) {
		e.preventDefault();
		var formData = new FormData(this);
		var card_no = $("#txtStaffIDNO").val();
		var name = $("#txtName").val();
		var dob = (($("#cboYears").val()!="" && $("#cboMonths").val()!="" && $("#cboDays").val())?$("#cboYears").val() + "-" + $("#cboMonths").val() + "-" + $("#cboDays").val():"");
		var nrc_no = "";
		var nrc_no_scode = (($("#cboCode").val())?($("#cboCode").val()):"");
		var nrc_no_tcode = (($("#cboTownshipCode").val())?($("#cboTownshipCode").val()):"");
		var nrc_no_type = (($("#cboNRCType").val())?($("#cboNRCType").val()):"");
		var nrc_no_seq = $("#txtNRCNo").val();
		if(nrc_no_scode!="" && nrc_no_tcode!="" && nrc_no_type!="" && nrc_no_seq!=""){
			nrc_no = nrc_no_scode + "/" + nrc_no_tcode + nrc_no_type + nrc_no_seq;
		}
		var gender = $("input[name='optGender']:checked").val();
		var marital_status = $("input[name='optMaritalStatus']:checked").val();
		var phone = $("#txtPhone").val();
		var email = $("#txtEmail").val();
		var contact_address = $("#txtContactAddress").val();
		var permanent_address = $("#txtPermanentAddress").val();
		var join_date = $("#txtDatePicker").val();
		var department = $("#cboDepartment").val();
		var position = $("#cboPosition").val();
		var reporting_to_id = $("#txtReportingToName").attr("data-id");

		var wt_monday = (($("#chkMonday").prop("checked"))?($("#txtTimePickerInMonday").val() + "-" + $("#txtTimePickerOutMonday").val()):"");
		var wt_tuesday = (($("#chkTuesday").prop("checked"))?($("#txtTimePickerInTuesday").val() + "-" + $("#txtTimePickerOutTuesday").val()):"");
		var wt_wednesday = (($("#chkWednesday").prop("checked"))?($("#txtTimePickerInWednesday").val() + "-" + $("#txtTimePickerOutWednesday").val()):"");
		var wt_thursday = (($("#chkThursday").prop("checked"))?($("#txtTimePickerInThursday").val() + "-" + $("#txtTimePickerInThursday").val()):"");
		var wt_friday = (($("#chkFriday").prop("checked"))?($("#txtTimePickerInFriday").val() + "-" + $("#txtTimePickerOutFriday").val()):"");
		var wt_saturday = (($("#chkSaturday").prop("checked"))?($("#txtTimePickerInSaturday").val() + "-" + $("#txtTimePickerOutSaturday").val()):"");
		var wt_sunday = (($("#chkSunday").prop("checked"))?($("#txtTimePickerInSunday").val() + "-" + $("#txtTimePickerOutSunday").val()):"");

		var sigp = "<?=$app_url;?>img/signature.png";
		var sig_pic = $("#previewing").attr("src");
		var idp = "<?=$app_url;?>img/id_card.png";
		var id_pic = $("#card").attr("src");

		if(card_no==""){
			bootbox.alert("Please fill Staff ID.");
		}else if(name==""){
			bootbox.alert("Please fill name.");
		}else if(email==""){
	        bootbox.alert("Please fill the email.");
	    }else if(IsEmail(email)==false){
	        bootbox.alert("Email format is wrong. Please check again.");
	    }else if(sig_pic==sigp){
            bootbox.alert("Please upload signature.");
        }else if(id_pic==idp){
            bootbox.alert("Please upload ID card.");
        }else if(department=="" || department==null){
        	bootbox.alert("Please choose department.");
        }else if(position=="" || position==null){
        	bootbox.alert("Please choose position.");
        }else if(nrc_no==""){
        	bootbox.alert("Please fill NRC.");
        }else if(dob==""){
        	bootbox.alert("Please fill Date of birth.");
        }else if(phone==""){
        	bootbox.alert("Please fill Phone number.");
        }else if(contact_address==""){
        	bootbox.alert("Please fill Contact Address.");
        }else if(permanent_address==""){
        	bootbox.alert("Please fill Permanent Address.");
        }else{
			$("#loading").css("display", "block");
			var objArr = [];
			objArr.push({ "id": id, "card_no": card_no, "name": name, "dob": dob, "nrc_no": nrc_no, "gender": gender, "marital_status": marital_status, "phone": phone, "email": email, "contact_address": contact_address, "permanent_address": permanent_address, "join_date": join_date, "department": department, "position": position, "reporting_to_id": reporting_to_id, "wt_monday": wt_monday, "wt_tuesday": wt_tuesday, "wt_tuesday": wt_tuesday, "wt_wednesday": wt_wednesday, "wt_thursday": wt_thursday, "wt_friday": wt_friday, "wt_saturday": wt_saturday, "wt_sunday": wt_sunday});
			formData.append('objArr', JSON.stringify( objArr ));
			$.ajax({
				url : APP_URL + "api/hr/staff/create_update.php",
				type : "POST",
				processData : false,
				contentType : false,
				data : formData,
				success: function(data){
					$("#loading").css("display", "none");
					if(data.message=="created"){
						bootbox.alert("Successfully created.");
						$("#frmEntry")[0].reset();
						$("#txtDatePicker").val(customDate);
						$("#datePicker").datepicker("setDate", customDate);
						fillNumbers(); 
						fillAssignedDayOfWeek();
						getAllDepartment();
						$("#txtReportingToName").attr("data-id", "");
						document.getElementById('previewing').src = "<?=$app_url;?>/img/signature.png";
						document.getElementById('card').src = "<?=$app_url;?>/img/id_card.png";
					}else if(data.message=="duplicate"){
						bootbox.alert("Not allow duplicate data.");
					}else if(data.message=="updated"){
						bootbox.alert("Successfully Updated.");
	  					document.location = APP_URL + "reports/staff.php";
					}else if(data.message=="session expire"){
						bootbox.alert("Session Expire! Please refresh the browser and login again.");
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			});
		}
	}));

	function getOneStaff(){
		$.ajax({
			url: APP_URL + "api/hr/staff/get_one_staff.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data){	
			$("#txtStaffIDNO").attr("disabled", true);
			$("#txtStaffIDNO").val(data.card_no);
			$("#txtName").val(data.name);

			if(data.dob){
	            if(data.dob.includes("-")){
	                var dobb = data.dob.split("-");
	                $("#cboDays").val(dobb[2]);
	                $("#cboMonths").val(dobb[1]);
	                $("#cboYears").val(dobb[0]);
	            }
	        }

	        if(data.nrc_no){
	            if(data.nrc_no.includes("/") && data.nrc_no.includes("(") && data.nrc_no.includes(")")){
	                var nrc = data.nrc_no.split("/");
	                $("#cboCode").val(nrc[0]);
	                var ap_tc = nrc[1].split("(");
	                getNRCbySDCode(ap_tc[0]);
	                var ap_type = ap_tc[1].split(")");
	                $("#cboNRCType").val("(" + ap_type[0] + ")");
	                $("#txtNRCNo").val(ap_type[1]);
	            }
	        }

	        if(data.marital_status=="0"){
	            $("#optSingle").prop("checked", true);
	         }else{
	            $("#optMarried").prop("checked", true);
	        }

	        if(data.gender=="0"){
	            $("#optMale").prop("checked", true);
	        }else{
	            $("#optFemale").prop("checked", true);
	        }

			$("#txtPhone").val(data.phone);
			$("#txtEmail").val(data.email);
			$("#txtContactAddress").val(data.contact_address);
			$("#txtPermanentAddress").val(data.permanent_address);
			$("#txtDatePicker").val(data.join_date);
			$("#datePicker").datepicker("setDate", data.join_date);

			getAllDepartment(data.department, data.position);

			$("#txtReportingToName").val(data.reporting_to_name);
			$("#txtReportingToName").attr("data-id", data.reporting_to_id);
			$("#txtReportingToPosition").val(data.reporting_to_position);

			if(data.wt_monday!=""){
	            if(data.wt_monday.includes("-")){
	                var in_out = data.wt_monday.split("-");
	                $("#txtTimePickerInMonday").val(in_out[0]);
					$("#txtTimePickerOutMonday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkMonday").attr("checked", false);
	        }

	        if(data.wt_tuesday!=""){
	            if(data.wt_tuesday.includes("-")){
	                var in_out = data.wt_tuesday.split("-");
	                $("#txtTimePickerInTuesday").val(in_out[0]);
					$("#txtTimePickerOutTuesday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkTuesday").attr("checked", false);
	        }

	        if(data.wt_wednesday!=""){
	            if(data.wt_wednesday.includes("-")){
	                var in_out = data.wt_wednesday.split("-");
	                $("#txtTimePickerInWednesday").val(in_out[0]);
					$("#txtTimePickerOutWednesday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkWednesday").attr("checked", false);
	        }

	        if(data.wt_thursday!=""){
	            if(data.wt_thursday.includes("-")){
	                var in_out = data.wt_thursday.split("-");
	                $("#txtTimePickerInThursday").val(in_out[0]);
					$("#txtTimePickerOutThursday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkThursday").attr("checked", false);
	        }

	        if(data.wt_friday!=""){
	            if(data.wt_friday.includes("-")){
	                var in_out = data.wt_friday.split("-");
	                $("#txtTimePickerInFriday").val(in_out[0]);
					$("#txtTimePickerOutFriday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkFriday").attr("checked", false);
	        }

	        if(data.wt_saturday!=""){
	            if(data.wt_saturday.includes("-")){
	                var in_out = data.wt_saturday.split("-");
	                $("#txtTimePickerInSaturday").val(in_out[0]);
					$("#txtTimePickerOutSaturday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkSaturday").attr("checked", false);
	        }

	        if(data.wt_sunday!=""){
	            if(data.wt_sunday.includes("-")){
	                var in_out = data.wt_sunday.split("-");
	                $("#txtTimePickerInSunday").val(in_out[0]);
					$("#txtTimePickerOutSunday").val(in_out[1]);
	            }
	        }else{
	        	$("#chkSunday").attr("checked", false);
	        }

	        if(data.signature){
				$("#previewing").attr('src','<?=$app_url;?>api/hr/staff/signature/' + data.signature);
			}else{
				$("#previewing").attr('src','<?=$app_url;?>img/signature.png');
			}

			if(data.id_card){
				$("#card").attr('src','<?=$app_url;?>api/hr/staff/id_card/' + data.id_card);
			}else{
				$("#card").attr('src','<?=$app_url;?>img/id_card.png');
			}
		});	
	} 

	function IsEmail(email) {
	     var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	     if(!regex.test(email)) {
	         return false;
	     }else{
	         return true;
	     }
	}

	function btozero(obj){
		if($(obj).val() == "" || $(obj).val() == "0")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}
</script>	
