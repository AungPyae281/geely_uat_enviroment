<?php include 'header.php'; ?>   
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
<style type="text/css">
	.highcharts-credits, .highcharts-axis-title{
		display: none;
	}
</style>
<div class="content-wrapper">
	<div class="content-header">
		<h3>Dashboard</h3>
	</div>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group row">
						<label class="col-md-1 col-form-label" style="text-align: right;">Pages:</label>
						<div class="col-md-4">
							<input id="txtYear" style="display: none;">
							<select type="text" class="form-control" id="cboPages"></select>
						</div>
					</div>
					<div id="container1"></div>
				</div>
				<div class="col-md-6">
					<div class="form-group row">
						<label class="col-md-1 col-form-label" style="text-align: right;">Target:</label>
						<div class="col-md-4">
							<select type="text" class="form-control" id="cboTarget"></select>
						</div>
					</div>
					<div id="container2"></div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group row">
						<label class="col-md-1 col-form-label" style="text-align: right;">Events:</label>
						<div class="col-md-4">
							<select type="text" class="form-control" id="cboEvents"></select>
						</div>
					</div>
					<div id="container3"></div>
				</div>
			</div>
		</div>
	</section>
</div>	

<?php include 'footer.php'; ?>

<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$(function() {
		$("body").addClass("sidebar-collapse"); 
		$("#txtYear").val(d.getFullYear());
		fillPages();
		fillTarget();
		fillEvents();
		// getAllChart();		

		Highcharts.chart('container1', {
		    chart: {
		        type: 'column'
		    },
		    title: {
		    	// title: false
		        text: 'For Page Monthly Actual Count'
		    },
		    xAxis: {
		        categories: ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"]
		    },
		    yAxis: {
		        // categories: [0, 16, 32, 48, 64],
		        title: {
		            text: ''
		        }
		    },
		    tooltip: {
		        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
		        shared: true
		    },
		    plotOptions: {
		        column: {
		            stacking: 'percent'
		        }
		    },
		    series: [{
		        name: '	No. of Booking',
		        data: '',
		        color: '#544fc5'
		    }, {
		        name: 'No. of Lead',
		        data: '',
		        color: '#2caffe'
		    }, {
		        name: 'No. of Engagement',
		        data: '',
		        color: '#7cb5ec'
		    }, {
		        name: 'No. of Reach',
		        data: '',
		        color: '#91e8e1'
		    }, {
		        name: 'No. of like',
		        data: '',
		        color: '#00e272'
		    }]
		});	

		Highcharts.chart('container2', {
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'For Page Target, Actual, Achievement'
		    },
		    xAxis: {
		        categories: ['Like', 'Reach', 'Engagement', 'Booking', 'Lead']
		    },
		    credits: {
		        enabled: false
		    },
		    plotOptions: {
		        column: {
		            borderRadius: '25%'
		        }
		    },
		    series: [{
		        name: 'Target',
		        data: ""
		    }, {
		        name: 'Actual',
		        data: ""
		    }, {
		        name: 'Achievement(%)',
		        data: ""
		    }]
		});
		// getPageMonthlyActualCount();

		Highcharts.chart('container3', {
		    chart: {
		        type: 'column'
		    },
		    title: {
		        text: 'Events Target, Actual, Achievement'
		    },
		    xAxis: {
		        categories: ['Number of Attendance (or) Walk In', 'Number of Test Drive', 'Potential', 'Booking', 'Reach', 'React', 'Comment', 'Share']
		    },
		    credits: {
		        enabled: false
		    },
		    plotOptions: {
		        column: {
		            borderRadius: '25%'
		        }
		    },
		    series: [{
		        name: 'Target',
		        data: ""
		    }, {
		        name: 'Actual',
		        data: ""
		    }, {
		        name: 'Achievement(%)',
		        data: ""
		    }]
		});
		// getPageMonthlyActualCount();
	});	

	$('#cboPages').on('change',function(){
		if($("#cboPages").val()!=""){
        	getPagesSummary();	
		}
	});

	$('#cboTarget').on('change',function(){
		if($("#cboTarget").val()!=""){
	        getTargetSummary();
	    }
	});

	$('#cboEvents').on('change',function(){
		if($("#cboEvents").val()!=""){
	        getEventsSummary();
	    }
	});

	function getEventsSummary(){
		var name = $("#cboEvents").val();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/utils/get_event_summary.php",
			data: JSON.stringify({ name: name }),
			success: function(data){  
				Highcharts.chart('container3', {
				    chart: {
				        type: 'column'
				    },
				    title: {
				        text: 'Events Target, Actual, Achievement'
				    },
				    xAxis: {
				        categories: data.description
				    },
				    credits: {
				        enabled: false
				    },
				    plotOptions: {
				        column: {
				            borderRadius: '25%'
				        }
				    },
				    series: [{
				        name: 'Target',
				        data: data.target
				    }, {
				        name: 'Actual',
				        data: data.actual
				    }, {
				        name: 'Achievement(%)',
				        data: data.achievements
				    }]
				});
			}
		});
	}

	function getTargetSummary(){
		var name = $("#cboTarget").val();
		var month_from = $("#cboTarget option:selected").attr("data-month-from");
		var month_to = $("#cboTarget option:selected").attr("data-month-to");
		var page_id = $("#cboTarget option:selected").attr("data-page-id");
		$.ajax({
			type: "POST",
			url: APP_URL + "api/utils/get_m_target_by_month_summary.php",
			data: JSON.stringify({ name: name, month_from: month_from, month_to: month_to, page_id: page_id }),
			success: function(data){  
				Highcharts.chart('container2', {
				    chart: {
				        type: 'column'
				    },
				    title: {
				        text: 'For Page Target, Actual, Achievement'
				    },
				    xAxis: {
				        categories: ['Like', 'Reach', 'Engagement', 'Booking', 'Lead']
				    },
				    credits: {
				        enabled: false
				    },
				    plotOptions: {
				        column: {
				            borderRadius: '25%'
				        }
				    },
				    series: [{
				        name: 'Target',
				        data: data.target
				    }, {
				        name: 'Actual',
				        data: data.actual
				    }, {
				        name: 'Achievement(%)',
				        data: data.achievements
				    }]
				});
			}
		});
	}

	function getPagesSummary(){
		var name = $("#cboPages").val();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/utils/get_marketing_summary.php",
			data: JSON.stringify({ name: name }),
			success: function(data){  
				Highcharts.chart('container1', {
				    chart: {
				        type: 'column'
				    },
				    title: {
				    	// title: false
				        text: 'For Page Monthly Actual Count'
				    },
				    xAxis: {
				        categories: ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"]
				    },
				    yAxis: {
				        // categories: [0, 16, 32, 48, 64],
				        title: {
				            text: ''
				        }
				    },
				    tooltip: {
				        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
				        shared: true
				    },
				    plotOptions: {
				        column: {
				            stacking: 'percent'
				        }
				    },
				    series: [{
				        name: '	No. of Booking',
				        data: data.page_booking,
				        color: '#544fc5'
				    }, {
				        name: 'No. of Lead',
				        data: data.page_lead,
				        color: '#2caffe'
				    }, {
				        name: 'No. of Engagement',
				        data: data.page_engagement,
				        color: '#7cb5ec'
				    }, {
				        name: 'No. of Reach',
				        data: data.page_reach,
				        color: '#91e8e1'
				    }, {
				        name: 'No. of like',
				        data: data.page_like,
				        color: '#00e272'
				    }]
				});	
			}
		});
	}

	function getAllChart(){
		// var date = $("#txtDatePickerChart").val();
		var page_name = $("#cboPages").val();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/showcase_stock_volume/get_area_chart.php",
			data: JSON.stringify({ page_name: page_name }),
			success: function(data){  
				console.log(data);
				// pageMonthlyActualCount(data);
			}
		});
	}

	function fillPages(dp){
	   $("#cboPages").find("option").remove();
	   $.ajax({
	      url: APP_URL + "api/marketing/pages/get_all_rows.php"
	   }).done(function(data) {   
	   		$("#cboPages").append("<option value= '' data-code = '' selected></option>");
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"'>" + v.name + "</option>");
	         }else{
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	function fillTarget(dp){
	   $("#cboTarget").find("option").remove();
	   $.ajax({
	      url: APP_URL + "api/marketing/target/get_all_rows.php"
	   }).done(function(data) {   
	   		$("#cboTarget").append("<option value= '' data-code = '' selected></option>");
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboTarget").append("<option value= '" + v.name + "' data-page-id = '"+ v.page_id + "' data-month-from = '"+ v.month_from +"' data-month-to = '"+ v.month_to +"' selected>" + v.name + "</option>");
	         }else{
	            $("#cboTarget").append("<option value= '" + v.name + "' data-page-id = '"+ v.page_id + "' data-month-from = '"+ v.month_from +"' data-month-to = '"+ v.month_to +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	function fillEvents(dp){
	   $("#cboEvents").find("option").remove();
	   $.ajax({
	      url: APP_URL + "api/marketing/event/get_all_rows.php"
	   }).done(function(data) {   
	   		$("#cboEvents").append("<option value= '' data-code = '' selected></option>");
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboEvents").append("<option value= '" + v.name + "' selected>" + v.name + "</option>");
	         }else{
	            $("#cboEvents").append("<option value= '" + v.name + "' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	// function getPageMonthlyActualCount(){
	// 	var page_name = $("#cboPages option:selected").val();
	// 	var year = $("#txtYear").val();
	// 	$.ajax({
	// 		url: APP_URL + "api/marketing/target_pages/search.php",
	// 		type: "POST",
	// 		data: JSON.stringify({ page_name: page_name, year: "2024%" })
	// 	}).done(function(data) {	
	// 		console.log(data);
	// 		// createChart(data.chart_categories, data.vacant_series, data.occupy_series);
	// 	});
	// }

	// function createChart(chart_categories, vacant_series, occupy_series){
	// 	Highcharts.chart('container2', {
	// 	    chart: {
	// 	        type: 'column',
	// 	        marginTop: 27
	// 	    },
	// 	    exporting: {
	// 		    enabled: false
	// 		},
	// 	    title: {
	// 	    	// title: false
	// 	        text: ''
	// 	    },
	// 	    xAxis: {
	// 	        categories: chart_categories
	// 	    },
	// 	    yAxis: {
	// 	        // categories: [0, 16, 32, 48, 64],
	// 	        title: {
	// 	            text: ''
	// 	        }
	// 	    },
	// 	    tooltip: {
	// 	        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
	// 	        shared: true
	// 	    },
	// 	    plotOptions: {
	// 	        column: {
	// 	            stacking: 'percent'
	// 	        }
	// 	    },
	// 	    series: [{
	// 	        name: 'Vacant',
	// 	        data: vacant_series,
	// 	        color: '#238f5d'
	// 	    }, {
	// 	        name: 'Occupy',
	// 	        data: occupy_series,
	// 	        color: '#ef7125'
	// 	    }]
	// 	});	
	// }
</script>