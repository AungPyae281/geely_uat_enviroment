<?php include '../header.php'; ?>
<?php
	$item_id = "";
	if(isset($_GET['item_id'])){
		if(!empty($_GET['item_id'])){
			$item_id = $_GET['item_id'];
		}
	}
?>
<style>
	#myTable1 td:nth-child(5){
		text-align: right;
		padding-right: 30px;
	}	
	div.dataTables_wrapper div.dataTables_info {
	    display: none;
	}
	.hide_column{
		display: none;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Stock In</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<form role="form" id="frmEntry">	
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">Entry</h3>
							</div>
							<div class="card-body">	
								<table id="myTable1" class="table table-bordered table-hover">
									<thead style="background-color: #ecedee;">
										<tr>
											<th style="width: 3%;">No.</th>
											<th>Type</th>
											<th>Category</th>
											<th>Item Name</th>
											<th>Capital Price</th>
											<th>Description</th>
											<th>ID</th>
										</tr>
									</thead>
									<tbody style="cursor: pointer;"></tbody>
								</table>
							</div>
							<div class="row">
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Date<span style="color: red; font-size: 20px;">*</span>: </label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Item Name<span style="color: red; font-size: 20px;">*</span>:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtItemName" disabled>
										</div>
										<input type="text" class="form-control" id="txtItemID" hidden>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Stock In By<span style="color: red; font-size: 20px;">*</span>:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtStockInBy">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Receive By<span style="color: red; font-size: 20px;">*</span>:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtReceiveBy">
										</div>
									</div>
								</div>
								<div class="col-md-4" style="padding-right: 27px;">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Qty/Price<span style="color: red; font-size: 20px;">*</span>: </label>
										<div class="col-md-3">
											<input type="number" class="form-control" onkeyup="btozero(this);" id="txtQuantity" value="1" min="1" style="text-align:right;">
										</div>
										<div class="col-md-5">
											<input type="text" class="form-control" onkeyup="btozero(this);" id="txtPrice" value="0"style="text-align:right;">
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 0px;">
										<div class="col-md-4"></div>
										<div class="col-md-8">
											<button type="button" class="btn btn-primary btn-block" onclick="create()">Add</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">Stock In List<span id="total_records" style="font-weight:bold;"> </span></h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
									<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
								</div>
							</div>
							<div class="card-body p-0">
								<table class="table table-striped table-bordered" id="myTable2">
									<thead>                  
										<tr>
											<th style="width: 3%;">No.</th>
											<th>Date</th>
											<th>Item Name</th>
											<th>Stock In By</th>
											<th>Receive By</th>
											<th style="width: 7%;">Qty</th>
											<th>Price</th>
											<!-- <th style="width: 3%;">Delete</th> -->
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
	</div>
</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var item_id = '<?= $item_id ?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		fillGrid();
		getStockList();
		if(item_id!=""){
			getItemDetail(item_id);
		}
	});

	$('#txtDatePicker').on('change',function(){
        getStockList();
	});

	function getItemDetail(item_id){
		$.ajax({
			url: APP_URL + "api/marketing/item/get_one_item.php",
			type: "POST",
			data: JSON.stringify({ id: item_id })
		}).done(function(data){	
			console.log(data);
	        $("#txtPrice").val(data.capital_price);
			$("#txtItemID").val(item_id);
			$("#txtItemName").val(data.item_name);
		});	
	}

	function fillGrid(){

		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/marketing/item/get_all_item_for_dtg.php",
			"columnDefs": [
	            {
	                "targets": [ 6 ],
	                // "visible": false,
	                "className": 'hide_column',
	                "searchable": false
	            },
	        ]
		});

		$('#myTable1').on('click', 'tbody td', function(e){
			$("#myTable1 tbody tr").css("color","");
			$("#myTable1 tbody tr").css("background-color","");
			$(this).parent().css("background-color", "#e3ecf5");
			$(this).parent().css("color", "rgb(34, 126, 140)");

			$("#txtPrice").val($(this).parent().find("td").eq(4).text().replace(/,/g, ''));
			$("#txtItemID").val($(this).parent().find("td").eq(6).text());
			$("#txtItemName").val($(this).parent().find("td").eq(3).text());	
		});
	}

	function getStockList(){
		var stock_in_date = $("#txtDatePicker").val();
		$.ajax({
			url: APP_URL + "api/marketing/stock_in/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ stock_in_date: stock_in_date })
		}).done(function(data){
			$("#loading").css("display","none");
			$("#myTable2").find("tbody").find("tr").remove();
			if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record(s) found.");}
			$.each(data.records, function(i, v) {	
				$("#myTable2").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px' class='order'>" + (i+1) + "</td>")
					.append("<td>" + v.stock_in_date + "</td>")
					.append("<td>" + v.item_name + "</td>")
					.append("<td>" + v.stock_in_by + "</td>")
					.append("<td>" + v.stock_in_receive_by + "</td>")
					.append("<td style='text-align:right;'>" + v.quantity + "</td>")
					.append("<td style='text-align:right;'>" + v.price + "</td>")
					// .append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='del(" + v.id + ",this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
				);
			});
        });
	}

	function del(id,obj){
		bootbox.confirm({
			message: "<h4>Are you sure that you want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
					type: "POST",
					url: APP_URL + "api/marketing/stock_in/delete.php",
					data: JSON.stringify({ id: id }),
					success: function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							getStockList();
						}else{
							bootbox.alert("Error on server side.");
						}
					}
					});
				}
			}
		});
	}

	function create(){
		var stock_in_date = $("#txtDatePicker").val();
		var item_id = $("#txtItemID").val();
		var item_name = $("#txtItemName").val();
		var quantity = parseInt($("#txtQuantity").val().replace(/,/g, ''));
		var price = parseInt($("#txtPrice").val().replace(/,/g, ''));
		var stock_in_by = $("#txtStockInBy").val();
		var stock_in_receive_by = $("#txtReceiveBy").val();
		if(quantity==0){
			bootbox.alert("Please fill the quantity.");
		}else if(stock_in_by==""){
			bootbox.alert("Please fill the stock in by.");
		}else if(stock_in_receive_by==""){
			bootbox.alert("Please fill the receive by.");
		}else if(item_id==""){
			bootbox.alert("Please select item detail.");
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/stock_in/create.php",
				type: "POST",
				data: JSON.stringify({ stock_in_date: stock_in_date, item_id: item_id, item_name: item_name, quantity: quantity, price: price, stock_in_by: stock_in_by, stock_in_receive_by: stock_in_receive_by })
			}).done(function(data) {
				if(data=="created"){
					bootbox.alert("Created.");
					$("#frmEntry")[0].reset();
					$("#txtDatePicker").val(customDate);
					getStockList();
				}else if(data=="updated"){
					bootbox.alert("Stockin success.");
					$("#frmEntry")[0].reset();
					$("#txtDatePicker").val(customDate);
					$("#txtStockInBy").val("");
					$("#txtReceiveBy").val("");
					$("#txtQuantity").val(1);
					$("#txtPrice").val(0);
					getStockList();
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}	

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}
</script>
