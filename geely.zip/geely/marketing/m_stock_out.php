<?php include '../header.php'; ?>
<style>
	#myTable1 td:nth-child(7), #myTable1 td:nth-child(5){
		text-align: right;
	}	
	div.dataTables_wrapper div.dataTables_info {
	    display: none;
	}
	.hide_column{
		display: none;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Stock Out</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<form role="form" id="frmEntry">	
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">Entry</h3>
							</div>

							<div class="card-body">	
								<table id="myTable1" class="table table-bordered table-hover">
									<thead style="background-color: #ecedee;">
										<tr>	
											<th style="width: 3%;">No.</th>
											<th>Type</th>
											<th>Category</th>
											<th>Item Name</th>
											<th>Capital Price</th>
											<th>Description</th>
											<th>Stock Balance</th>
											<th>ID</th>
										</tr>
									</thead>
									<tbody style="cursor: pointer;"></tbody>
								</table>	
							</div>

							<div class="row">
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Date<span style="color: red; font-size: 20px;">*</span>: </label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;padding-top: 0px;">Reason<span style="color: red; font-size: 20px;">*</span>:</label>
										<div class="col-md-8">
											<div class="radio">	
												<label class="control-label col-md-4">
													<input id="optUse" name="optReason" value="1" type="radio" checked>
													Use
												</label>
												<label class="control-label col-md-4">
													<input id="optLost" name="optReason" value="1" type="radio">
													Lost
												</label>
												<label class="control-label col-md-4">
													<input id="optDamage" name="optReason" value="1" type="radio">
													Damage
												</label>
												<label class="control-label col-md-4">
													<input id="optExpire" name="optReason" value="1" type="radio">
													Expire
												</label>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Quantity<span style="color: red; font-size: 20px;">*</span>: </label>
										<div class="col-md-8">
											<input type="number" class="form-control" onkeyup="btozero(this);" id="txtQuantity" value="1" min="1" style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Receive By<span style="color: red; font-size: 20px;">*</span>:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtReceiveBy">
										</div>
									</div>
								</div>
								<div class="col-md-4" style="padding-right: 27px;">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Stock Out By<span style="color: red; font-size: 20px;">*</span>:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtStockOutBy">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Remark:
										</label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtRemark">
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 0px;">
										<div class="col-md-4"></div>
										<div class="col-md-8">
											<button type="button" class="btn btn-primary btn-block" onclick="cre()">Add</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">Stock Out List<span id="total_records" style="font-weight:bold;"> </span></h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
									<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
								</div>
							</div>
							<div class="card-body p-0">
								<table class="table table-striped table-bordered" id="myTable2">
									<thead>                  
										<tr>
											<th style="width: 3%;">No.</th>
											<th>Date</th>
											<th>Item Name</th>
											<th>Stock Out By</th>
											<th>Receive By</th>
											<th style="width: 7%;">Qty</th>
											<th>Reason</th>
											<!-- <th style="width: 3%;">Delete</th> -->
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
					</form>
				</div>

			</div>
		</div>
		
	</div>
</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var OBJ = "";
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date", customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$('#datePicker').datepicker();  
		$("body").addClass("sidebar-collapse");
		fillGrid();
		getStockList();
	});

	$('#txtDatePicker').on('change',function(){
        getStockList();
	});


	function fillGrid(){
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/marketing/stock_balance/get_all_rows.php",
			"columnDefs": [
	            {
	                "targets": [ 7 ],
	                // "visible": false,
	                "className": 'hide_column',
	                "searchable": false
	            },
	        ]
		});

	}

	$('#myTable1').on('click', 'tbody td', function(e){
		OBJ = this;
		$("#myTable1 tbody tr").css("color","");
		$("#myTable1 tbody tr").css("background-color","");
		$(this).parent().css("background-color", "#e3ecf5");
		$(this).parent().css("color", "rgb(34, 126, 140)");

		// $("#txtPrice").val($(this).parent().find("td").eq(6).text().replace(/,/g, ''));
		// $("#txtItemCode").val($(this).parent().find("td").eq(1).text());
		// $("#txtItemName").val($(this).parent().find("td").eq(2).text());	
	});

	function getStockList(){
		var stock_out_date = $("#txtDatePicker").val();
		var reason = "";

		$("#myTable2").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/stock_out/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ stock_out_date: stock_out_date })
		}).done(function(data){
			$("#loading").css("display","none");	
			if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record(s) found.");}
			$.each(data.records, function(i, v) {
				if(v.use==1){
					reason = "Use";
				}else if(v.lost==1){
					reason = "Lost";
				}else if(v.damage==1){
					reason = "Damage";
				}else{
					reason = "Expire";
				}

				$("#myTable2").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i+1) + "</td>")
					.append("<td>" + v.stock_out_date + "</td>")	
					.append("<td>" + v.item_name + "</td>")
					.append("<td>" + v.stock_out_by + "</td>")
					.append("<td>" + v.stock_out_receive_by + "</td>")
					.append("<td style='text-align:right;'>" + v.quantity + "</td>")
					.append("<td>" + reason + "</td>")
					// .append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='del(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
				);
			});
        });
	}

	function del(id, obj){
		bootbox.confirm({
			message: "<h4>Are you sure that you want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
					type: "POST",
					url: APP_URL + "api/marketing/stock_out/delete.php",
					data: JSON.stringify({ id: id }),
					success: function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							getStockList();
						}else{
							bootbox.alert("Error on server side.");
						}
					}
					});
				}
			}
		});
	}

	function cre(){	
		var total_stock = $(OBJ).parent().find("td").eq(6).text();
		var stock_out_date = $("#txtDatePicker").val();
		var use = ($("#optUse").prop('checked'))?1:0;
		var lost = ($("#optLost").prop('checked'))?1:0;
		var damage = ($("#optDamage").prop('checked'))?1:0;
		var expire = ($("#optExpire").prop('checked'))?1:0;
		var item_id = $(OBJ).parent().find("td").eq(7).text();
		var item_name = $(OBJ).parent().find("td").eq(3).text();
		var quantity = $("#txtQuantity").val();
		var stock_out_by =$("#txtStockOutBy").val();
		var stock_out_receive_by =$("#txtReceiveBy").val();
		var remark =$("#txtRemark").val();
		
		if(OBJ==""){
			bootbox.alert("Please choose one item.");
		}else if(quantity==0){
			bootbox.alert("Please fill the quantity.");
		}else if(stock_out_by.trim()==""){
			bootbox.alert("Please fill the stock out by.");
		}else if(stock_out_receive_by.trim()==""){
			bootbox.alert("Please fill the receive by.");
		}else if(parseInt(quantity)>parseInt(total_stock)){
			bootbox.alert("Stockout quantity is execute!");
		}else{
			$.ajax({
				type: "POST",
				url: APP_URL + "api/marketing/stock_out/create.php",
				data: JSON.stringify({ stock_out_date: stock_out_date, use: use, lost: lost, damage: damage, expire: expire, item_id: item_id, item_name: item_name, quantity: quantity, stock_out_by: stock_out_by, stock_out_receive_by: stock_out_receive_by, remark: remark }),
				success: function(data){	
					if(data=="created"){
						bootbox.alert("Stockout success.");
						$("#frmEntry")[0].reset();
						$("#txtDatePicker").val(customDate);
						getStockList();
						fillGrid();
						OBJ = "";
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			}); 
		}		
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}
</script>
