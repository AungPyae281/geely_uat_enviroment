<?php include '../header.php'; ?>
<style>
	select {
		padding-top: 1px !important;
	}
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 89%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items-oc {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 100%;
		left: 0px;
		right: 0px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div, .autocomplete-items-oc div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover, .autocomplete-items-oc div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	} 
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Balance Sheet - Reports</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date From:</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDateFrom" type="checkbox" style="margin: 8px 0px" checked disabled>
												<label for="chkDateFrom"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" >
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">GL Code: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtGLCode">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Type: </label>
											<div class="col-md-7">
												<select class="form-control" id="cboType"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtName">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Category: </label>
											<div class="col-md-7">
												<select class="form-control" id="cboCategory"></select>
											</div>
										</div>
										<div class="form-group row">
				   							<div class="col-md-5"></div>
											<div class="col-md-3">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
				   						</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title"><span id="txtTitle">Summary</span> List<span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-bordered" id="myTable">
						<thead>
							<tr>
								<th style="width: 3%; text-align: center;">No.</th>
								<th style="width: 10%; text-align: center;">Type</th>
								<th style="width: 10%; text-align: center;">Category</th>
								<th style="width: 10%; text-align: center;">Gl Code</th>
								<th style="width: 15%; text-align: center;">Name</th>
								<th style="width: 12%; text-align: center;">date1</th>
								<th style="width: 12%; text-align: center;">date2</th>
								<th style="width: 12%; text-align: center;">date3</th>
								<th style="width: 12%; text-align: center;">date4</th>
								<th style="width: 12%; text-align: center;">date5</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var Action = '<?=$_SESSION["userrole"];?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
		$('#datePicker1').datepicker();
		getAllType();
		getCategoriesByType();
		search();
	});

	function getAllType(type, category){
		$("#cboType").find("option").remove();
		$("#cboType").append("<option value = '' data-id = ''></option>");
		$("#cboScboTypeubGroup").find("option").remove();
		$.ajax({
			url: APP_URL + "api/finance/gl_type/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.type==type){
					$("#cboType").append("<option value = '" + v.type + "' data-id = '" + v.id + "' selected>" + v.type + "</option>");
				}else{
					$("#cboType").append("<option value = '" + v.type + "' data-id = '" + v.id + "'>" + v.type + "</option>");
				}
			});
			getCategoriesByType(category);
		});
	}

	function getCategoriesByType(category){
		var type = $("#cboType").val();
		$("#cboCategory").find("option").remove();
		$("#cboCategory").append("<option value = ''></option>");

		$.ajax({
			url: APP_URL + "api/finance/gl_category/get_categories_by_type.php",
			type: "POST",
			data: JSON.stringify({ type: type })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				if(v.category==category){
					$("#cboCategory").append("<option value = '" + v.category + "' data-id = '" + v.id + "' selected>" + v.category + "</option>");
				}else{
					$("#cboCategory").append("<option value = '" + v.category + "' data-id = '" + v.id + "'>" + v.category + "</option>");
				}
			});
		});
	}

	$("#cboType").change(function(){
		getCategoriesByType();
	});

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$("#chkDateFrom").change(function() {
		if ($('#chkDateFrom').prop('checked')){
			$("#txtDatePicker1").prop("disabled", false);
			$("#txtDatePicker1").css("cursor", "pointer");
		}else{
			$("#txtDatePicker1").prop("disabled", true);
			$("#txtDatePicker1").val(customDate);
		}
	});

	$("#chkDateTo").change(function() {
		if ($('#chkDateTo').prop('checked')){
			$("#txtDatePicker2").prop("disabled", false);
			$("#txtDatePicker2").css("cursor", "pointer");
		}else{
			$("#txtDatePicker2").prop("disabled", true);
			$("#txtDatePicker2").val(customDate);
		}
	});

	function search(){
		$("#loading").css("display","block");
		var df = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker1").val():"";
		var type = $("#cboType").val();
		var category = $("#cboCategory").val();
		var gl_code = $("#txtGLCode").val();
		var name = $("#txtName").val();

		$("#myTable").find("thead").find("tr").remove();
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/finance/gl_account/get_balance_sheet.php",
			data: JSON.stringify({ df: df, type: type, category: category, gl_code: gl_code, name: name }),
			error: function(data) {
				$("#loading").css("display","none");
			}
		}).done(function(data) {	
			if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record found.");}
			$("#loading").css("display","none");

			$("#myTable").find("thead")
			.append($('<tr>')
				.append("<th style='width: 5%; text-align: center; padding-left: 0.75rem;'>No.</th>")
				.append("<th style='width: 9%;'>Type</th>")
				.append("<th style='width: 18%;'>Category</th>")
				.append("<th style='text-align: center;'>GL Code</th>")
				.append("<th style='text-align: center;'>Name</th>")
				.append("<th style='width: 10%;'>" + data.date1 + "</th>")
				.append("<th style='width: 10%;'>" + data.date2 + "</th>")
				.append("<th style='width: 10%;'>" + data.date3 + "</th>")
				.append("<th style='width: 10%;'>" + data.date4 + "</th>")
				.append("<th style='width: 10%;'>" + data.date5 + "</th>")
			);
			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i+1) + "</td>")
					.append("<td>" + v.type + "</td>")
					.append("<td>" + v.category + "</td>")
					.append("<td>" + v.gl_code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:blue;text-decoration:underline;' onclick='goToDetail(\"" + data.date1 + "\", \"" + v.gl_code + "\", \"" + v.category + "\", this)'>" + v.opening_balance1 + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:blue;text-decoration:underline;' onclick='goToDetail(\"" + data.date2 + "\", \"" + v.gl_code + "\", \"" + v.category + "\", this)'>" + v.opening_balance2 + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:blue;text-decoration:underline;' onclick='goToDetail(\"" + data.date3 + "\", \"" + v.gl_code + "\", \"" + v.category + "\", this)'>" + v.opening_balance3 + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:blue;text-decoration:underline;' onclick='goToDetail(\"" + data.date4 + "\", \"" + v.gl_code + "\", \"" + v.category + "\", this)'>" + v.opening_balance4 + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:blue;text-decoration:underline;' onclick='goToDetail(\"" + data.date5 + "\", \"" + v.gl_code + "\", \"" + v.category + "\", this)'>" + v.opening_balance5 + "</a></td>")
				);
			});
       });
	}

	function goToDetail(date, gl_code, category, obj){
		var d_str = date.split('-', 1) + "-01-01" ;
		window.open("<?=$app_url;?>reports/balance_sheet_detail.php?act=detail&df=" + d_str + "&dt=" + date + "&gl=" + gl_code + "&cat=" + category, "_blank");
	}
</script>	
