<?php include '../header.php'; ?>
<style>
	select {
		padding-top: 1px !important;
	}
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 89%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items-oc {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 100%;
		left: 0px;
		right: 0px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div, .autocomplete-items-oc div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover, .autocomplete-items-oc div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	} 
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>General Ledger - Reports</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date From:</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDateFrom" type="checkbox" style="margin: 8px 0px">
												<label for="chkDateFrom"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" disabled>
												</div>
											</div>
										</div>										
									</div>
									<div class="col-md-4">
										<!-- <div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Payment Voucher No.: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtVoucherNo">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Receive No.: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtReceiveNo">
											</div>
										</div> -->

										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date To: </label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDateTo" type="checkbox" style="margin: 8px 0px">
												<label for="chkDateTo"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" disabled>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<!-- <div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Expense By: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtExpenseBy">
											</div>
										</div>
										<div class="form-group row">
				   							<label class="col-md-5 col-form-label" style="text-align: right; padding-top: 0px;"></label>
				   							<div class="col-md-7">
			   									<div class="radio" style="padding-top: 2px;">
													<label class="col-md-5" style="padding-left: 0px;">
														<input value="summary" id="optSummary" name="optstatus" type="radio" checked="checked">
														Summary
													</label>
													<label class="col-md-5" style="padding-left: 0px;">
														<input value="detail" id="optDetail" name="optstatus" type="radio">
														Detail
													</label>
												</div>
											</div>
				   						</div> -->
				   						<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">GL Account:</label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<select type="text" class="form-control" id="cboGLAccount">
                                                </select>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-5"></div>
											<div class="col-md-3">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">List<span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-bordered" id="myTable">
						<thead>
							<tr>
								<th style="width: 5%; text-align: center;">No.</th>
								<th style="width: 10%; text-align: center;">Date</th>
								<th style="width: 10%; text-align: center;">GL Code</th>
								<th style="text-align: center;">Name</th>
								<th style="text-align: center;">Description</th>
								<th style="width: 15%; text-align: center;">Debit</th>
								<th style="width: 15%; text-align: center;">Credit</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var Action = '<?=$_SESSION["userrole"];?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker();
		getAllGLAccount();
	});

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$("#chkDateFrom").change(function() {
		if ($('#chkDateFrom').prop('checked')){
			$("#txtDatePicker1").prop("disabled", false);
			$("#txtDatePicker1").css("cursor", "pointer");
		}else{
			$("#txtDatePicker1").prop("disabled", true);
			$("#txtDatePicker1").val(customDate);
		}
	});

	$("#chkDateTo").change(function() {
		if ($('#chkDateTo').prop('checked')){
			$("#txtDatePicker2").prop("disabled", false);
			$("#txtDatePicker2").css("cursor", "pointer");
		}else{
			$("#txtDatePicker2").prop("disabled", true);
			$("#txtDatePicker2").val(customDate);
		}
	});

	function getAllGLAccount(){
		$("#cboGLAccount").find("option").remove();
		// $("#cboGLAccount").append("<option value = ''></option>");

		$.ajax({
			url: APP_URL + "api/finance/gl_account/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ type: '', category: '' })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#cboGLAccount").append("<option value = '" + v.gl_code + "' data-id = '" + v.id + "'>" + v.gl_code + "</option>");
			});
		});
	}

	function search(){
		$("#loading").css("display","block");
		var df = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker1").val():"";
		var dt = ($("#chkDateTo").prop("checked"))?$("#txtDatePicker2").val():"";
		var gl_code = $("#cboGLAccount option:selected").val();

		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/finance/gl_account/get_general_ledger.php",
			data: JSON.stringify({ df: df, dt: dt, gl_code: gl_code }),
			error: function(data) {
				$("#loading").css("display","none");
			}
		}).done(function(data) {	
			if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record found.");}
			$("#loading").css("display","none");
			var total_debit = 0;
			var total_credit = 0;

			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i+1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.gl_code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td>" + v.description + "</td>")
					.append("<td style='text-align:right;'>" + (v.debit).toLocaleString() + "</td>")
					.append("<td style='text-align:right;'>" + (v.credit).toLocaleString() + "</td>")
				);
				total_debit += (parseInt(v.debit.replace(/,/g, '')));
				total_credit += (parseInt(v.credit.replace(/,/g, '')));
			});
		    $("#myTable").find("tbody")
			.append($('<tr style="font-weight:bold; font-size: 19px;">')
				.append("<td colspan='5' style='text-align:right;'>Total:</td>")
				.append("<td style='text-align:right; padding-right: 12px !important;'>" + (total_debit).toLocaleString() + "</td>")
				.append("<td style='text-align:right; padding-right: 12px !important;'>" + (total_credit).toLocaleString() + "</td>")
			);  
		    // $("#myTable").find("tbody")
			// .append($('<tr style="font-weight:bold; font-size: 19px;">')
			// 	.append("<td colspan='5' style='text-align:right;'>Difference:</td>")
			// 	.append("<td style='text-align:right; padding-right: 12px !important;'></td>")
			// 	.append("<td style='text-align:right; padding-right: 12px !important;'>" + (total_debit - total_credit).toLocaleString() + "</td>")
			// );  
       });
	}
</script>	
