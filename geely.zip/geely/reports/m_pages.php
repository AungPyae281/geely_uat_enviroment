<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1 class="pageTitleGeely">Pages - Report</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Year:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboYears">
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Pages:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboPages"></select>
											</div>
										</div>
									</div>
									<div class="col-md-6"></div>
									<div class="col-md-6">
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>

					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"></span></h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div>
						</div>
						<div class="card-body p-0">
							<table class="table table-striped table-responsive table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Page Name</th>
										<th>Category</th>
										<th>Jan</th>
										<th>Feb</th>
										<th>Mar</th>
										<th>Apr</th>
										<th>May</th>
										<th>Jun</th>
										<th>Jul</th>
										<th>Aug</th>
										<th>Sep</th>
										<th>Oct</th>
										<th>Nov</th>
										<th>Dec</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
			
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	var yyyy = d.getFullYear();

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$("#cboYears option[data-select='" + yyyy +"']").attr("selected","selected");
		// fillMonth();
		fillPages();
		fillNumbers();
	});	

	function fillNumbers(){
		var yy = d.getFullYear();
		// $("#cboYears").append("<option value= ''>Year</option>");
		for (var i = yy; i >= 1940; i--){
			$("#cboYears").append("<option value= '" + i + "'>" + i + "</option>");
		}
	}

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	function fillMonth(){
		for(var i = 11; i<17; i++){
			var d = new Date();
			d.setMonth(d.getMonth() -i);
			var mm = (d.getMonth("MM")+1);
			$("#cboYears").append("<option value= '" + d.getFullYear() + "'>" + d.getFullYear() + "</option>");
		}
		changeHeader();
	} 

	function fillPages(dp){
	   $("#cboPages").find("option").remove();
	   $("#cboPages").append("<option value = '' data-code = ''></option>");
	   $.ajax({
	      url: APP_URL + "api/marketing/pages/get_all_rows.php"
	   }).done(function(data) {   
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' selected>" + v.name + "</option>");
	         }else{
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	function search(){
		$("#loading").css("display","block");
		var year = $("#cboYears").val() + "%";
		var page_name = $("#cboPages").val();

		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/marketing/target_pages/search.php",
			data: JSON.stringify({ year: year, page_name: page_name })
		}).done(function(data) {	
			console.log(data);
			$.each(data.records, function(i, v) {
				var feb_percent = Math.ceil(((v.february-v.january)/v.january)*100);
				feb_percent = isNaN(feb_percent) ? 0 : feb_percent;
				var mar_percent = Math.ceil(((v.march-v.february)/v.february)*100);
				mar_percent = isNaN(mar_percent) ? 0 : mar_percent;
				var apr_percent = Math.ceil(((v.april-v.march)/v.march)*100);
				apr_percent = isNaN(apr_percent) ? 0 : apr_percent;
				var may_percent = Math.ceil(((v.may-v.april)/v.april)*100);
				may_percent = isNaN(may_percent) ? 0 : may_percent;
				var jun_percent = Math.ceil(((v.jun-v.may)/v.may)*100);
				jun_percent = isNaN(jun_percent) ? 0 : jun_percent;
				var jul_percent = Math.ceil(((v.july-v.jun)/v.jun)*100);
				jul_percent = isNaN(jul_percent) ? 0 : jul_percent;
				var aug_percent = Math.ceil(((v.august-v.july)/v.july)*100);
				aug_percent = isNaN(aug_percent) ? 0 : aug_percent;
				var sep_percent = Math.ceil(((v.september-v.august)/v.august)*100);
				sep_percent = isNaN(sep_percent) ? 0 : sep_percent;
				var oct_percent = Math.ceil(((v.october-v.september)/v.september)*100);
				oct_percent = isNaN(oct_percent) ? 0 : oct_percent;
				var nov_percent = Math.ceil(((v.november-v.october)/v.october)*100);
				nov_percent = isNaN(nov_percent) ? 0 : nov_percent;
				var dec_percent = Math.ceil(((v.december-v.november)/v.november)*100);
				dec_percent = isNaN(dec_percent) ? 0 : dec_percent;
				if(data.records.length>0){
					$("#myTable").find("tbody")
					.append($('<tr>')
						.append("<td >" + (i+1) + "</td>")
						.append("<td >" + v.name + "</td>")
						.append("<td >" + "No. of " + v.reason + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.january + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.february + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.march + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.april + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.may + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.june + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.july + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.august + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.september + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.october + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.november + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + v.december + "</td>")
					)
					.append($('<tr>')
						.append("<td ></td>")
						.append("<td ></td>")
						.append("<td >" + "Increase %" + "</td>")
						.append("<td style='font-weight: bold; text-align: right;'></td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + feb_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + mar_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + apr_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + may_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + jun_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + jul_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + aug_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + sep_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + oct_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + nov_percent + "%</td>")
						.append("<td style='font-weight: bold; text-align: right;'>" + dec_percent + "%</td>")
					)
				}
				$("#loading").css("display","none");
			});
       });
	}	
</script>
