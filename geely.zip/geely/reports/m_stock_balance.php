<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1 class="pageTitleGeely">Stock Balance - Reports</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Brand:</label>
											<div class="col-md-8">  
												<select class="form-control" id="cboType" name="type" >
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Category:</label>
											<div class="col-md-8">  
												<select class="form-control" id="cboCategory" name="category" >
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Item Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Stock Balance</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkQty" type="checkbox" style="margin: 8px 0px">
												<label for="chkQty">:</label>
											</div>
											<div class="col-md-3">
												<input id="txtQuantityFrom" name="name" class="form-control  pull-left" type="text" maxlength="4" onkeypress="return isNumber(event)" onkeyup="btozero(this);" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2"> 
												<select class="form-control form-control" id="cboSign" name="title" onchange="sign()">
													<option value="=">=</option>
													<option value="<">&lt;</option>
													<option value=">">&gt;</option>
													<option value="between">between</option>
												</select> 
											</div>
											<div class="col-md-3">
												<input id="txtQuantityTo" name="name" class="form-control pull-right" type="text" maxlength="4" onkeypress="return isNumber(event)" onkeyup="btozero(this);" value="0" style="text-align:right;" disabled="">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Stock Balance List<span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">No.</th>
							<th style="width: 15%">Type</th>
							<th style="width: 15%">Category</th>
							<th>Item Name</th>
							<th style="width: 5%">Quantity</th>
							<th style="width: 15%">Capital Price</th>
							<th style="width: 15%">Amount</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>

	$(function(){
		$("body").addClass("sidebar-collapse");

		$("#btnExport").click(function (e) {
			tableToExcel("myTable", "StockBalance");
		});
		fillCategory();
		fillType();
	});


	function fillCategory(){
		$("#cboCategory").find("option").remove();
		$("#cboCategory").append("<option value = '' data-id = ''>All</option>");
		$.ajax({
			url: APP_URL + "api/marketing/category/get_all_rows.php"
		}).done(function(data) {
			console.log(data);
			$.each(data.records, function(i, v) {
				console.log(v);
				$("#cboCategory").append("<option value= '" + v.category + "' data-id = '"+ v.id +"' >" + v.category + "</option>");
			});
		});
	}

	function fillType(){
		$("#cboType").find("option").remove();
		$("#cboType").append("<option value = '' data-id = ''>All</option>");
		$.ajax({
			url: APP_URL + "api/marketing/type/get_all_rows.php",
			type: "POST"
		}).done(function(data) {
			console.log(data);
			$.each(data.records, function(i, v) {
				$("#cboType").append("<option value= '" + v.type + "' data-id = '"+ v.id +"' >" + v.type + "</option>");
			});
		});
	}


	function search(){
		$("#loading").css("display","block");
		var item_name = $("#txtItemName").val();
		var category = $("#cboCategory").val();
		var type = $("#cboType").val();
		var qtyfrom = $("#txtQuantityFrom").val();
		var qtyto = $("#txtQuantityTo").val();
		var sign = $("#cboSign").val();
		var chk_qty = ($("#chkQty").prop("checked"))?1:2;
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/marketing/stock_balance/search.php",
			data: JSON.stringify({ chk_qty: chk_qty, qtyfrom: qtyfrom, qtyto: qtyto, category: category, type:type, item_name:item_name, sign: sign }),
			error: function(data) {
				$("#loading").css("display","none");
			}
		}).done(function(data) {
			$("#loading").css("display","none");
			console.log(data.records.length);
			$("#myTable").find("tbody").find("tr").remove();
			if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record(s) found.");}
			$.each(data.records, function(i, v) {
				console.log(v);
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i+1) + "</td>")
					.append("<td>" + v.type + "</td>")
					.append("<td>" + v.category + "</td>")
					.append("<td>" + v.item_name + "</td>")
					.append("<td style='text-align:right;'>" + (v.quantity).toLocaleString() + "</td>")
					.append("<td style='text-align:right;'>" + v.capital_price + "</td>")
					.append("<td style='text-align:right;'>" + v.amount + "</td>")
				)
			});
			if(data.total_amount){
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td colspan='6' style='font-weight: bold; text-align: right;'>Total Amount:</td>")
					.append("<td style='font-weight: bold; text-align: right;'>" + data.total_amount + "</td>")
				)
			}
		});
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function sign(){
		if(($("#cboSign").val()) == "between"){
			$("#txtQuantityTo").prop('disabled', false);
		}else{
			$("#txtQuantityTo").val("0");
			$("#txtQuantityTo").prop('disabled', true);
		};
	}
	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});
</script>