<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1 class="pageTitleGeely">Stock In - Report</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date From: </label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-17" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date To: </label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-17" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15">
												</div>
											</div>
										</div>
									</div>
					                <div class="col-md-6">
					                	<div class="form-group row">
					                		<label class="col-md-4 col-form-label" style="text-align: right;">Item Name: </label>
					                		<div class="col-md-8">
					                			<input type="text" class="form-control" id="txtItemName">
					                		</div>
					                	</div>
					                </div>
					                <div class="col-md-6">
					                	<div class="form-group row">
					                		<label class="col-md-4 col-form-label" style="text-align: right;">Stock In By: </label>
					                		<div class="col-md-8">
					                			<input type="text" class="form-control" id="txtBy">
					                		</div>
					                	</div>
					                </div>
					                <div class="col-md-6"></div>
					                <div class="col-md-6">
					                	<div class="form-group row">
					                		<div class="col-md-4"></div>
					                		<div class="col-md-4">
					                			<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
					                		</div>
					                		<div class="col-md-4">
					                			<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
					                		</div>
					                	</div>
					                </div>
					            </div>
					        </div>
					    </form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Stock In List<span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">No.</th>
								<th>Date</th>
								<th>Type </th>
								<th>Category </th>
								<th>Item Name </th>
								<th>Stock In By</th>
								<th>Receive By</th>
								<th>Quantity</th>
								<th>Price</th>
								<th>Amount </th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker();
	});

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	function search(){
		$("#loading").css("display","block");
		var df = $("#txtDatePicker1").val();
		var dt = $("#txtDatePicker2").val();
		var item_name = $("#txtItemName").val();
		var stock_in_by = $("#txtBy").val();
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/marketing/stock_in/search.php",
			data: JSON.stringify({ df: df, dt:dt, item_name:item_name, stock_in_by:stock_in_by }),
			error: function(data) {
				$("#loading").css("display","none");
			}
		}).done(function(data) {
           if(data.records){$("#total_records").text(" - " + data.records.length + " records");}else{$("#total_records").text(0 + " record(s) found.");}
           $("#loading").css("display","none");
           $.each(data.records, function(i, v) {
           	console.log(v);
           	$("#myTable").find("tbody")
           	.append($('<tr>')
           		.append("<td>" + (i+1) + "</td>")
           		.append("<td>" + v.stock_in_date + "</td>")
           		.append("<td>" + v.type + "</td>")
           		.append("<td>" + v.category + "</td>")
           		.append("<td>" + v.item_name + "</td>")
           		.append("<td>" + v.stock_in_by + "</td>")
           		.append("<td>" + v.stock_in_receive_by + "</td>")
           		.append("<td style='text-align:right;'>" + parseInt(v.quantity).toLocaleString() + "</td>")
           		.append("<td style='text-align:right;'>" + parseInt(v.price).toLocaleString() + "</td>")
           		.append("<td style='text-align:right;'>" + parseInt(v.quantity * v.price).toLocaleString() + "</td>")
           		// .append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='del(" + v.id + ",this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
           		)
           });
       });
	}

	function del(id,obj){
		bootbox.confirm({
			message: "<h4>Are you sure that you want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
					type: "POST",
					url: APP_URL + "api/marketing/stock_in/delete.php",
					data: JSON.stringify({ id: id }),
					success: function(data){
						if(data=="deleted"){
							$(obj).parent().parent().remove();
							// getStockList();
						}else{
							bootbox.alert("Error on server side.");
						}
					}
					});
				}
			}
		});
	}
</script>	
