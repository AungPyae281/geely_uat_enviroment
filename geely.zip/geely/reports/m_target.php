<?php include '../header.php'; ?>
<style>
	.displaY{
		display: none;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1 class="pageTitleGeely">Target - Report</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6" hidden>
										<div class="form-group row" >
											<label class="col-md-4 col-form-label" style="text-align: right;">Pages:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboPages"></select>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Target Name:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtName" disabled>
												<input type="text" class="form-control" id="txtMonthFrom" hidden>
												<input type="text" class="form-control" id="txtMonthTo" hidden>
												<input type="text" class="form-control" id="txtPageID" hidden>												
											</div>
											<div class="col-md-1" style="padding-left: 0px;">
												<span class="input-group-btn">
													<button type="button" class="btn btn-success" onclick="getAllTargetName();" id="btnName" style="padding-left: 10px;">. . .</button>
												</span>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>

					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"></span></h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div>
						</div>
						<div class="card-body p-0">
							<table class="table table-striped table-responsive table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Tgt. Name</th>
										<th>Page Name</th>
										<th>Month From</th>
										<th>Month To</th>
										<th>Tgt. Like</th>
										<th>Act. Like</th>
										<th>Ach. Like (%)</th>
										<th>Tgt. Reach</th>
										<th>Act. Reach</th>
										<th>Ach. Reach (%)</th>
										<th>Tgt. Engagement</th>
										<th>Act. Engagement</th>
										<th>Ach. Engagement (%)</th>
										<th>Tgt. Booking</th>
										<th>Act. Booking</th>
										<th>Ach. Booking (%)</th>
										<th>Tgt. Lead</th>
										<th>Act. Lead</th>
										<th>Ach. Lead (%)</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>

					<center>
						<div class="modal fade" id="myModalTargetName">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 40%;top: 29px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Target List</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table class="table table-head-fixed" id="myTable1" style="cursor:pointer;">
											<thead>                  
												<tr>
													<th>Name</th>
													<th>Month From</th>
													<th>Month To</th>
													<th style="display:none;">Page ID</th>
													<th style="display:none;">ID</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</center>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	var yyyy = d.getFullYear();

	$(function(){
		$("body").addClass("sidebar-collapse");	
		fillPages();
	});	

	function getAllTargetName(){
		$("#myModalTargetName").modal('show');
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/marketing/target/get_all_target.php",
			"columnDefs": [
				{
					'targets': [3, 4],
					"className": 'displaY'
				}
			]
		});	
	}

	$('#myTable1').on('click', 'tbody tr', function(e){ 
		$("#myTable1 tbody tr").css("color", "");
		$("#myTable1 tbody tr").css("background-color", "");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtName").val($(this).find("td").eq(0).text());
		$("#txtMonthFrom").val($(this).find("td").eq(1).text());
		$("#txtMonthTo").val($(this).find("td").eq(2).text());
		$("#txtPageID").val($(this).find("td").eq(3).text());
		$("#myModalTargetName").modal('hide');
	});

	function fillNumbers(){
		var yy = d.getFullYear();
		// $("#cboYears").append("<option value= ''>Year</option>");
		for (var i = yy; i >= 1940; i--){
			$("#cboYears").append("<option value= '" + i + "'>" + i + "</option>");
		}
	}

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	function fillMonth(){
		for(var i = 11; i<17; i++){
			var d = new Date();
			d.setMonth(d.getMonth() -i);
			var mm = (d.getMonth("MM")+1);
			$("#cboYears").append("<option value= '" + d.getFullYear() + "'>" + d.getFullYear() + "</option>");
		}
		changeHeader();
	} 

	function fillPages(dp){
	   $("#cboPages").find("option").remove();
	   $("#cboPages").append("<option value = '' data-code = ''></option>");
	   $.ajax({
	      url: APP_URL + "api/marketing/pages/get_all_rows.php"
	   }).done(function(data) {   
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' selected>" + v.name + "</option>");
	         }else{
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	function search(){
		$("#loading").css("display","block");
		var name = $("#txtName").val();
		var month_from = $("#txtMonthFrom").val();
		var month_to = $("#txtMonthTo").val();

		if(name==""){
			bootbox.alert("Please select one target name.");
			$("#loading").css("display","none");
			return false;
		}else{
			$("#myTable").find("tbody").find("tr").remove();
			$.ajax({
				type: "POST",
				url: APP_URL + "api/marketing/target/search.php",
				data: JSON.stringify({ name: name, month_from: month_from , month_to: month_to })
			}).done(function(data) {	
				console.log(data);
				$.each(data.records, function(i, v) {
					if(data.records.length>0){
						$("#myTable").find("tbody")
						.append($('<tr>')
							.append("<td >" + (i+1) + "</td>")
							.append("<td >" + v.target_name + "</td>")
							.append("<td >" + v.page_name + "</td>")
							.append("<td >" + v.month_from + "</td>")
							.append("<td >" + v.month_to + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.target_like + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.total_like + "</td>")
							.append("<td style='font-weight: bold; text-align: right;color: red;'>" + v.ach_like + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.target_reach + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.total_reach + "</td>")
							.append("<td style='font-weight: bold; text-align: right;color: red;'>" + v.ach_reach + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.target_engagement + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.total_engagement + "</td>")
							.append("<td style='font-weight: bold; text-align: right;color: red;'>" + v.ach_engagement + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.target_booking + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.total_booking + "</td>")
							.append("<td style='font-weight: bold; text-align: right;color: red;'>" + v.ach_booking + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.target_lead + "</td>")
							.append("<td style='font-weight: bold; text-align: right;'>" + v.total_lead + "</td>")
							.append("<td style='font-weight: bold; text-align: right;color: red;'>" + v.ach_lead + "</td>")
						)
					}
					$("#loading").css("display","none");
				});
	       });
		}
	}	
</script>
