<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    } 
    /*[class*="sidebar-dark-"] .nav-sidebar > .nav-item > .nav-link:active {
      color: #fff;
      background-color: #10649c;
    }*/
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Ford Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Ford Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-user"></i>
                        <p>Admin <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item"><a href="<?=$app_url;?>admin/userrolelist.php" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>User Role</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>admin/userlist.php" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>User Account</p></a></li> 

                        <li class="nav-item"><a href="<?=$app_url;?>admin/changepassword.php" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Change Password</p></a></li> 

                        <li class="nav-item"><a href="<?=$app_url;?>admin/broker.php" data="Broker|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Broker</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>admin/brand.php" data="Brand|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Brand</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>admin/model.php" data="Model|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Model</p></a></li>
                    </ul>
                </li>  
                 
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-plus-circle"></i>
                        <p>Entry <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>entry/grade.php" data="New Model|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Grade</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>entry/car_list.php" data="Car List|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Car List</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>entry/test_drive_car.php" data="Test Drive Car|110100" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Test Drive Car</p></a></li>
                    </ul>
                </li> 

               <!--  <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-screwdriver"></i>
                        <p>Spareparts <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/group.php" data="Group|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Group</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/sub_group.php" data="Sub Group|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Sub Group</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts.php" data="Spareparts|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Spareparts</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/store.php" data="Store|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Store</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/sub_store.php" data="Sub Store|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Sub Store</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/service_center_store.php" data="Service Center Store|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Service Center Store</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts_store_stock_level.php" data="Store Stock Level|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Store Stock Level</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts_waiting_list.php" data="Spareparts Waiting List|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Waiting List</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts_order.php" data="Spareparts Order|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Order</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts_receiving.php" data="Spareparts Receiving|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Receiving</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>spareparts/spareparts_receive_list.php" data="Spareparts Receiving|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Receiving List</p></a></li>
                    </ul>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-wrench"></i>
                        <p>Services <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview"> 
                        <li class="nav-item"><a href="<?=$app_url;?>services/service_item.php" data="Service Item|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Item</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_item_task.php" data="Service Item Task|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Item Task</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_package.php" data="Service Package|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Package</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_center_bay.php" data="Service Center Bay|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Center Bay</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_bay_services.php" data="Service Bay Services|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Bay Services</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_promotion.php" data="Service Promotion|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Promotion</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_customer.php" data="Service Customer|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Customer</p></a></li>

                        <li class="nav-item"><a href="<?=$app_url;?>services/service_appointment.php" data="Service Appointment|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Appointment</p></a></li>
                    </ul>
                </li> --> 

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-users"></i>
                        <p>HR <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>hr/department.php" data="Department|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Department</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>hr/position.php" data="Position|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Position</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>hr/staff.php" data="Staff|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Staff</p></a></li>
                    </ul>
                </li> 

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-dollar-sign"></i>
                        <p>Price Change <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>sales/car_price.php" data="Car Price|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Car Price</p></a></li>
                       <li class="nav-item"><a href="<?=$app_url;?>sales/rtad_tax_change.php" data="RTAD Tax|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>RTAD Tax</p></a></li>
                    </ul>
                </li> 

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-solid fa-coins"></i>
                        <p>Finance <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview"> 
                        <li class="nav-item"><a href="<?=$app_url;?>finance/bank_account.php" data="Bank Account|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Bank Account</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>finance/currency_exchange.php" data="Currency Exchange|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Currency Exchange</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>finance/request_form.php" data="Request Form|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Request Form</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>finance/bank_account_transaction.php" data="Bank Account Transaction|111000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Bank Account Transaction</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>finance/price_change_approval.php" data="Price Change Approval|011000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Price Change Approval</p></a></li>
                    </ul>
                </li>
                
                 <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-percent"></i>
                        <p>Payment Config <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>payment_config/promotion.php" data="Promotion|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Promotion</p></a></li>
                    </ul>
                </li> 
				<!--<li class="nav-item">
					<a href="<?=$app_url;?>entry/promotion.php" class="nav-link">
						<i class="fas fa-money-bill-alt nav-icon"></i> <p>Promotion</p>
					</a>
				</li>
				
				<li class="nav-item">
					<a href="<?=$app_url;?>entry/define_payment_term.php" class="nav-link">
						<i class="fas fa-money-bill-alt nav-icon"></i> <p>Define - Payment Term</p>
					</a>
				</li>


				<li class="nav-item">
					<a href="<?=$app_url;?>entry/car.php" class="nav-link">
						<i class="fas fa-car nav-icon"></i> <p>Car</p>
					</a>
                </li>
				<li class="nav-item">
					<a href="<?=$app_url;?>entry/car_list.php" class="nav-link">
						<i class="fas fa-clipboard-list nav-icon"></i> <p>Car List</p>
					</a>
				</li>

				<li class="nav-item">
					<a href="<?=$app_url;?>entry/broker.php" class="nav-link">
						<i class="fas fa-user nav-icon"></i> <p>Broker</p>
					</a>
				</li>
				-->
				<li class="nav-item">
					<a href="<?=$app_url;?>marketing/customer_list.php" data="Customer Detail|110000" class="nav-link nav-link-treeview">
						<i class="fas fa-address-book nav-icon"></i> <p>Customer List</p>
					</a>
				</li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>test_drive/test_drive_booking_list.php" data="Test Drive Booking List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Test Drive Booking List</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>test_drive/test_drive_result_list.php" data="Test Drive Result List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Test Drive Result List</p>
                    </a>
                </li>
				<li class="nav-item">
					<a href="<?=$app_url;?>order/order_processing_list.php" data="Order Detail|011000" class="nav-link nav-link-treeview">
						<i class="fas fa-clipboard-list nav-icon"></i> <p>Order Processing List</p>
					</a>
				</li>
				
				
				<li class="nav-item">
					<a href="<?=$app_url;?>sales/sales_list.php" data="1. Sales List|010000" class="nav-link nav-link-treeview">
						<i class="fas fa-clipboard-list nav-icon"></i> <p>Sales Processing List</p>
					</a>
				</li>
               <!--  <li class="nav-item">
                    <a href="<?=$app_url;?>services/service_appointment_list.php" data="Service Appointment List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Service Appointment List</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?=$app_url;?>services/servicing_list.php" data="Servicing List|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Servicing List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>spareparts/sp_waiting_lists.php" data="Spareparts Waiting Lists|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i> <p>Spareparts Waiting List</p>
                    </a>
                </li> -->
				<!--
				<li class="nav-item">
					<a href="<?=$app_url;?>entry/quotation_list.php" class="nav-link">
						<i class="fas fa-clipboard-list nav-icon"></i> <p>Quotation List</p>
					</a>
				</li>

				<li class="nav-item">
					<a href="<?=$app_url;?>entry/test_drive_booking_list.php" class="nav-link">
						<i class="fas fa-calendar-check nav-icon"></i> <p>Test Drive Booking List</p>
					</a>
				</li>

				<li class="nav-item">
					<a href="<?=$app_url;?>entry/test_drive_result_list.php" class="nav-link">
						<i class="fas fa-poll nav-icon"></i> <p>Test Drive Result List</p>
					</a>
				</li>
				-->
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-car"></i> <p>Order <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>logistic/production_order.php" data="Production Order|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Production Order</p></a></li>
                    </ul>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>logistic/define_price_production_car.php" data="Change Vehicle Order Price|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Change Vehicle Order Price</p></a></li>
                    </ul>
                </li>
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-truck"></i> <p>Inventory <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item"><a href="<?=$app_url;?>logistic/car_stock.php" data="Car Stock|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Stock In (Car)</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>logistic/supply_chain.php" data="Supply Chain Transfer|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Supply Chain (Car)</p></a></li>
                        <li class="nav-item"><a href="<?=$app_url;?>logistic/car_stock_transfer.php" data="Car Stock Transfer|100000" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Stock Transfer (Car)</p></a></li>
                    </ul>
                </li>
				
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fa fa-chart-bar"></i> <p>Reports <i class="fas fa-angle-left right"></i></p>
					</a>
					<ul class="nav nav-treeview">   
						<li class="nav-item">
                            <li class="nav-item"><a href="<?=$app_url;?>reports/employee.php" data="Employee Report|111111" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Employee</p></a></li>
                            <li class="nav-item"><a href="<?=$app_url;?>reports/service_customer.php" data="Service Customer Report|010010" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Service Customer</p></a></li>
                            <li class="nav-item"><a href="<?=$app_url;?>reports/service_appointment.php" data="Service Appointment Report|010010" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Service Appointment</p></a></li>
                            <li class="nav-item"><a href="<?=$app_url;?>reports/spareparts.php" data="Spareparts Report|010010" class="nav-link nav-link-treeview"><i class="far fa-folder nav-icon"></i><p>Spareparts</p></a></li>
						</li>
                    </ul>
                </li>
				
            </ul>
        </nav>
    </div>
</aside>     