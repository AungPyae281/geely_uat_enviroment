<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    }  
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Geely Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Geely Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>admin/userrolelist.php" data="Userrole|010100" data-key class="nav-link nav-link-treeview">
                        <i class="fa fa-user nav-icon"></i>
                        <p>User Role</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>admin/userlist.php" data="User Define|010100" data-key class="nav-link nav-link-treeview">
                        <i class="fa fa-users nav-icon"></i>
                        <p>User Account</p>
                    </a>
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>admin/due_date_setting.php" data="Due Date Setting|011000" data-key class="nav-link nav-link-treeview">
                        <i class="fa fa-cog nav-icon"></i>
                        <p>Due Date Setting</p>
                    </a>
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>admin/route.php" data-key class="nav-link nav-link-treeview">
                        <i class="fa fa-cog nav-icon"></i>
                        <p>Route</p>
                    </a>
                </li> 
				
            </ul>
        </nav>
    </div>
</aside>     