<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    }  
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Geely Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Geely Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-plus-circle"></i>
                        <p>Entry <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/gl_type.php" data="G/L Type|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>G/L Type</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/gl_category.php" data="G/L Category|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>G/L Category</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/exchange_rate.php" data="Exchange Rate|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Exchange Rate</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/gl_account.php" data="G/L Account|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>G/L Account</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/bank_account.php" data="Bank Account|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Bank Account</p>
                            </a>
                        </li> 

                       <!--  <li class="nav-item">
                            <a href="<?=$app_url;?>finance/purchase_price.php" data="Purchase Price|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Purchase Price</p>
                            </a>
                        </li> -->

                      <!--   <li class="nav-item">
                            <a href="<?=$app_url;?>finance/income.php" data="Income|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Income</p>
                            </a>
                        </li> -->

                      <!--   <li class="nav-item">
                            <a href="<?=$app_url;?>finance/advance_receipt.php" data="Advance Receipt|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Advance Receipt</p>
                            </a>
                        </li> -->
                    </ul>
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/income.php" data="Income|100000" class="nav-link nav-link-treeview">
                        <i class="fa fa-money-check nav-icon"></i>
                        <p>Income</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/journal.php" data="Journal|100000" class="nav-link nav-link-treeview">
                        <i class="fa fa-file-invoice-dollar nav-icon"></i>
                        <p>Journal Entry</p>
                    </a>
                </li>   

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/advance_receipt.php" data="Advance Receipt|100000" class="nav-link nav-link-treeview">
                        <i class="fa fa-file-invoice-dollar nav-icon"></i>
                        <p>Advance Receipt</p>
                    </a>
                </li>

                <!-- <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-plus-circle"></i>
                        <p>Advance <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/advance_staff.php" data="Advance - Staff Entry|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Advance - Staff</p>
                            </a>
                        </li>

                         <li class="nav-item">
                            <a href="<?=$app_url;?>finance/advance_supplier.php" data="Advance - Supplier Entry|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Advance - Supplier</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/advance_claim.php" data="Advance Claim|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Advance Claim</p>
                            </a>
                        </li>
                    </ul>
                </li> -->
                
                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/account_transfer.php" data="Account Transfer|100000" class="nav-link nav-link-treeview">
                        <i class="far fa-folder nav-icon" data-custom="sub"></i>
                        <p>Account Transfer</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/bank_account_transfer.php" data="Bank Account Transfer|110000" class="nav-link nav-link-treeview">
                        <i class="fa fa-landmark nav-icon"></i>
                        <p>Bank Account Transfer</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/account_balance.php" data="Account Balance|010000" class="nav-link nav-link-treeview">
                        <i class="fa fa-receipt nav-icon"></i>
                        <p>Account - Balance</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/sparepart_pre_order_list.php" data="Pre Order List|010000" class="nav-link nav-link-treeview">
                        <i class="fa fa-shopping-cart nav-icon"></i>
                        <p>Sparepart Pre Order</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/servicing_list.php" data="Servicing List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Servicing List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/deposit_settlement_list.php" data="Deposit Settlement List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-invoice nav-icon"></i>
                        <p>Deposit Settlement List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/requisition_list.php" data="Requisition List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-invoice nav-icon"></i>
                        <p>Requisition List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/expense.php" data="Expense|100000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-invoice nav-icon"></i>
                        <p>Expense</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>finance/invoices.php" data="Invoices|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-invoice nav-icon"></i>
                        <p>Invoices</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-dollar-sign"></i>
                        <p>Price Change <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/rtad_tax_change.php" data="RTAD Tax|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>RTAD Tax</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/define_price_production_car.php" data="Define Purchase Price|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Define Purchase Price</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>finance/car_price.php" data="Car Price|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Car Price</p>
                            </a>
                        </li>
                    </ul>                     
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/order_processing_list.php" data="Order Detail|011000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Order Processing List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/sales_list.php" data="1. Sales List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Sales Processing List</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-chart-bar"></i> <p>Reports <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/car_stock.php" data="Car Stock Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Car Stock</p>
                                </a>
                                <a href="<?=$app_url;?>reports/sales_finance.php" data="Sales Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Sales</p>
                                </a>
                                <a href="<?=$app_url;?>reports/advance_payment.php" data="Advance Payment Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Advance Payment</p>
                                </a>
                                <a href="<?=$app_url;?>reports/gl_account_transaction_report.php" data="GL Account Transaction Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>GL Account Record Report</p>
                                </a>

                                <a href="<?=$app_url;?>reports/account_transaction.php" data="Account Transaction Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Account Transaction</p>
                                </a>
                                <a href="<?=$app_url;?>reports/expense.php" data="Expense Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Expense</p>
                                </a>
                                <a href="<?=$app_url;?>reports/general_ledger.php" data="General Ledger Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>General Ledger</p>
                                </a>
                                <a href="<?=$app_url;?>reports/trial_balance.php" data="Trial Balance Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Trial Balance</p>
                                </a>
                                <a href="<?=$app_url;?>reports/profit_and_loss.php" data="Profit and Loss Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Profit & Loss</p>
                                </a>
                                <a href="<?=$app_url;?>reports/balance_sheet.php" data="Balance Sheet Report|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Balance Sheet</p>
                                </a>
                            </li>
                        </li>
                    </ul>
                </li>

            </ul>
        </nav>
    </div>
</aside>     