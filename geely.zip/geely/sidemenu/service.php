<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    }  
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Geely Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Geely Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-wrench"></i>
                        <p>Setup <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview"> 
                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/promotion.php" data="Service Promotion|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Promotion</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_item.php" data="Service Item|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Service Item</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_item_task.php" data="Service Item Task|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Service Item Task</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_package.php" data="Service Package|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Package</p>
                            </a>
                        </li>
 
                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_center_bay.php" data="Service Center Bay|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Bay</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_bay_services.php" data="Service Bay Services|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Bay Services</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/store.php" data="Store|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Store</p>
                            </a>
                        </li> 

                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sub_store.php" data="Sub Store|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Sub Store</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_center_store.php" data="Service Center Store|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Service Center Store</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>service/service_center_assign.php" data="Service Center Assign|111000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Service Center Assign</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/store_stock_level.php" data="Store Stock Level|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Store Stock Level</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-plus-circle"></i>
                        <p>Entry <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/group.php" data="Group|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Group</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sub_group.php" data="Sub Group|110000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Sub Group</p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart.php" data="Sparepart|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Sparepart</p>
                            </a>
                        </li> 
                    </ul>
                </li> 

                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/sales_list.php" data="1. Sales List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Sales Processing List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>service/service_appointment_list.php" data="Service Appointment|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-calendar nav-icon"></i>
                        <p>Appointment List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>service/servicing_list.php" data="Servicing List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Servicing List</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>service/survey.php" data="Survey|100000" class="nav-link nav-link-treeview">
                        <i class="fas fa-file-alt nav-icon"></i>
                        <p>Survey</p>
                    </a>
                </li>

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-solid fa-screwdriver"></i>
                        <p>Sparepart <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sp_waiting_list.php" data="Waiting List|010000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Waiting List</p>
                            </a>
                        </li>  
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_order.php" data="Order|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Order</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_receiving.php" data="Receiving|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Receiving</p>
                            </a>
                        </li>
                    </ul>
                </li> 

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-truck"></i>
                        <p>Inventory <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_issue_note.php" data="Issue Note|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Issue Note (Stock Out)</p>
                            </a>
                        </li> 
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_stock_out.php" data="Stock Out|110100" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock Out</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_stock_transfer.php" data="Stock Transfer|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock Transfer</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_stock_receive.php" data="Stock Receive|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock Receive</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>sparepart/sparepart_stock_return.php" data="Stock Return|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock Return</p>
                            </a>
                        </li>
                    </ul>
                </li> 

                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-chart-bar"></i> <p>Reports <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">  
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/service_customer.php" data="Service Customer|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Service Customer</p>
                                </a>
                            </li>
                        </li> 
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/service_car.php" data="Service Car|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Service Car</p>
                                </a>
                            </li>
                        </li> 
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/service_promotion.php" data="Service Promotion|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Service Promotion</p>
                                </a>
                            </li>
                        </li>
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/sparepart.php" data="Sparepart|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Sparepart</p>
                                </a>
                            </li>
                        </li>
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/warranty_car.php" data="Warranty Car|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Warranty Car</p>
                                </a>
                            </li>
                        </li>
                        <li class="nav-item">
                            <li class="nav-item">
                                <a href="<?=$app_url;?>reports/service.php" data="Service|010000" class="nav-link nav-link-treeview">
                                    <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                    <p>Service</p>
                                </a>
                            </li>
                        </li>
                    </ul>
                </li>
                
            </ul>
        </nav>
    </div>
</aside>     