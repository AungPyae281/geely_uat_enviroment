<style>
    .brand-link .brand-image-xs{
        margin-top: -0.4rem !important;
        max-height: 45px !important;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link{
        background-color: #1b8cc5;
    }
    [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:focus, [class*="sidebar-dark-"] .nav-treeview > .nav-item > .nav-link:hover {
        background-color: #10649c !important;
        color: #fff;
    }  
    [class*='sidebar-dark-'] .nav-treeview > .nav-item > .nav-link.activeMenu{
        background-color: #10649c !important;
    }  
    .activee {
        color: #fff !important;
        background-color: #10649c !important;
    }

    .activeMenu {
      background-color: #10649c  !important;
      color: #fff !important;
    } 
</style>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link" style="height: 56px;">
        <img src="<?=$app_url;?>img/logo_sm.png" alt="Geely Logo Small" class="brand-image-xl logo-xs">
        <img src="<?=$app_url;?>img/logo.png" alt="Geely Logo Large" class="brand-image-xs logo-xl" style="left: 54px;">
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image"> 
                <img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info" style="padding-top: 0px;">
                <p style="margin-bottom: 0px;color: #006b79;"><?=$_SESSION['user'];?></p>
                <a href="#"><?=$_SESSION['userrole'];?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php" class="nav-link">
                        <i class="nav-icon fa fa-home fa-fw"></i> <p>Home</p>
                    </a>
                </li>

                

                <!-- <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-car"></i>
                        <p>Order <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">   
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/production_order.php" data="Production Order|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Production Order</p>
                            </a>
                        </li>
                    </ul>
                </li> -->
                
                <li class="nav-item has-treeview">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa fa-truck"></i>
                        <p>Inventory <i class="fas fa-angle-left right"></i></p>
                    </a>
                    <ul class="nav nav-treeview">    
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/supply_chain.php" data="Supply Chain Transfer|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Supply Chain</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=$app_url;?>supply_chain/car_stock_transfer.php" data="Car Stock Transfer|100000" class="nav-link nav-link-treeview">
                                <i class="far fa-folder nav-icon" data-custom="sub"></i>
                                <p>Stock Transfer</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="<?=$app_url;?>sales/sales_list.php" data="1. Sales List|010000" class="nav-link nav-link-treeview">
                        <i class="fas fa-clipboard-list nav-icon"></i>
                        <p>Sales Processing List</p>
                    </a>
                </li>

            </ul>
        </nav>
    </div>
</aside>     