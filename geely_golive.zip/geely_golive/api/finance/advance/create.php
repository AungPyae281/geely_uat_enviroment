<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance.php';
    include_once '../../objects/advance_detail.php';
    include_once '../../objects/trial_balance.php';

    include_once '../../objects/expense.php';
    include_once '../../objects/expense_detail.php';
    include_once '../../objects/expense_history.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $advance = new Advance($db);
    $advance_detail = new AdvanceDetail($db);
    $trial_balance = new TrialBalance($db);

    $expense = new Expense($db);
    $expense_detail = new ExpenseDetail($db);
    $expense_history = new ExpenseHistory($db);

    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $targetPath1 = "";
    $targetPath2 = "";
    $newname = "";
    $newname1 = "";
    $newname2 = "";

    mkdir("./upload/" . $data[0]->voucher_no ."/");

    $img = $_FILES['file'];
    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext!=""){
            $newname = $_FILES['file']['name'];
            $targetPath = './upload/' . $data[0]->voucher_no . '/' . $newname;
            move_uploaded_file($_FILES['file']['tmp_name'],$targetPath);
            $advance->upload_receipt = $newname; 
        }   
    }

    $img = $_FILES['file1'];
    if(!empty($_FILES['file1']))
    {
        $ext = pathinfo($_FILES['file1']['name'], PATHINFO_EXTENSION);
        if($ext!=""){
            $newname = $_FILES['file1']['name'];
            $targetPath = './upload/' . $data[0]->voucher_no . '/' . $newname;
            move_uploaded_file($_FILES['file1']['tmp_name'],$targetPath);
            $advance->gm_approval = $newname; 
        }   
    }

    $img = $_FILES['file2'];
    if(!empty($_FILES['file2']))
    {
        $ext = pathinfo($_FILES['file2']['name'], PATHINFO_EXTENSION);
        if($ext!=""){
            $newname = $_FILES['file2']['name'];
            $targetPath = './upload/' . $data[0]->voucher_no . '/' . $newname;
            move_uploaded_file($_FILES['file2']['tmp_name'],$targetPath);
            $advance->ceo_approval = $newname; 
        }   
    }


    $advance->gl_category_flag = $data[0]->gl_category_flag;
    $advance->date = $data[0]->date;
    $advance->receive_by = $data[0]->receive_by;
    $advance->description = $data[0]->description;
    $advance->request_no = $data[0]->request_no;
    $advance->voucher_no = $data[0]->voucher_no;
    $advance->entry_by = $_SESSION['user'];
    $advance->entry_date_time = date("Y-m-d H:i:s");

    if($advance->create()){
        foreach($data[0]->details as $detail){
            $advance_detail->advance_id = $advance->id;
            $advance_detail->due_days = $detail->due_days;
            $advance_detail->gl_code_to = $detail->gl_code_to;
            $advance_detail->amount = $detail->amount;
            $advance_detail->description = $detail->description;
            $advance_detail->job_code = $detail->job_code;
            $advance_detail->gl_code_bank_or_cash = $detail->gl_code_bank_or_cash;
            $advance_detail->journal_ref_number = $detail->journal_ref_number;
            if(!$advance_detail->create()){
                $msg_arr = array(
                    "message" => "error_advance_detail"
                );
                echo json_encode($msg_arr);
                die();
            }else{
                $trial_balance->gl_code = $detail->gl_code_bank_or_cash;
                $trial_balance->date_time = date("Y-m-d H:i:s");
                $trial_balance->transaction_id = $advance_detail->id;
                $trial_balance->gl_code_ref = $detail->gl_code_to;
                $trial_balance->statement = $detail->gl_code_name;
                $trial_balance->debit = 0;
                $trial_balance->credit = $detail->amount;
                $trial_balance->entry_by = $_SESSION['user'];
                $trial_balance->entry_date_time = date("Y-m-d H:i:s");

                if($trial_balance->create()){
                    $msg_arr = array(
                        "message" => "created",
                        "advance_id" => $advance->id,
                        "voucher_no" => $data[0]->voucher_no
                    );
                }else{
                    $msg_arr = array(
                        "message" => "error_trial_balance"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
            }
        }
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }


    if($advance->gl_category_flag=='true'){
        $expense->expense_date = date("Y-m-d");
        $expense->payment_voucher_no = $data[0]->voucher_no;
        $expense->bank_account_to = "";
        $expense->expense_by = $_SESSION['user'];
        $expense->receive_no = $data[0]->voucher_no;
        $expense->entry_by = $_SESSION['user'];
        $expense->entry_date_time = date("Y-m-d H:i:s");
        $expense->upload_receive = $advance->upload_receipt;

        if($expense->create()){
            foreach($data[0]->details as $detail){
                $expense_history->expense_id = $expense->id;
                $expense_history->advance_id = $advance->id;
                $expense_history->voucher_no = $data[0]->voucher_no;
                $expense_history->request_no = $data[0]->request_no;
                $expense_history->amount = $detail->amount;

                if(!$expense_history->create()){
                    $msg_arr = array(
                        "message" => "error_expense_history"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
            }

            foreach($data[0]->details as $detail){
                $expense_detail->expense_id = $expense->id;
                $expense_detail->gl_code = $detail->gl_code_to;
                $expense_detail->amount = $detail->amount;
                $expense_detail->remark = "";
            
                if(!$expense_detail->create()){
                    $msg_arr = array(
                        "message" => "error_advance_detail"
                    );
                    echo json_encode($msg_arr);
                    die();
                }else{
                    $msg_arr = array(
                        "message" => "created"
                    );
                }
            }
        }else{
            $msg_arr = array(
                "message" => "error expense"
            );
        }
    }
    echo json_encode($msg_arr);
?>