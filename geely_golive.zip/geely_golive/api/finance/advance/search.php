<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $advance = new Advance($db);
    $data = json_decode(file_get_contents("php://input")); 

    $advance->df = $data->df;
    $advance->dt = $data->dt;
    $advance->voucher_no = $data->voucher_no;
    $advance->brand = $data->brand;
    $advance->requester = $data->requester;
    $advance->requet_no = $data->requet_no;

    $stmt = $advance->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "id" => $id,
                "date" => $date,
                "voucher_no" => $voucher_no,
                "brand" => $brand,
                "requester" => $name,
                "request_no" => $request_no,
                "receive_by" => $receive_by,
                "gl_code_from" => $name . "(" . $gl_code_bank_or_cash . ")",
                "amount" => number_format($amount)
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>