<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/advance_expense_request.php';
include_once '../../objects/advance_expense_request_detail.php';
include_once '../../objects/approval.php';
include_once '../../objects/reject.php';

date_default_timezone_set('Asia/Rangoon');
session_start();

$database = new Database();
$db = $database->getConnection();
 
$advance_expense_request = new AdvanceExpenseRequest($db);
$advance_expense_request_detail = new AdvanceExpenseRequestDetail($db);
$approval = new Approval($db);
$reject = new Reject($db);
$data = json_decode(file_get_contents("php://input"));

$advance_expense_request->request_number = $data->request_number;
$advance_expense_request->entry_date_time = date("Y-m-d H:i:s");
$advance_expense_request->entry_by = $_SESSION['user'];	
$advance_expense_request->staff_id = $_SESSION['staff_id'];
$advance_expense_request->request_date = $data->request_date;
$advance_expense_request->brand =$data->brand;	
$advance_expense_request->remark = $data->remark;

$advance_expense_request_detail->request_number = $data->request_number;

$advance_expense_request_detail->getAdvanceExpenseRequestID();
$advance_expense_request_detail->advance_expense_request_id = $advance_expense_request_detail->id;
$advance_expense_request_detail->delete();
$advance_expense_request->delete();
$approval->main_id = $data->request_number;
$approval->delete();

$reject->main_id = $data->request_number;
$reject->updateFromReRequest();

if($advance_expense_request->create()){
	foreach($data->details as $detail){
		$advance_expense_request_detail->advance_expense_request_id = $advance_expense_request->id;
		$advance_expense_request_detail->description = $detail->description;
		$advance_expense_request_detail->reason = $detail->reason;
		$advance_expense_request_detail->qty = $detail->qty;
		$advance_expense_request_detail->cost_per_unit = $detail->cost_per_unit;

		if(!$advance_expense_request_detail->create()){
			$arr = array(
				"message" => "error_advance_expense_request_detail",
				"test" => $advance_expense_request->id
			);
			echo json_encode($arr);
			die();
		}else{
			$arr = array(
				"message" => "updated",
				"test" => $advance_expense_request_detail->id
			);
		}
	}

	foreach($data->approvalList as $detail){
		$approval->main_id = $advance_expense_request->request_number;
		$approval->order_no = $detail->order_no;
		$approval->role = $detail->position;
		$approval->process = "Advance and Expense Request";
		$approval->staff_id = $detail->staff_id;

		if(!$approval->createFromRequestForm()){
			$arr = array(
				"message" => "error_create_approval",
				"test" => $advance_expense_request->id
			);
			echo json_encode($arr);
			die();
		}
	}
}else{
	$arr = array(
		"message" => "error",
		"rqnum" => $advance_expense_request->request_number
	);
}
echo json_encode($arr);
?>	