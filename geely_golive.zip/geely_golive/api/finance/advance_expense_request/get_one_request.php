<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance_expense_request.php';
    include_once '../../objects/advance_expense_request_detail.php';
    include_once '../../objects/approval.php';
    include_once '../../objects/reject.php';
     
    $database = new Database();
    $db = $database->getConnection();
    session_start();

    $advance_expense_request = new AdvanceExpenseRequest($db);
    $advance_expense_request_detail = new AdvanceExpenseRequestDetail($db);
    $approval = new Approval($db);
    $reject = new Reject($db);
    $data = json_decode(file_get_contents("php://input"));

    $advance_expense_request->request_number = $data->r_no;
    $approval->main_id = $advance_expense_request->request_number;

    $advance_expense_request->getOneRequest();

    $a_details = array();
    $stmt1 = $approval->getApprovalDetail();
    $num1 = $stmt1->rowCount();
    if($num1>0){
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $a_detail=array(
                "id" => $id,
                "role" => $role,
                "staff_id" => $staff_id,
                "name" => $name,
                "main_id" => $main_id,    
                "order_no" => $order_no,    
                "process" => $process,
                "approve" => $approve,
                "approve_date_time" => $approve_date_time
            );
            array_push($a_details, $a_detail);
        }
    }

    $advance_expense_request_detail->advance_expense_request_id = $advance_expense_request->id;

    $p_details = array();
    $stmt = $advance_expense_request_detail->getRequestDetail();
    $num = $stmt->rowCount();
    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $p_detail=array(
                "id" => $id,
                "advance_expense_request_id" => $advance_expense_request_id,
                "description" => $description,
                "reason" => $reason,    
                "qty" => $qty,    
                "cost_per_unit" => $cost_per_unit
            );
            array_push($p_details, $p_detail);
        }
    }

    $approval->staff_id = $_SESSION['staff_id'];
    $approval->getOneApprovalForRequest();

    $reject->main_id = $advance_expense_request->request_number;
    $reject->getOneRejectForRequest();

    if($approval->order_no!=0){
        $btnApprove = 1;
    }else{
        $btnApprove = 0;
    }

    $rdetail = array(
        "id" => (int)$advance_expense_request->id,
        "request_number" => $advance_expense_request->request_number,
        "request_date" => $advance_expense_request->request_date,
        "brand" => $advance_expense_request->brand,
        "entry_by" => $advance_expense_request->entry_by,
        "staff_id" => $advance_expense_request->staff_id,
        "login_staff_id" => $_SESSION['staff_id'],
        "remark" => $advance_expense_request->remark,
        "staff_name" => $advance_expense_request->staff_name,
        "entry_date_time" => $advance_expense_request->entry_date_time,
        "btn_approve" => $btnApprove,
        "btn_edit" => $reject->fixed,
        "reject_reason" => $reject->reject_reason,
        "order_no" => $approval->order_no,
        "p_details" => $p_details,
        "a_details" => $a_details
    );
    echo json_encode($rdetail);

?>