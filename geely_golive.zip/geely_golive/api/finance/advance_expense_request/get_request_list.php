<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance_expense_request.php';
    include_once '../../objects/approval.php';

    session_start();
    date_default_timezone_set('Asia/Rangoon');  

    $database = new Database();
    $db = $database->getConnection();

    $advance_expense_request = new AdvanceExpenseRequest($db);
    $approval = new Approval($db);

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['staff_id']!=""){

        $advance_expense_request->staff_id = $_SESSION['staff_id'];
        $advance_expense_request->position = $_SESSION['position'];

        $advance_expense_request->process = "Advance and Expense Request"; 

        $stmt = $advance_expense_request->getRequestList();
        $num = $stmt->rowCount(); 

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row); 
                $approval_flow = ""; 
                $order_process = "";
                $sign = 0;

                $approval->process = "Advance and Expense Request";
                $approval->main_id = $request_number; 

                $stmt1 = $approval->getApprovalListForRequestForm();
                $num1 = $stmt1->rowCount();
                if($num1>0){
                    while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
                        extract($row1);
                        if($status=="Approve"){
                            $color = "#13c613";
                        }else if($status=="Reject"){
                            $color = "#e40d0d";
                        }else{
                            $color = "#bebebe";
                        } 
                        $approval_flow = $approval_flow . (($approval_flow!="")?"<br>":"") . $order_no . ') ' . '<i class="fa fa-circle" style="color:' . $color . '"></i> ' . $role;
                    }
                }

                if($approval->checkLastApprovalForRequestForm()==0 && $_SESSION['position']=="Finance Manager"){
                    $order_process = "Cash Out";
                    $sign = 1;
                }else{
                    $order_process = "Approval";
                }

                $detail = array(    
                    $entry_date_time,
                    $request_number,
                    '<span data-id="' . $staff_id . '"></span>' . $name,
                    // $name,
                    $brand,
                    $remark,
                    number_format($total_amount), 
                    $order_process,
                    $approval_flow,    
                    $request_number . "|" . $sign
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>