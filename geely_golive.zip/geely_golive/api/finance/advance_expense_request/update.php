<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/approval.php';
	include_once '../../objects/reject.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$approval = new Approval($db);
	$reject = new Reject($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){

		$approval->main_id = $data->main_id;
		$approval->process = "Advance and Expense Request";
		
		if($data->btnStatus=="Approve"){

			$approval->staff_id = $_SESSION["staff_id"];
			$approval->order_no = $data->order_no;
			$approval->approve_date_time = date("Y-m-d H:i:s");

			if($approval->updateApproval()){
				$arr = array( 
					"message" => "updated"
				);
			}else{
				$arr = array( 
					"message" => "error apporve"
				);
			}
		}else{

			$reject->role = $_SESSION['position'];
			$reject->staff_id = $_SESSION['staff_id'];
			$reject->main_id = $data->main_id;
			$reject->order_no = $data->order_no;
			$reject->process = "Advance and Expense Request";
			$reject->reject_date_time = date("Y-m-d H:i:s");
			$reject->remark = $data->reject_remark;
			$reject->previous_order_no = (int)$data->order_no - 1;

			if($reject->createForOC()){
				$arr = array( 
					"message" => "updated"
				);
			}else{
				$arr = array( 
					"message" => "error reject"
				);
			}
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>	