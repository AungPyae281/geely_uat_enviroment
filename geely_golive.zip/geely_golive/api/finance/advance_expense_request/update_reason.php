<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance_expense_request_detail.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $advance_expense_request_detail = new AdvanceExpenseRequestDetail($db);
    $data = json_decode(file_get_contents("php://input"));

    $advance_expense_request_detail->id = $data->id;
    $advance_expense_request_detail->reason = $data->reason;

    if($advance_expense_request_detail->updateReason()){
        $msg_arr = array(
            "message" => "update"
        );
    }
    echo json_encode($msg_arr);
?>