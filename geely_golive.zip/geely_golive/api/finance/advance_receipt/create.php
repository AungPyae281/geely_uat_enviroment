<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance_receipt.php';
    include_once '../../objects/trial_balance.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $advance_receipt = new AdvanceReceipt($db);
    $trial_balance = new TrialBalance($db); 
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $advance_receipt->upload_receipt = $newname;  

    $advance_receipt->receipt_date = $data[0]->receipt_date;
    $advance_receipt->customer_id = $data[0]->customer_id;
    $advance_receipt->gl_code_bank_or_cash_debit = $data[0]->gl_code_bank_or_cash_debit;
    $advance_receipt->amount = $data[0]->amount;
    $advance_receipt->description = $data[0]->description;
    $advance_receipt->receive_by = $data[0]->receive_by;
    $advance_receipt->gl_code = $data[0]->gl_code;

    $advance_receipt->entry_by = $_SESSION['user'];
    $advance_receipt->entry_date_time = date("Y-m-d H:i:s");

    $trial_balance->gl_code = $data[0]->gl_code_bank_or_cash_debit;
    $trial_balance->date_time = $data[0]->receipt_date . ' ' . date("H:i:s");
    $trial_balance->gl_code_ref = $data[0]->gl_code;
    $trial_balance->debit = $data[0]->amount;
    $trial_balance->credit = 0;
    $trial_balance->entry_by = $_SESSION['user'];
    $trial_balance->entry_date_time = date("Y-m-d H:i:s");

    if($advance_receipt->create()){

        $trial_balance->transaction_id = $advance_receipt->id;
        $trial_balance->statement = "Advance Receipt";

        $trial_balance->create();

        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>