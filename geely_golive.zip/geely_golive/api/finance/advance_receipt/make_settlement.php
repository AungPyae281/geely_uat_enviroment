<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/advance_receipt.php';
    include_once '../../objects/trial_balance.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$advance_receipt = new AdvanceReceipt($db);
    $trial_balance = new TrialBalance($db); 
	$data = json_decode(file_get_contents("php://input"));

	$advance_receipt->id = $data->id;
	$advance_receipt->settlement_date = $data->date; 
	$advance_receipt->gl_code_bank_or_cash_credit = $data->gl_code_bank_or_cash_credit;

    $advance_receipt->settlement_by = $_SESSION['user'];
    $advance_receipt->settlement_date_time = date("Y-m-d H:i:s");

    $trial_balance->gl_code = $data->gl_code_bank_or_cash_credit;
    $trial_balance->date_time = $data->date . ' ' . date("H:i:s");
    $trial_balance->gl_code_ref = "4013/002";
    $trial_balance->debit = 0;
    $trial_balance->credit = $data->amount;
    $trial_balance->entry_by = $_SESSION['user'];
    $trial_balance->entry_date_time = date("Y-m-d H:i:s");

	if($advance_receipt->update()){

		$trial_balance->transaction_id = $data->id;
        $trial_balance->statement = "Advance Receipt Settlement";

        $trial_balance->create();

		$msg_arr = array(
			"message" => "updated"
		);
	}else{
		$msg_arr = array(
			"message" => "error"
		);
	}
	echo json_encode($msg_arr);
?>