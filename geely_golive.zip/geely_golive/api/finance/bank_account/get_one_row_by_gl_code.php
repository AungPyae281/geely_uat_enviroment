<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/bank_account.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
    $bank_account = new BankAccount($db);
    $data = json_decode(file_get_contents("php://input"));

	$bank_account->gl_code = $data->gl_code;

	$bank_account->getOneRowByGLCode();

	$arr = array(
        "id" =>  $bank_account->id,
	    "gl_code" =>  $bank_account->gl_code,
		"country" => $bank_account->country,
		"bank_name" => $bank_account->bank_name,
		"branch" => $bank_account->branch,
		"swift_code" => $bank_account->swift_code,
		"currency" => $bank_account->currency,
		"account_no" => $bank_account->account_no,
		"account_name" => $bank_account->account_name,
		"account_type" => $bank_account->account_type
    );
	echo json_encode($arr);
?>