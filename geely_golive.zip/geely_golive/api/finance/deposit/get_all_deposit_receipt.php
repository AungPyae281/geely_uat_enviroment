<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/deposit_receipt.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $deposit_receipt = new DepositReceipt($db); 

    $arr = array();
    $arr["data"] = array();

    $stmt = $deposit_receipt->getAllDepositReceipt();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                $receipt_date,
                $receipt_no,
                $oc_no,
                $sales_center,
                $customer_name,
                $customer_phone,
                number_format($amount),
                $id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>