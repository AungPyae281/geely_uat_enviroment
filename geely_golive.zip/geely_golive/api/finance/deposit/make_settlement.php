<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/deposit_refund.php';
	include_once '../../objects/income.php';
    include_once '../../objects/trial_balance.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$deposit_refund = new DepositRefund($db);
	$income = new Income($db);
    $trial_balance = new TrialBalance($db); 
	$data = json_decode(file_get_contents("php://input"));

	if($data->reason=="Refund"){
		$deposit_refund->date = $data->date; 
		$deposit_refund->ref_id = $data->id;
		$deposit_refund->oc_no = $data->oc_no;
		$deposit_refund->gl_code = "4013/001"; 
		$deposit_refund->gl_code_bank_or_cash = $data->gl_code_bank_or_cash;
		$deposit_refund->amount = $data->amount;
		$deposit_refund->description = $data->description;

	    $deposit_refund->entry_by = $_SESSION['user'];
	    $deposit_refund->entry_date_time = date("Y-m-d H:i:s");

	    $trial_balance->gl_code = $data->gl_code_bank_or_cash;
        $trial_balance->date_time = $data->date . ' ' . date("H:i:s");
        $trial_balance->gl_code_ref = $deposit_refund->gl_code;
        $trial_balance->debit = 0;
        $trial_balance->credit = $data->amount;
        $trial_balance->entry_by = $_SESSION['user'];
        $trial_balance->entry_date_time = date("Y-m-d H:i:s");

	    if($deposit_refund->create()){

	    	$trial_balance->transaction_id = $deposit_refund->id;
            $trial_balance->statement = "Deposit Refund";

            $trial_balance->create();

			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$income->date = $data->date; 
		$income->ref_id = $data->id;
		$income->gl_code = "4013/001"; 
		$income->gl_code_bank_or_cash = $data->gl_code_bank_or_cash;
		$income->amount = $data->amount;
		$income->description = $data->description;

	    $income->entry_by = $_SESSION['user'];
	    $income->entry_date_time = date("Y-m-d H:i:s");

	    if($income->create()){
			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($msg_arr);
?>