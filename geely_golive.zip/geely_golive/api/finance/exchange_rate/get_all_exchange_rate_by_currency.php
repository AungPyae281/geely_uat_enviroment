<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");	

include_once '../../config/database.php';
include_once '../../objects/exchange_rate.php';
date_default_timezone_set('Asia/Rangoon');

$database = new Database();
$db = $database->getConnection();

$exchange_rate = new ExchangeRate($db);
$data = json_decode(file_get_contents("php://input"));

$exchange_rate->currency = $data->currency;

$details = array();	
$arr["records"]=array();

$stmt = $exchange_rate->getAllRowsByCurrency();
if($stmt->rowCount()>0){
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		extract($row);
		$rate_history=array(
			"id" => $id,
			"date" => $date,
			"currency" => $currency,
			"rate" => number_format($rate),
			"entry_by" => $entry_by,
			"entry_date_time" => $entry_date_time
		);
		array_push($arr["records"], $rate_history);
	}	
}
echo json_encode($arr);
?>