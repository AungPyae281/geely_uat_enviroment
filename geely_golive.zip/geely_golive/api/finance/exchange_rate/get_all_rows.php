<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../../config/database.php';
	include_once '../../objects/exchange_rate.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$exchange_rate = new ExchangeRate($db);

	$stmt = $exchange_rate->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"date" => $date,
				"currency" => $currency,
				"rate" => (float)$rate,
				"entry_date_time" => $entry_date_time
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>