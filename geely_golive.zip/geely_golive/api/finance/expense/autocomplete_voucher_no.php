<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/expense.php';

$database = new Database();
$db = $database->getConnection();
 
$expense = new Expense($db);
$data = json_decode(file_get_contents("php://input"));

$expense->payment_voucher_no = $data->voucher_no;

$stmt = $expense->autocompleteVoucherNo();
$num = $stmt->rowCount();
$arr = array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $detail = array(
            "voucher_no" => $payment_voucher_no
        );
        array_push($arr, $detail);
    }
}
echo json_encode($arr);
?>