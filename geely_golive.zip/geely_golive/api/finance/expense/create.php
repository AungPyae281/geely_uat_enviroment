<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/expense.php';
    include_once '../../objects/expense_detail.php';
    include_once '../../objects/trial_balance.php';
    include_once '../../objects/car_additional_charges.php';
    include_once '../../objects/expense_history.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $expense = new Expense($db);
    $expense_detail = new ExpenseDetail($db);
    $trial_balance = new TrialBalance($db);
    $car_additional_charges = new CarAdditionalCharges($db);
    $expense_history = new ExpenseHistory($db);
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $expense->upload_receive = $newname;  

    $expense->expense_date =$data[0]->expense_date;
    $expense->payment_voucher_no =$data[0]->payment_voucher_no;
    $expense->bank_account_to = $data[0]->bank_account_to;
    $expense->expense_by = $data[0]->expense_by;
    $expense->receive_no = $data[0]->receive_no;
    $expense->entry_by = $_SESSION['user'];
    $expense->entry_date_time = date("Y-m-d H:i:s");

    if($expense->create()){
        $trial_balance->gl_code = "";
        $trial_balance->date_time = date("Y-m-d H:i:s");
        $trial_balance->transaction_id = $expense->id;
        $trial_balance->gl_code = $data[0]->gl_code_to;
        $trial_balance->gl_code_ref = $data[0]->gl_code_to;
        $trial_balance->statement = "Settlement expense to " . $data[0]->gl_code_name;
        $trial_balance->debit = $data[0]->balance;
        $trial_balance->credit = 0;
        $trial_balance->entry_by = $_SESSION['user'];
        $trial_balance->entry_date_time = date("Y-m-d H:i:s");

        if($data[0]->balance!="0"){
            $trial_balance->create();
        }

        foreach($data[0]->expense_history as $details){
            $expense_history->expense_id = $expense->id;
            $expense_history->advance_id = $details->advance_id;
            $expense_history->voucher_no = $details->voucher_no;
            $expense_history->request_no = $details->request_no;
            $expense_history->amount = $details->amount;

            if(!$expense_history->create()){
                $msg_arr = array(
                    "message" => "error_expense_history"
                );
                echo json_encode($msg_arr);
                die();
            }
        }

        foreach($data[0]->expense_details as $detail){
            $expense_detail->expense_id = $expense->id;
            $expense_detail->gl_code = $detail->gl_code;
            $expense_detail->amount = $detail->amount;
            $expense_detail->remark = $detail->remark;

            $car_additional_charges->vin_no = $detail->vinno;
            $car_additional_charges->reason = $detail->reason;
            $car_additional_charges->remark = $detail->remark;
            $car_additional_charges->amount = $detail->amount;
            $car_additional_charges->entry_by = $_SESSION['user'];
            $car_additional_charges->entry_date_time = date("Y-m-d H:i:s");

            if($detail->vinno!=""){
                $car_additional_charges->create();
            }
        
            if(!$expense_detail->create()){
                $msg_arr = array(
                    "message" => "error_advance_detail"
                );
                echo json_encode($msg_arr);
                die();
            }else{
                $msg_arr = array(
                    "message" => "created"
                );
            }
        }
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>