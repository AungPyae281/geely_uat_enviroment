<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/expense.php';
    include_once '../../objects/expense_detail.php';
    include_once '../../objects/trial_balance.php';
    include_once '../../objects/car_additional_charges.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $expense = new Expense($db);
    $expense_detail = new ExpenseDetail($db);
    $trial_balance = new TrialBalance($db);
    $car_additional_charges = new CarAdditionalCharges($db);
    $data = json_decode(file_get_contents("php://input"));

    $expense->payment_voucher_no =$data->payment_voucher_no;
    $expense->bank_account_to = $data->bank_account_to;
    $expense->expense_by = $data->expense_by;
    $expense->entry_by = $_SESSION['user'];
    $expense->entry_date_time = date("Y-m-d H:i:s");

    if($expense->create()){
        $trial_balance->gl_code = "";
        $trial_balance->date_time = date("Y-m-d H:i:s");
        $trial_balance->transaction_id = $expense->id;
        $trial_balance->gl_code_ref = $data->gl_code_to;
        $trial_balance->statement = "Settlement expense to " . $data->gl_code_name;
        $trial_balance->debit = $data->balance;
        $trial_balance->credit = 0;
        $trial_balance->entry_by = $_SESSION['user'];
        $trial_balance->entry_date_time = date("Y-m-d H:i:s");

        if($data->balance!="0"){
            $trial_balance->create();
        }

        foreach($data->expense_details as $detail){
            $expense_detail->expense_id = $expense->id;
            $expense_detail->gl_code = $detail->gl_code;
            $expense_detail->amount = $detail->amount;
            $expense_detail->remark = $detail->remark;

            $car_additional_charges->vin_no = $detail->vinno;
            $car_additional_charges->reason = $detail->reason;
            $car_additional_charges->remark = $detail->remark;
            $car_additional_charges->amount = $detail->amount;
            $car_additional_charges->entry_by = $_SESSION['user'];
            $car_additional_charges->entry_date_time = date("Y-m-d H:i:s");

            if($detail->vinno!=""){
                $car_additional_charges->create();
            }
        
            if(!$expense_detail->create()){
                $msg_arr = array(
                    "message" => "error_advance_detail"
                );
                echo json_encode($msg_arr);
                die();
            }else{
                $msg_arr = array(
                    "message" => "created"
                );
            }
        }
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>