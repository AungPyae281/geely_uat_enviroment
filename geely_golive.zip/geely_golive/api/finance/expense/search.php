<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/expense.php';

$database = new Database();
$db = $database->getConnection();
 
$expense = new Expense($db);

$data = json_decode(file_get_contents("php://input"));
$expense->df = $data->df;
$expense->df1 = substr($data->df, 0, 7);
$expense->dt = $data->dt;  
$expense->dt1 = substr($data->dt, 0, 7);
$expense->payment_voucher_no = $data->voucher_no;
$expense->receive_no = $data->receive_no;
$expense->expense_by = $data->expense_by;
$expense->status = $data->status; 

$stmt = $expense->search();
$num = $stmt->rowCount();

$arr=array();
$arr["records"]=array();
$total_amount = 0;
if($num>0){
    if($data->status=="summary"){
         while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $exp=array(
                "id" => $id,
                "expense_date" => $expense_date,
				"payment_voucher_no" => $payment_voucher_no,
				"bank_account_to" => $bank_account_to,
				"expense_by" => $expense_by,
		        "receive_no" => $receive_no,
				"amount" => number_format($amount)
            );
            $total_amount += $amount;
            array_push($arr["records"], $exp);
        }
    }else{
         while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $exp=array(
                "id" => $id,
                "expense_id" => (int)$expense_id,
                "expense_date" => $expense_date,
                "payment_voucher_no" => $payment_voucher_no,
                "receive_no" => $receive_no,
				"bank_account_to" => $bank_account_to,
                "expense_by" => $expense_by,
                "remark" => $remark,
                "gl_code" => $gl_code,
                "amount" => number_format($amount)
            );
            $total_amount += $amount;
            array_push($arr["records"], $exp);
        }
    }
    $arr["total_amount"] = number_format($total_amount);
}
echo json_encode($arr);
?>