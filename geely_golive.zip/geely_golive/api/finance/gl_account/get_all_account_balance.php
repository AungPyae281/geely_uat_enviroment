<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/gl_account.php';

    date_default_timezone_set('Asia/Rangoon');

    $database = new Database();
    $db = $database->getConnection();

    $gl_account = new GLAccount($db);
    $data = json_decode(file_get_contents("php://input"));

    $gl_account->date = date("Y-m-d");

    $stmt = $gl_account->getAllAccountBal();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            if(!($category=="Bank" && $bank_id==0)){
                $balance_mmk = $balance;
                if($currency!="MMK"){
                    $balance_mmk = Round(($balance * $rate), 2);
                }
                $detail = array(
                    "gl_code" => ($gl_code)?$gl_code:"",
                    "name" => ($name)?$name:"",
                    "currency" => ($currency)?$currency:"",         
                    "exchange_rate" => ($rate)?(float)ROUND($rate, 2):"",         
                    "balance" => ($balance)?(float)$balance:0,    
                    "balance_mmk" => (float)$balance_mmk
                );  
                array_push($arr["records"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>