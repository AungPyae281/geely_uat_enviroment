<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
	  
	include_once '../../config/database.php';
	include_once '../../objects/gl_account.php';
	include_once '../../objects/trial_balance.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$gl_account = new GLAccount($db);
	$trial_balance = new TrialBalance($db);
	$data = json_decode(file_get_contents("php://input"));
	
	$gl_account->date_from = $data->df;
	$gl_account->gl_code = $data->gl_code;

	$trial_balance->date_from = $data->df;
	$trial_balance->date_to = $data->dt;
	$trial_balance->gl_code = $data->gl_code;

	$arr = array();
	$arr["records"] = array();
	
	if($data->category=="Bank" || $data->category=="Cash"){
		//Opening Balance
		$opening_balance = round((float)$gl_account->getBankOrCashOpeningBal(), 2);
		$closing_balance = 0 ;
		$detail = array( 
			"date" => "",
			"transaction" => "Opening Balance",
			"debit" => $opening_balance,
			"credit" => 0,
			"balance" => $opening_balance
		);
		$closing_balance += $opening_balance;
		array_push($arr["records"], $detail);
		//Opening Balance
		$balance = $opening_balance;
		$stmt = $trial_balance->getAllTransactionByGLCode();
		$num = $stmt->rowCount();

		if($num>0){ 
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				extract($row);
				$detail = array( 
				$balance = $balance + $debit - $credit,
					"date" => $date,
					"transaction" => $transaction,
					"debit" => round((float)$debit, 2),
					"credit" => round((float)$credit, 2),
					"balance" => $balance
				);
				$closing_balance += (float)$debit - (float)$credit;
				array_push($arr["records"], $detail);
			} 
		} 
		$arr["closing_balance"] = round($closing_balance, 2);
	}else{
		// //Opening Balance
		// $opening_balance = round((float)$gl_account->getGLAccountOpeningBal(), 2);
		// $closing_balance = 0 ;
		// $detail = array( 
		// 	"date" => "",
		// 	"transaction" => "Opening Balance",
		// 	"debit" => $opening_balance,
		// 	"credit" => 0
		// );
		// $closing_balance += $opening_balance;
		// array_push($arr["records"], $detail);
		// //Opening Balance

		// $stmt = $trial_balance->getAllTransactionByGLCode();
		// $num = $stmt->rowCount();

		// if($num>0){ 
		// 	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		// 		extract($row);
		// 		$detail = array( 
		// 			"date" => $date,
		// 			"transaction" => $transaction,
		// 			"debit" => round((float)$debit, 2),
		// 			"credit" => round((float)$credit, 2)
		// 		);
		// 		$closing_balance += (float)$debit - (float)$credit;
		// 		array_push($arr["records"], $detail);
		// 	} 
		// } 
		// $arr["closing_balance"] = round($closing_balance, 2);
	}
	echo json_encode($arr);
?>