<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/gl_account.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $gl_account = new GLAccount($db);
    $data = json_decode(file_get_contents("php://input")); 

    $gl_account->date1 = $data->df;
    // $new_date2 = new DateTime(substr($data->df,0,4).'-1');
    // $new_date3 = new DateTime(substr($data->df,0,4).'-2');

    $dateString2 = $data->df;
    $dateString3 = $data->df;
    $dateString4 = $data->df;
    $dateString5 = $data->df;
    // Convert the string to a DateTime object
    $date2 = new DateTime($dateString2);
    $date3 = new DateTime($dateString3);
    $date4 = new DateTime($dateString4);
    $date5 = new DateTime($dateString5);

    // Subtract one day
    $date2->sub(new DateInterval('P1Y'));
    $date3->sub(new DateInterval('P2Y'));
    $date4->sub(new DateInterval('P3Y'));
    $date5->sub(new DateInterval('P4Y'));

    $gl_account->date2 =  explode("-",$date2->format('Y-m-d'))[0]."-12-31";
    $gl_account->date3 =  explode("-",$date3->format('Y-m-d'))[0]."-12-31";
    $gl_account->date4 =  explode("-",$date4->format('Y-m-d'))[0]."-12-31";
    $gl_account->date5 =  explode("-",$date5->format('Y-m-d'))[0]."-12-31";

    $gl_account->type = $data->type;
    $gl_account->category = $data->category;
    $gl_account->gl_code = $data->gl_code;
    $gl_account->name = $data->name;

    $stmt = $gl_account->searchForBalanceSheet();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                // "id" => $id,
                "type" => $type,
                "category" => $category,
                "gl_code" => $gl_code,
                "name" => $name,
                "opening_balance1" => number_format($opening_balance1),
                "opening_balance2" => number_format($opening_balance2),
                "opening_balance3" => number_format($opening_balance3),
                "opening_balance4" => number_format($opening_balance4),
                "opening_balance5" => number_format($opening_balance5)
            );  
            array_push($arr["records"], $detail);
        }
    }
    $arr["date1"] = $gl_account->date1;
    $arr["date2"] = $gl_account->date2;
    $arr["date3"] = $gl_account->date3;
    $arr["date4"] = $gl_account->date4;
    $arr["date5"] = $gl_account->date5;
    echo json_encode($arr);
?>