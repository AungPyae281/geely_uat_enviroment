<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/income.php';
    include_once '../../objects/trial_balance.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $income = new Income($db);
    $trial_balance = new TrialBalance($db); 
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $income->upload_receipt = $newname;  

    $income->date = $data[0]->date;
    $income->gl_code = $data[0]->gl_code;
    $income->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
    $income->amount = $data[0]->amount;
    $income->description = $data[0]->description;

    $income->entry_by = $_SESSION['user'];
    $income->entry_date_time = date("Y-m-d H:i:s");

    $trial_balance->gl_code = $data[0]->gl_code_bank_or_cash;
    $trial_balance->date_time = $data[0]->date . ' ' . date("H:i:s");
    $trial_balance->gl_code_ref = $data[0]->gl_code;
    $trial_balance->debit = $data[0]->amount;
    $trial_balance->credit = 0;
    $trial_balance->entry_by = $_SESSION['user'];
    $trial_balance->entry_date_time = date("Y-m-d H:i:s");

    if($income->create()){

        $trial_balance->transaction_id = $income->id;
        $trial_balance->statement = "Income from " . $data[0]->gl_code;

        $trial_balance->create();

        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>