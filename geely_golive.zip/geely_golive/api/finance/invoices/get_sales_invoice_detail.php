<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
    include_once '../../objects/payment.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $payment = new Payment($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;

    $sales->getOnePrint();

    $payment->oc_no = $data->oc_no;

    $payment_detail = array();

    $stmt = $payment->getAllRows();
    $num = $stmt->rowCount();

    $total_payment = 0;
    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => $id,
                "date" => $date,
                "paid_by" => $paid_by,
                "receive_by" => $receive_by,
                "description" => $description,
                "amount" => number_format($amount)
            );
            $total_payment += (int)$amount;
            array_push($payment_detail, $detail);
        }
    }

    $arr = array(
        "oc_no" => $sales->oc_no,
        "sales_center" => $sales->sales_center,
        "sales_date" => $sales->date,
        "payment_type" => $sales->payment_type,
        "due_date_time" => ($sales->payment_due_date_time=="")?$sales->dc_due_date_time:$sales->payment_due_date_time,
        "total_amount" => number_format($sales->selling_price),
        "customer_name" => $sales->customer_name,
        "customer_phone" => $sales->mobile_no,
        "processing" => $sales->processing,
        "payment_detail" => $payment_detail,
        "total_payment" => number_format($total_payment)
    );
    echo json_encode($arr);
?>