<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/journal.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $journal = new Journal($db);
    $data = json_decode($_POST['objArr']);

    $journal->date = $data[0]->date;
    $journal->ref_number = $data[0]->ref_number;
    $journal->gl_code = $data[0]->db_gl_code;
    $journal->debit = $data[0]->amount;
    $journal->credit = 0;
    $journal->description = $data[0]->description;
    $journal->entry_by = $data[0]->entry_by;
    $journal->entry_date_time = date("Y-m-d H:i:s");

    if($journal->create()){
        $journal->debit = 0;
        $journal->credit = $data[0]->amount;
        $journal->gl_code = $data[0]->cd_gl_code;
        if($journal->create()){
            $msg_arr = array(
                "message" => "created"
            );
        }else{
            $msg_arr = array(
                "message" => "error 2nd create"
            );
        }
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>