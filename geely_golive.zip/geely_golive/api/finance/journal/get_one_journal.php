<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/journal.php';
     
    $database = new Database();
    $db = $database->getConnection();
    session_start();

    $journal = new Journal($db);
    $data = json_decode(file_get_contents("php://input"));

    $journal->ref_number = $data->ref_number;

    $journal->getOneJournal();

    $rdetail = array(
        "id" => (int)$journal->id,
        "date" => $journal->date,
        "ref_number" => $journal->ref_number,
        "gl_code" => $journal->gl_code,
        "debit" => $journal->debit,
        "credit" => $journal->credit,
        "description" => $journal->description,
        "entry_by" => $journal->entry_by,
        "entry_date_time" => $journal->entry_date_time,
        "name" => $journal->name
    );
    echo json_encode($rdetail);

?>