<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/staff.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $staff = new Staff($db);
    $data = json_decode(file_get_contents("php://input"));

    $staff->id = $data->id;
    $staff->getOneStaff();

    $arr = array(
        "card_no" =>  $staff->card_no,
        "join_date" => $staff->join_date,
        "department" => $staff->department,
        "position" => $staff->position,
        "name" => $staff->name,
        "dob" => $staff->dob,
        "gender" => $staff->gender,
        "nrc_no" => ($staff->nrc_no)?$staff->nrc_no:"",
        "marital_status" => $staff->marital_status,
        "phone" => $staff->phone,
        "email" => $staff->email,
        "contact_address" => $staff->contact_address,
        "permanent_address" => $staff->permanent_address,
        "reporting_to_id" => $staff->reporting_to_id,
        "reporting_to_name" => $staff->reporting_to_name,
        "reporting_to_position" => $staff->reporting_to_position,
        "signature" => $staff->signature,
        "id_card" => $staff->id_card,
        "wt_monday" => $staff->wt_monday,
        "wt_tuesday" => $staff->wt_tuesday,
        "wt_wednesday" => $staff->wt_wednesday,
        "wt_thursday" => $staff->wt_thursday,
        "wt_friday" => $staff->wt_friday,
        "wt_saturday" => $staff->wt_saturday,
        "wt_sunday" => $staff->wt_sunday
    );
    echo json_encode($arr);
?>