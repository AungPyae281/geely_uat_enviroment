<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/event.php';
    include_once '../../objects/event_detail.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $event = new event($db);
    $event_detail = new eventDetail($db);
    $data = json_decode(file_get_contents("php://input"));

    $event->name =$data->name;
    $event->voucher_no = $data->voucher_no;
    $event->date = $data->date;
    $event->done = $data->done;
    $event->entry_by = $_SESSION['user'];
    $event->entry_date_time = date("Y-m-d H:i:s");
    if($data->id){
        $event->id = $data->id;
        $event_detail->event_id = $data->id;
        if($event->update()){
            $event_detail->delete();
            foreach($data->event_details as $detail){
                $event_detail->event_id = $event->id;
                $event_detail->description = $detail->description;
                $event_detail->target = $detail->target;
                $event_detail->actual = $detail->actual;
                if(!$event_detail->create()){
                    $msg_arr = array(
                        "message" => "error_advance_detail"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
            }

            $msg_arr = array(
                "message" => "updated"
            );
        }else{
            $msg_arr = array(
                "message" => "error"
            );
        }
    }else{
        if($event->create()){
            foreach($data->event_details as $detail){
                $event_detail->event_id = $event->id;
                $event_detail->description = $detail->description;
                $event_detail->target = $detail->target;
                $event_detail->actual = $detail->actual;
                if(!$event_detail->create()){
                    $msg_arr = array(
                        "message" => "error_advance_detail"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
            }
            $msg_arr = array(
                "message" => "created"
            );
        }else{
            $msg_arr = array(
                "message" => "error"
            );
            echo json_encode($msg_arr);
            die();
        }
    }

    
    echo json_encode($msg_arr);
?>