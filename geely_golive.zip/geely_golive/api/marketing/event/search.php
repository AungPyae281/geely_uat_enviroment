<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/event.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $event = new Event($db);
    $data = json_decode(file_get_contents("php://input")); 

    $event->df = $data->df;
    $event->dt = $data->dt;
    $event->name = $data->name;

    $stmt = $event->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "id" => $id,
                "date" => $date,
                "voucher_no" => $voucher_no,
                "name" => $name,
                "entry_by" => $entry_by,
                "entry_date_time" => $entry_date_time,
                "total_amount" => str_replace(',', '', $voucher_no),
                // "total_amount" => $total_amount,
                "number_of_attendance_or_walk_in_act" => $number_of_attendance_or_walk_in_act,
                "number_of_test_drive_act" => $number_of_test_drive_act,
                "potential_act" => $potential_act,
                "booking_act" => $booking_act,
                "reach_act" => $reach_act,
                "react_act" => $react_act,
                "comment_act" => $comment_act,
                "share_act" => $share_act,
                "number_of_attendance_or_walk_in_tgt" => $number_of_attendance_or_walk_in_tgt,
                "number_of_test_drive_tgt" => $number_of_test_drive_tgt,
                "potential_tgt" => $potential_tgt,
                "booking_tgt" => $booking_tgt,
                "reach_tgt" => $reach_tgt,
                "react_tgt" => $react_tgt,
                "comment_tgt" => $comment_tgt,
                "share_tgt" => $share_tgt
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>