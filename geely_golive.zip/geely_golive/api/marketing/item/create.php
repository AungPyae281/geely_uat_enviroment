<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/m_item.php';
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$m_item = new MItem($db);
	$data = json_decode(file_get_contents("php://input"));

	$m_item->type = $data->type;
	$m_item->category = $data->category;
	$m_item->item_name = $data->item_name;
	$m_item->capital_price = $data->capital_price;
	$m_item->description = $data->description;

	if($data->id){
		$m_item->id = $data->id;
		if($m_item->update()){
			$msg_arr = array(
				"message" => "updated",
				"item_id" => $data->id
			);
		}else{
			$msg_arr = array(
				"message" => "errorIU"
			);
		}
	}else{
		if($m_item->isExist()){
			$msg_arr = array(
				"message" => "duplicate"
			);
		}else{
			if($m_item->create()){
			  	$msg_arr = array(
					"message" => "created",
					"item_id" => $m_item->id
				);
			}else{
				$msg_arr = array(
					"message" => "error"
				);
			}
		}
	}

	echo json_encode($msg_arr);
?>	