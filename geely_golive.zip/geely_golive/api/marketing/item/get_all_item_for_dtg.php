<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/m_item.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $m_item = new MItem($db);   

    $stmt = $m_item->getAllItem();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array(); 
    $i = 0;
    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                ++$i,
                $type,
                $category,
                $item_name,
                number_format($capital_price),
                $description,
                $id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>