<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/m_pages.php';
	include_once '../../objects/m_target_pages.php';
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$m_pages = new Pages($db);
	$m_target_pages = new MTargetPages($db);
	$data = json_decode(file_get_contents("php://input"));

	$m_pages->name = $data->name;

	$m_target_pages->month = date("Y-m");
	$m_target_pages->p_like = 0;
	$m_target_pages->p_reach = 0;
	$m_target_pages->p_engagement = 0;
	$m_target_pages->p_lead = 0;
	$m_target_pages->p_booking = 0;


	if($m_pages->isExist()){
		$arr = array(
			"message" => "duplicate"
		);
	}else{
		if($m_pages->create()){
			$m_target_pages->page_id = $m_pages->id;
			$m_target_pages->create();
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>