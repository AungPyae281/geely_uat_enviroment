<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_stock_balance.php';

$database = new Database();
$db = $database->getConnection();
 
$m_stock_balance = new MStockBalance($db);
$data = json_decode(file_get_contents("php://input"));

$m_stock_balance->category = $data->category;
$m_stock_balance->type = $data->type;
$m_stock_balance->item_name = $data->item_name;
$m_stock_balance->chk_qty = $data->chk_qty;
if($data->chk_qty==1){
    $m_stock_balance->qtyfrom = $data->qtyfrom;
    $m_stock_balance->qtyto = $data->qtyto;
    $m_stock_balance->sign = $data->sign;
}

$stmt = $m_stock_balance->search();
$num = $stmt->rowCount();
$arr=array();
$arr["records"]=array();
if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $item=array(
            "id" => (int)$id,
            "stock_out_date" => ($stock_out_date)?$stock_out_date:"",
            "type" => ($type)?$type:"",
            "category" => ($category)?$category:"",
            "item_name" => $item_name,
            "quantity" => (int)$quantity,
            "capital_price" => number_format($capital_price),
            "amount" => number_format($quantity * $capital_price)
        );
        $total_amount +=$quantity * $capital_price;
        array_push($arr["records"], $item);
    }
     $arr["total_amount"] = number_format($total_amount);
}
echo json_encode($arr);
?>