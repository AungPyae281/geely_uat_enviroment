<?php
// required headers
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_stock_in.php';
include_once '../../objects/m_stock_balance.php';

session_start();
date_default_timezone_set('Asia/Rangoon'); 

$database = new Database();
$db = $database->getConnection();

$m_stock_in = new MStockIn($db);
$m_stock_balance = new MStockBalance($db);
$data = json_decode(file_get_contents("php://input"));

$m_stock_in->stock_in_date = $data->stock_in_date;
$m_stock_in->store = "Main";
$m_stock_in->item_id = $data->item_id;
$m_stock_in->item_name = $data->item_name;
$m_stock_in->quantity = $data->quantity;
$m_stock_in->stock_in_by = $data->stock_in_by;
$m_stock_in->stock_in_receive_by = $data->stock_in_receive_by;
$m_stock_in->capital_price = $data->price;
$m_stock_in->entry_by = $_SESSION['user'];
$m_stock_in->entry_date_time = date("Y-m-d H:i");

$m_stock_balance->store = "Main";
$m_stock_balance->item_id = $data->item_id;
$m_stock_balance->item_name = $data->item_name;
$m_stock_balance->quantity = $data->quantity;
$m_stock_balance->plus = 1;


if($m_stock_in->create()){
    if($m_stock_balance->checkMaterial()){
        if($m_stock_balance->updateFromStockIn()){
            echo 'updated';
        }else{
            $m_stock_in->delete();
            echo 'error';
        }    
    }else{
        if($m_stock_balance->create()){
            echo 'created';
        }else{
            $m_stock_in->delete();
            echo 'error';
        }   
    }
}else{
    echo 'error';
}
?>