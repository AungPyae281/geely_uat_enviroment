<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_stock_in.php';

$database = new Database();
$db = $database->getConnection();
 
$m_stock_in = new MStockIn($db);
$data = json_decode(file_get_contents("php://input"));
 
$m_stock_in->df = $data->df; 
$m_stock_in->dt = $data->dt; 
$m_stock_in->item_name = $data->item_name;
$m_stock_in->stock_in_by = $data->stock_in_by;

$stmt = $m_stock_in->search();
$num = $stmt->rowCount();

$arr=array();
$arr["records"]=array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $stock_in=array(
            "id" => (int)$id,
            "stock_in_date" => $stock_in_date,
            "type" => $type,
            "category" => $category,
            "store" => $store,
            "stock_in_by" => $stock_in_by,
            "quantity" => $quantity,
            "item_name" => ($item_name)?$item_name:"",
            "stock_in_receive_by" => $stock_in_receive_by,
            "price" => $capital_price
        );  
        array_push($arr["records"], $stock_in);
    }
}
echo json_encode($arr);
?>