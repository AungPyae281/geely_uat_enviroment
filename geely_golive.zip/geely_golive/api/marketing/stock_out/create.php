<?php
// required headers
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_stock_out.php';
include_once '../../objects/m_stock_balance.php';
session_start();
date_default_timezone_set('Asia/Rangoon'); 

$database = new Database();
$db = $database->getConnection();
 
$m_stock_out = new MStockOut($db);
$m_stock_balance = new MStockBalance($db);
$data = json_decode(file_get_contents("php://input"));

$m_stock_out->stock_out_date = $data->stock_out_date;
$m_stock_out->store = "Main";
$m_stock_out->item_id = $data->item_id;
$m_stock_out->item_name = $data->item_name;
$m_stock_out->quantity = $data->quantity;
$m_stock_out->use = $data->use;
$m_stock_out->lost = $data->lost;
$m_stock_out->damage = $data->damage;
$m_stock_out->expire = $data->expire;
$m_stock_out->stock_out_by = $data->stock_out_by;
$m_stock_out->stock_out_receive_by = $data->stock_out_receive_by;
$m_stock_out->remark = $data->remark;
$m_stock_out->entry_by = $_SESSION['user'];
$m_stock_out->entry_date_time = date("Y-m-d H:i");

$m_stock_balance->store = "Main";
$m_stock_balance->item_id = $data->item_id;
$m_stock_balance->item_name = $data->item_name;
$m_stock_balance->quantity = $data->quantity;
$m_stock_balance->use = $data->use;
$m_stock_balance->lost = $data->lost;
$m_stock_balance->damage = $data->damage;
$m_stock_balance->expire = $data->expire;
$m_stock_balance->plus = 1;

if($m_stock_balance->checkItemForStockOut()){
    if($m_stock_out->create()){
        if($m_stock_balance->updateFromStockOut()){
            echo 'created';
        }else{
            $m_stock_out->delete();
            echo 'error1';
        }    
    }else{
        echo 'error2';
    }
}else{
    echo 'error3';
}
?>