<?php
// required headers
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_stock_out.php';
include_once '../../objects/m_stock_balance.php';
 
$database = new Database();
$db = $database->getConnection();

$m_stock_out = new StockOut($db);
$m_stock_balance = new StockBalance($db);
$data = json_decode(file_get_contents("php://input"));

$m_stock_out->id = $data->id;

$m_stock_out->getOneRow();

$m_stock_balance->store = $stock_in->store;
$m_stock_balance->item_id = $stock_in->item_id;
$m_stock_balance->item_name = $stock_in->item_name;
$m_stock_balance->quantity = $stock_in->quantity;
$m_stock_balance->plus = 0;
 
if($m_stock_out->delete()){
    if($m_stock_balance->updateFromStockOut()){
        $msg_arr = array(
            "message" => "deleted"
        );
    }    
}else{
    $msg_arr = array(
        "message" => "error"
    );
}
echo json_encode($msg_arr);
?>