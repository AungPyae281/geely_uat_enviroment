<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_target_pages.php';

$database = new Database();
$db = $database->getConnection();
 
$m_target_pages = new MTargetPages($db);
$data = json_decode(file_get_contents("php://input"));

$m_target_pages->month = $data->month; 
$m_target_pages->page_name = $data->page_name;

$stmt = $m_target_pages->getAllRows();

$num = $stmt->rowCount();
$arr=array();
$arr["records"]=array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $m_target_pages=array(
            "id" => (int)$id,
            "page_id" => $page_id,
            "month" => $month,
            "page_name" => $page_name,
            "p_like" => number_format($p_like),
            "p_reach" => number_format($p_reach),
            "p_engagement" => number_format($p_engagement),
            "p_lead" => number_format($p_lead),
            "p_booking" => number_format($p_booking)
        );
 
        array_push($arr["records"], $m_target_pages);
    }   
}
echo json_encode($arr);
?>