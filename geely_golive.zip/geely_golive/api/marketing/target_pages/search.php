<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_target_pages.php';

$database = new Database();
$db = $database->getConnection();
 
$m_target_pages = new MTargetPages($db);
$data = json_decode(file_get_contents("php://input"));
 
$m_target_pages->year = $data->year;
$m_target_pages->page_name = $data->page_name;

$stmt = $m_target_pages->search();
$num = $stmt->rowCount();

$arr=array();
$arr["records"]=array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $data=array(
            "id" => (int)$id,
            "name" => $name,
            "reason" => $reason,
            "january" => $january,
            "february" => $february,
            "march" => $march,
            "april" => $april,
            "may" => $may,
            "june" => $june,
            "july" => $july,
            "august" => $august,
            "september" => $september,
            "october" => $october,
            "november" => $november,
            "december" => $december
        );  
        array_push($arr["records"], $data);
    }
}
echo json_encode($arr);
?>