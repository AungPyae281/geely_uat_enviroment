<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../objects/m_target_pages.php';

$database = new Database();
$db = $database->getConnection();
 
$m_target_pages = new MTargetPages($db);
$data = json_decode(file_get_contents("php://input"));

$m_target_pages->page_name = $data->page_name;
$col1 = $data->col1;
$col2 = $data->col2;
$col3 = $data->col3;
$col4 = $data->col4;
$col5 = $data->col5;
$col6 = $data->col6;
$col7 = $data->col7;
$col8 = $data->col8;
$col9 = $data->col9;
$col10 = $data->col10;
$col11 = $data->col11;
$col12 = $data->col12;

$stmt = $m_target_pages->getMonthlyPages($col1, $col2, $col3, $col4, $col5, $col6, $col7, $col8, $col9, $col10, $col11, $col12);

$num = $stmt->rowCount();
$arr=array();
$arr["records"]=array();

if($num>0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $m_target_pages=array(
            "page_name" => $page_name,
			"col1" => (int)$col1,
			"col2" => (int)$col2,
			"col3" => (int)$col3,
			"col4" => (int)$col4,
			"col5" => (int)$col5,
			"col6" => (int)$col6,
			"col7" => (int)$col7,
			"col8" => (int)$col8,
			"col9" => (int)$col9,
			"col10" => (int)$col10,
			"col11" => (int)$col11,
			"col12" => (int)$col12			
        );
 
        array_push($arr["records"], $m_target_pages);
    }   
}
echo json_encode($arr);
?>