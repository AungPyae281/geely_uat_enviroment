<?php
// required headers
header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/m_target_pages.php';
date_default_timezone_set('Asia/Rangoon');  
session_start();

$database = new Database();
$db = $database->getConnection();
 
$m_target_pages = new MTargetPages($db);
$data = json_decode(file_get_contents("php://input"));

$m_target_pages->page_id = $data->page_id;
$m_target_pages->month = $data->month;
$m_target_pages->amount = $data->amount;
$m_target_pages->col_name = $data->col_name;
// $m_target_pages->edited_by = $_SESSION['user'];
// $m_target_pages->edited_date_time = date("Y-m-d H:i:s");

if($m_target_pages->update()){
	echo 'updated';
}else{
	echo 'error';
}
?>