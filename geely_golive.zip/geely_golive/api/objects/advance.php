<?php
class Advance{ 
	private $conn;
	private $table_name = "advance";
 
    public $id;	
	public $date;
	public $receive_by;
	public $description;
	public $request_no;
	public $voucher_no;
	public $gm_approval;
	public $ceo_approval;
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET date=:date, receive_by=:receive_by, description=:description, request_no=:request_no, voucher_no=:voucher_no, gm_approval=:gm_approval, ceo_approval=:ceo_approval, upload_receipt=:upload_receipt, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":receive_by", $this->receive_by);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":request_no", $this->request_no);
		$stmt->bindParam(":voucher_no", $this->voucher_no);
		$stmt->bindParam(":gm_approval", $this->gm_approval);
		$stmt->bindParam(":ceo_approval", $this->ceo_approval);
		$stmt->bindParam(":upload_receipt", $this->upload_receipt);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	// function create(){
	// 	$query = "INSERT INTO " . $this->table_name . " SET date=:date, receive_by=:receive_by, description=:description, request_no=:request_no, voucher_no=:voucher_no, upload_receipt=:upload_receipt, entry_by=:entry_by, entry_date_time=:entry_date_time";

	// 	$stmt = $this->conn->prepare($query);

	// 	$stmt->bindParam(":date", $this->date); 
	// 	$stmt->bindParam(":receive_by", $this->receive_by);
	// 	$stmt->bindParam(":description", $this->description);
	// 	$stmt->bindParam(":request_no", $this->request_no);
	// 	$stmt->bindParam(":voucher_no", $this->voucher_no);
	// 	$stmt->bindParam(":upload_receipt", $this->upload_receipt);
	// 	$stmt->bindParam(":entry_by", $this->entry_by);
	// 	$stmt->bindParam(":entry_date_time", $this->entry_date_time);

	// 	if($stmt->execute()){
	// 		$this->id = $this->conn->lastInsertId();
	// 		return true;
	// 	}
	// 	return false;		
	// }

	function getAllRows(){
		$condition = "";	

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " date = :date ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY `date`, account_from, account_to DESC";
		$stmt = $this->conn->prepare( $query );
		if($this->date) $stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getOneAdvanceBalance(){
		$query = "SELECT aa.*, SUM(advance.amount) AS sec_balance, SUM(advance.amount) - aa.fir_advance_balance as advance_balance FROM ( SELECT SUM(advance_claim.amount) AS fir_advance_balance, advance_claim.gl_code_from
			FROM advance_claim
			WHERE
			REPLACE(advance_claim.gl_code_from, '/', '')=:gl_code_to) AS aa JOIN advance ON advance.gl_code_to=aa.gl_code_from
			WHERE
			REPLACE(advance.gl_code_to, '/', '')=:gl_code_to";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);	
		$stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->advance_balance = $row['advance_balance'];
        }
	}

	function getAllPaymentForDTG(){
		$query = "SELECT `date`, voucher_no, request_no, receive_by, `description`, total_payment, id
		FROM advance
		JOIN (
		SELECT SUM(amount) AS total_payment, advance_id
		FROM advance_detail
		GROUP BY advance_detail.advance_id) AS dtl ON advance.id=dtl.advance_id";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllPaymentForMarketingDTG(){
		$query = "SELECT `date`, voucher_no, request_no, receive_by, `description`, total_payment, id
		FROM advance
		JOIN (
		SELECT SUM(amount) AS total_payment, advance_id
		FROM advance_detail
		GROUP BY advance_detail.advance_id) AS dtl ON advance.id=dtl.advance_id";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllPaymentForExpenseDTG(){
		$query = "SELECT fnl.*
		FROM (
		    SELECT `date`, voucher_no, request_no, receive_by, `description`, total_payment, id
		    FROM advance
		    JOIN (
		        SELECT SUM(amount) AS total_payment, advance_id
		        FROM advance_detail
		        GROUP BY advance_detail.advance_id
		    ) AS dtl ON advance.id = dtl.advance_id
		) AS fnl
		LEFT JOIN expense 
		    ON FIND_IN_SET(fnl.voucher_no, REPLACE(expense.payment_voucher_no, '|', ',')) > 0
		WHERE expense.payment_voucher_no IS NULL";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function search(){
        $condition = "";
        
        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " advance.date >= :df";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " advance.date <= :dt";
        }

        if($this->voucher_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " voucher_no = :voucher_no";
        }

        if($this->brand){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " brand = :brand";
        }

        if($this->requester){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (staff.name LIKE  :requester '%' or staff.name LIKE '%' :requester '%' or staff.name Like '%' :requester )";
        }

        if($this->requet_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " advance.requet_no = :requet_no";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT advance.*, SUM(amount) AS amount, staff.name, advance_expense_request.brand, advance_detail.gl_code_bank_or_cash, gl_account.name FROM advance LEFT JOIN advance_detail ON advance.id=advance_detail.advance_id
LEFT JOIN advance_expense_request ON advance.request_no=advance_expense_request.request_number
LEFT JOIN staff ON advance_expense_request.staff_id=staff.id 
LEFT JOIN gl_account ON advance_detail.gl_code_bank_or_cash=gl_account.gl_code " . $condition . " group by voucher_no ORDER BY date DESC, voucher_no DESC";
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->voucher_no) $stmt->bindParam(":voucher_no", $this->voucher_no);
        if($this->brand) $stmt->bindParam(":brand", $this->brand);
        if($this->requester) $stmt->bindParam(":requester", $this->requester);
        if($this->requet_no) $stmt->bindParam(":requet_no", $this->requet_no);
        $stmt->execute();
        return $stmt;
    }
}
