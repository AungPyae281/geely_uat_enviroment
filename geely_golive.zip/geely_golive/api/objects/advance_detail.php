<?php
class AdvanceDetail{ 
	private $conn;
	private $table_name = "advance_detail";
 
    public $id;	
	public $advance_id;
	public $due_days;
	public $gl_code_to;
	public $amount;
	public $description; 
	public $job_code;
	public $gl_code_bank_or_cash;
	public $journal_ref_number;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET advance_id=:advance_id, due_days=:due_days, gl_code_to=:gl_code_to, amount=:amount, description=:description, job_code=:job_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, journal_ref_number=:journal_ref_number";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":advance_id", $this->advance_id);
		$stmt->bindParam(":due_days", $this->due_days);
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":description", $this->description); 
		$stmt->bindParam(":job_code", $this->job_code); 
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":journal_ref_number", $this->journal_ref_number);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " date = :date ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY `date`, account_from, account_to DESC";
		$stmt = $this->conn->prepare( $query );
		if($this->date) $stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getOneAdvanceBalance(){
		$query = "SELECT aa.*, SUM(advance.amount) AS sec_balance, SUM(advance.amount) - aa.fir_advance_balance as advance_balance FROM ( SELECT SUM(advance_claim.amount) AS fir_advance_balance, advance_claim.gl_code_from
			FROM advance_claim
			WHERE
			REPLACE(advance_claim.gl_code_from, '/', '')=:gl_code_to) AS aa JOIN advance ON advance.gl_code_to=aa.gl_code_from
			WHERE
			REPLACE(advance.gl_code_to, '/', '')=:gl_code_to";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);	
		$stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->advance_balance = $row['advance_balance'];
        }
	}
}
