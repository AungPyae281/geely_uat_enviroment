<?php
class AdvanceExpenseRequest{ 
	private $conn;
	private $table_name = "advance_expense_request"; 

	public $id;
	public $request_number;
	public $request_date;
	public $brand;
	public $staff_id;
	public $remark; 
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET request_number=:request_number, entry_date_time=:entry_date_time, entry_by=:entry_by, request_date=:request_date, brand=:brand, staff_id=:staff_id, remark=:remark";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":request_number", $this->request_number);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":request_date", $this->request_date);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":remark", $this->remark);
	 
		if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE request_number=:request_number";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":request_number", $this->request_number);
	 
		if($stmt->execute()){
			return true;
		}
		return false;
    }

	function getRequestList(){
    	$condition = "";
        if(strpos($this->position, "manager")!== false){
            $condition .= " Where staff_id=:staff_id";
        }

		$query = "SELECT las.*, advance.request_no FROM advance right JOIN (SELECT * FROM (SELECT fnl.*, staff.name FROM staff JOIN (SELECT APV.*, SUM(qty * cost_per_unit) AS total_amount
FROM advance_expense_request_detail
JOIN (
SELECT advance_expense_request.*, AVC.*
FROM advance_expense_request
JOIN (
SELECT role,PROCESS , main_id, COUNT(*) AS approve_count
FROM approval
WHERE `process`=:process AND approve=0
GROUP BY main_id) AS AVC ON advance_expense_request.request_number=AVC.main_id) AS APV ON
APV.id=advance_expense_request_detail.advance_expense_request_id " . $condition . " GROUP BY main_id order BY request_date) AS fnl ON fnl.staff_id=staff.id
		UNION ALL
		SELECT fnl.*, staff.name FROM staff JOIN (SELECT APV.*, SUM(qty * cost_per_unit) AS total_amount
FROM advance_expense_request_detail
JOIN (
SELECT advance_expense_request.*, AVC.*
FROM advance_expense_request
JOIN (
SELECT role,PROCESS , main_id, COUNT(*) AS approve_count
FROM approval
WHERE `process`=:process AND approve=1
GROUP BY main_id) AS AVC ON advance_expense_request.request_number=AVC.main_id) AS APV ON
APV.id=advance_expense_request_detail.advance_expense_request_id " . $condition . " GROUP BY main_id order BY request_date) AS fnl ON fnl.staff_id=staff.id) AS tt GROUP BY tt.main_id) as las ON advance.request_no=las.request_number WHERE advance.request_no IS NULL";

		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":process", $this->process);
		if(strpos($this->position, "manager")!== false) $stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->execute();
		return $stmt;
	}

	function getGenerateCode($prefix){
		$query = "SELECT request_number FROM `" . $this->table_name . "` WHERE request_number like '$prefix%'  ORDER BY request_number desc limit 0,1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%'05d", ((int)str_replace($prefix,"",$row['request_number']) + 1));
		}else{
			return $prefix . "00001";
		}
	}

	function getOneRequest(){
		$query = "SELECT advance_expense_request.*, staff.name as staff_name FROM " . $this->table_name . " left join staff on advance_expense_request.staff_id=staff.id WHERE request_number=:request_number LIMIT 0,1";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":request_number", $this->request_number);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->request_number = $row['request_number'];
			$this->request_date = $row['request_date'];	
			$this->brand = $row['brand'];
			$this->entry_by = $row['entry_by'];
			$this->staff_id = $row['staff_id'];
			$this->remark = $row['remark'];
			$this->staff_name = $row['staff_name'];
			$this->entry_date_time = $row['entry_date_time'];
		}
	}
}
?>