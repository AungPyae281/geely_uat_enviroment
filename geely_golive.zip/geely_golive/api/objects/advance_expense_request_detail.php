<?php
class AdvanceExpenseRequestDetail{ 
	private $conn;
	private $table_name = "advance_expense_request_detail"; 

	public $id;
	public $advance_expense_request_id;
	public $description;
	public $reason;
	public $qty;
	public $cost_per_unit;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET advance_expense_request_id=:advance_expense_request_id, description=:description, reason=:reason, qty=:qty, cost_per_unit=:cost_per_unit";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":advance_expense_request_id", $this->advance_expense_request_id);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":reason", $this->reason);
		$stmt->bindParam(":qty", $this->qty);
		$stmt->bindParam(":cost_per_unit", $this->cost_per_unit);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function updateDescription(){
		$query = "UPDATE " . $this->table_name . " SET description=:description where id=:id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":description", $this->description); 
		$stmt->bindParam(":id", $this->id); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function updateReason(){
		$query = "UPDATE " . $this->table_name . " SET reason=:reason where id=:id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":reason", $this->reason); 
		$stmt->bindParam(":id", $this->id); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getRequestDetail(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE advance_expense_request_detail.advance_expense_request_id=:advance_expense_request_id";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":advance_expense_request_id", $this->advance_expense_request_id);
		$stmt->execute();
		return $stmt;
	}

	function getAdvanceExpenseRequestID(){
		$query = "SELECT * FROM advance_expense_request WHERE request_number=:request_number";

		$stmt = $this->conn->prepare( $query );

		$stmt->bindParam(":request_number", $this->request_number);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = (int)$row['id'];
		}
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE advance_expense_request_id=:advance_expense_request_id";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":advance_expense_request_id", $this->advance_expense_request_id);
	 
		if($stmt->execute()){
			return true;
		}
		return false;
    }
}
?>