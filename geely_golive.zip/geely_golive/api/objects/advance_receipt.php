<?php
class AdvanceReceipt{ 
	private $conn;
	private $table_name = "advance_receipt";
 
    public $id;	
	public $receipt_date;
	public $settlement_date;
	public $customer_id;
	public $gl_code;
	public $gl_code_bank_or_cash_debit;
	public $gl_code_bank_or_cash_credit;
	public $amount; 
	public $description; 
	public $receive_by; 
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$statement = "";
		if($this->upload_receipt!=""){
			$statement = ", upload_receipt=:upload_receipt ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET receipt_date=:receipt_date, customer_id=:customer_id, gl_code=:gl_code, gl_code_bank_or_cash_debit=:gl_code_bank_or_cash_debit, amount=:amount, description=:description, receive_by=:receive_by, entry_by=:entry_by, entry_date_time=:entry_date_time" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":receipt_date", $this->receipt_date);
		$stmt->bindParam(":customer_id", $this->customer_id);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash_debit", $this->gl_code_bank_or_cash_debit);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":receive_by", $this->receive_by);
		if($this->upload_receipt!="") $stmt->bindParam(":upload_receipt", $this->upload_receipt);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET settlement_date=:settlement_date, gl_code_bank_or_cash_credit=:gl_code_bank_or_cash_credit, settlement_by=:settlement_by, settlement_date_time=:settlement_date_time WHERE id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":settlement_date", $this->settlement_date);
		$stmt->bindParam(":gl_code_bank_or_cash_credit", $this->gl_code_bank_or_cash_credit);
		$stmt->bindParam(":settlement_by", $this->settlement_by);
		$stmt->bindParam(":settlement_date_time", $this->settlement_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllReceiptList(){
		$query = "SELECT advance_receipt.*, customer.registration_no AS customer_registration_no, customer.name AS customer_name, concat(gl_account.gl_code, ' (', gl_account.name, ')') AS bank_cash_account FROM " . $this->table_name . " LEFT JOIN customer ON advance_receipt.customer_id=customer.id
LEFT JOIN gl_account ON advance_receipt.gl_code_bank_or_cash_debit=gl_account.gl_code WHERE gl_code_bank_or_cash_credit='' ORDER BY receipt_date";
		$stmt = $this->conn->prepare($query);		
		$stmt->execute();
		return $stmt;
	} 
}
?>