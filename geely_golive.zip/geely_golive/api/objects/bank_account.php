<?php
class BankAccount{ 
	private $conn;
	private $table_name = "bank_account";
 
	public $id;
	public $gl_code;
	public $country;
	public $bank_name; 
	public $branch;
	public $swift_code;
	public $currency;
	public $account_no;
	public $account_name;
	public $account_type;
	public $opening_balance;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE account_no=:account_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query ); 
		$stmt->bindParam(":account_no", $this->account_no); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function isExistForUpdate(){
		$query = "SELECT bank_account.id FROM bank_account JOIN trial_balance ON bank_account.gl_code=trial_balance.gl_code WHERE bank_account.gl_code=:gl_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query ); 
		$stmt->bindParam(":gl_code", $this->gl_code); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function update(){
    	$query = "UPDATE " . $this->table_name . " SET `country`=:country, `bank_name`=:bank_name, `branch`=:branch, `swift_code`=:swift_code, `currency`=:currency, `account_no`=:account_no, `account_name`=:account_name, `account_type`=:account_type, `opening_balance`=:opening_balance, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time where id=:id";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":country", $this->country);	
		$stmt->bindParam(":bank_name", $this->bank_name);	
		$stmt->bindParam(":branch", $this->branch);	
		$stmt->bindParam(":swift_code", $this->swift_code);	
		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":account_no", $this->account_no);	
		$stmt->bindParam(":account_name", $this->account_name);	
		$stmt->bindParam(":account_type", $this->account_type);	
		$stmt->bindParam(":opening_balance", $this->opening_balance);	
		$stmt->bindParam(":entry_by", $this->entry_by);	
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	
		$stmt->bindParam(":id", $this->id);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gl_code=:gl_code, country=:country, bank_name=:bank_name, branch=:branch, swift_code=:swift_code, currency=:currency, account_no=:account_no, account_name=:account_name, account_type=:account_type, opening_balance=:opening_balance, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":country", $this->country);
		$stmt->bindParam(":bank_name", $this->bank_name);
		$stmt->bindParam(":branch", $this->branch);
		$stmt->bindParam(":swift_code", $this->swift_code);
		$stmt->bindParam(":currency", $this->currency);
		$stmt->bindParam(":account_no", $this->account_no);
		$stmt->bindParam(":account_name", $this->account_name);
		$stmt->bindParam(":account_type", $this->account_type);
		$stmt->bindParam(":opening_balance", $this->opening_balance);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}

	function getAllBankAccount(){
		$condition = "";	

		if($this->country){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " bank_account.country =:country ";
		}

		if($this->currency){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " bank_account.currency =:currency ";
		} 

		if($condition!=""){
			$condition = " WHERE " . $condition;
		} 

		$query = "SELECT bank_account.*, (opening_balance + IFNULL(SUM(debit), 0) - IFNULL(SUM(credit), 0)) AS balance, IFNULL(er.rate, 0) AS rate FROM bank_account
LEFT JOIN (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit FROM (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit
FROM trial_balance group by gl_code
UNION
SELECT gl_code_ref AS gl_code, SUM(debit) AS debit, SUM(credit) AS credit
FROM trial_balance group by gl_code_ref) AS fir group by fir.gl_code) AS tb ON bank_account.gl_code=tb.gl_code
LEFT JOIN (SELECT currency, rate FROM exchange_rate WHERE id IN (SELECT MAX(id) FROM exchange_rate WHERE `date`<=:date GROUP BY currency)) AS er ON bank_account.currency=er.currency
GROUP BY bank_account.gl_code " . $condition . " ORDER BY bank_account.country, bank_account.bank_name, bank_account.account_name";

		$stmt = $this->conn->prepare($query);
		 
		if($this->country) $this->country=htmlspecialchars(strip_tags($this->country));
		if($this->currency) $this->currency=htmlspecialchars(strip_tags($this->currency));
		
		if($this->country) $stmt->bindParam(":country", $this->country);
		if($this->currency) $stmt->bindParam(":currency", $this->currency);
		$stmt->bindParam(":date", $this->date);
		
		$stmt->execute();
		return $stmt;
	} 

	function getAllBankAndCashAccount(){
		$query = "SELECT gl_account.*, IFNULL(bank_account.id, 0) as bank_id, (IFNULL(bank_account.opening_balance, 0) + SUM(IFNULL(debit, 0)) - SUM(IFNULL(credit, 0))) AS balance FROM gl_account
LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
LEFT JOIN (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit FROM trial_balance GROUP BY gl_code) AS tb ON bank_account.gl_code=tb.gl_code
WHERE gl_account.category IN ('Bank', 'Cash')
GROUP BY gl_account.gl_code
ORDER BY gl_account.gl_code, gl_account.`name`";
		$stmt = $this->conn->prepare($query);	
		$stmt->execute();
		return $stmt;
	} 

	function getAllBankAndCashMMKAccount(){
		$query = "SELECT gl_account.*, IFNULL(bank_account.id, 0) as bank_id, (IFNULL(bank_account.opening_balance, 0) + SUM(IFNULL(debit, 0)) - SUM(IFNULL(credit, 0))) AS balance FROM gl_account
LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
LEFT JOIN (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit FROM trial_balance GROUP BY gl_code) AS tb ON bank_account.gl_code=tb.gl_code
WHERE gl_account.category IN ('Bank', 'Cash') AND gl_account.currency IN ('MMK','')
GROUP BY gl_account.gl_code
ORDER BY gl_account.gl_code, gl_account.`name`";
		$stmt = $this->conn->prepare($query);	
		$stmt->execute();
		return $stmt;
	} 

	function getOneRowByGLCode(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE	gl_code = :gl_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->gl_code = $row['gl_code'];
			$this->country = $row['country'];
			$this->bank_name = $row['bank_name'];
			$this->branch = $row['branch'];
			$this->swift_code = $row['swift_code'];	
			$this->currency = $row['currency'];
			$this->account_no = $row['account_no'];
			$this->account_name = $row['account_name'];
			$this->account_type = $row['account_type'];	
		}
	}
}
?>