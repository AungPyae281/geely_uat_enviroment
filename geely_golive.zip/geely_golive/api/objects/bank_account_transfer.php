<?php
class BankAccountTransfer{ 
	private $conn;
	private $table_name = "bank_account_transfer";
 
    public $id;	
	public $gl_code_from;
	public $account_from;
	public $gl_code_to;
	public $account_to;
	public $date;
	public $amount_from;
	public $amount_to; 
	public $exchange_rate; 
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gl_code_from=:gl_code_from, account_from=:account_from, gl_code_to=:gl_code_to, account_to=:account_to, date=:date, amount_from=:amount_from, amount_to=:amount_to, exchange_rate=:exchange_rate, upload_receipt=:upload_receipt, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gl_code_from", $this->gl_code_from);
		$stmt->bindParam(":account_from", $this->account_from);
		$stmt->bindParam(":gl_code_to", $this->gl_code_to);
		$stmt->bindParam(":account_to", $this->account_to);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":amount_from", $this->amount_from);
		$stmt->bindParam(":amount_to", $this->amount_to); 
		$stmt->bindParam(":exchange_rate", $this->exchange_rate); 
		$stmt->bindParam(":upload_receipt", $this->upload_receipt);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " date = :date ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY `date`, account_from, account_to DESC";
		$stmt = $this->conn->prepare( $query );
		if($this->date) $stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}
	
}
