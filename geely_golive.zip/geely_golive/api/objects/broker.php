<?php
class Broker{
	private $conn;
	private $table_name = "broker";

	public $id;
	public $registration_no;
	public $name;
	public $gender;
	public $dob;
	public $nrc_no;
	public $phone;
	public $email;
	public $address; 
	public $company;
	public $register_date;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}
 
	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `name`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getGenerateRegistrationNo($prefix){
		$query = "SELECT registration_no FROM `" . $this->table_name . "` WHERE registration_no like ? ORDER BY registration_no DESC LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$keywords = htmlspecialchars(strip_tags($prefix));
		$keywords = "{$keywords}%";
		
		$stmt->bindParam(1, $keywords);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%03d", ((int)str_replace($prefix, "", $row['registration_no']) + 1));
		}else{
			return $prefix . "001";
		}
	}

	function checkBroker(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE nrc_no=:nrc_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":nrc_no", $this->nrc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET 
		registration_no=:registration_no
		, name=:name
		, gender=:gender
		, dob=:dob
		, nrc_no=:nrc_no
		, phone=:phone
		, email=:email
		, register_date=:register_date  
		, company=:company 
		, address=:address 
        , entry_by=:entry_by
        , entry_date_time=:entry_date_time";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":gender", $this->gender);
		$stmt->bindParam(":dob", $this->dob);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
        $stmt->bindParam(":phone", $this->phone);	
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":register_date", $this->register_date); 
        $stmt->bindParam(":company", $this->company);
        $stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
    }

    function update(){
		$query = "UPDATE " . $this->table_name . " SET
		name=:name
		, gender=:gender
		, dob=:dob
		, nrc_no=:nrc_no
		, phone=:phone
		, email=:email
		, register_date=:register_date  
		, company=:company 
		, address=:address WHERE id=:id";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":gender", $this->gender);
		$stmt->bindParam(":dob", $this->dob);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
        $stmt->bindParam(":phone", $this->phone);	
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":register_date", $this->register_date); 
        $stmt->bindParam(":company", $this->company);
        $stmt->bindParam(":address", $this->address);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE	id = ? LIMIT 0,1";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(1, $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->registration_no = $row['registration_no'];
			$this->name = $row['name'];
			$this->gender = $row['gender'];
			$this->dob = $row['dob'];
			$this->nrc_no = $row['nrc_no'];	
			$this->phone = $row['phone'];
			$this->email = $row['email'];
			$this->address = $row['address']; 
			$this->company = $row['company'];
			$this->register_date = $row['register_date'];
			$this->entry_by = $row['entry_by'];
			$this->entry_date_time = $row['entry_date_time'];
		}
	}

	function autocomplete(){
        $condition = "";
        
        if($this->name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (name LIKE  :name '%' or name LIKE '%' :name '%' or name Like '%' :name )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY name";
        $stmt = $this->conn->prepare($query);
        if($this->name) $stmt->bindParam(":name", $this->name);
        $stmt->execute();
        return $stmt;
    }
}
?>