<?php
class CarAdditionalCharges{
    // database connection and table name
	private $conn;
	private $table_name = "car_additional_charges";

    // object properties
    public $id;	
	public $vin_no;
	public $reason;
	public $remark;
	public $amount;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY reason";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET vin_no=:vin_no, reason=:reason, remark=:remark, amount=:amount, entry_by=:entry_by, entry_date_time=:entry_date_time"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":vin_no", $this->vin_no); 
		$stmt->bindParam(":reason", $this->reason); 
		$stmt->bindParam(":remark", $this->remark); 
		$stmt->bindParam(":amount", $this->amount); 
		$stmt->bindParam(":entry_by", $this->entry_by); 
		$stmt->bindParam(":entry_date_time", $this->entry_date_time); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
}
