<?php
class CarAdditionalChargesReason{
    // database connection and table name
	private $conn;
	private $table_name = "car_additional_charges_reason";

    // object properties
    public $id;	
	public $reason;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY reason";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `reason` = :reason LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->reason = htmlspecialchars(strip_tags($this->reason)); 
		$stmt->bindParam(":reason", $this->reason); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET reason=:reason"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":reason", $this->reason); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
	
}
