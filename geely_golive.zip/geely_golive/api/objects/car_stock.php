<?php
class CarStock{
	// database connection and table name
	private $conn;
	private $table_name = "car_stock";

	// object properties
	public $id;
	public $car_list_id;
	public $production_order_id;
	public $oc_no;
	public $sales_id;
	public $lot_no;
	public $bl_no;
	public $import_license_no;
	public $id_no;
	public $bounded_approval_code;
	public $brand;
	public $model;
	public $model_year;
	public $grade;
	public $engine_power;
	public $interior_color;
	public $exterior_color;
	public $vin_no;
	public $engine_no;
	public $stock_status;
	public $location;
	public $entry_by;
	public $entry_date_time;
	public $vehicle_price;
	public $json_id;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function checkCar($vin_no, $engine_no){
		$query = "SELECT id, vin_no, engine_no FROM " . $this->table_name . " WHERE vin_no=:vin_no OR engine_no=:engine_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":vin_no", $vin_no);
		$stmt->bindParam(":engine_no", $engine_no);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->vin_no = $row["vin_no"];
			$this->engine_no = $row["engine_no"];
			return true;
		}
		return false;
    }

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_list_id=:car_list_id, production_order_id=:production_order_id, oc_no=:oc_no, sales_id=:sales_id, brand=:brand, model=:model, model_year=:model_year, grade=:grade, engine_power=:engine_power, interior_color=:interior_color, exterior_color=:exterior_color, vin_no=:vin_no, engine_no=:engine_no, stock_status=:stock_status, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_list_id", $this->car_list_id);
		$stmt->bindParam(":production_order_id", $this->production_order_id);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":sales_id", $this->sales_id);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":interior_color", $this->interior_color);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);
		$stmt->bindParam(":stock_status", $this->stock_status);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	// Start for check
	function getAllStockByStatus(){
		$condition = "";	
		if($this->stock_status){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " stock_status =:stock_status ";
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		} 
		$query = "SELECT car_stock.*, transporter_name, transporter_phone FROM " . $this->table_name . " LEFT JOIN (SELECT car_stock_id, transporter_name, transporter_phone FROM car_outbound_transfer order BY entry_date_time DESC LIMIT 0, 1) AS a ON car_stock.id=a.car_stock_id" . $condition . " ORDER BY car_stock.id";
		$stmt = $this->conn->prepare($query);
		if($this->stock_status) $this->stock_status=htmlspecialchars(strip_tags($this->stock_status));
		if($this->stock_status) $stmt->bindParam(":stock_status", $this->stock_status);
		$stmt->execute();
		return $stmt;
	}

	function checkIDNO($id){
		$query = "SELECT id_no FROM " . $this->table_name . " WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			extract($row);
			return $id_no;
		}
    }

    function checkBAC($id){
		$query = "SELECT bounded_approval_code FROM " . $this->table_name . " WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			extract($row);
			return $bounded_approval_code;
		}
    }

    function updateOutboundTransfer(){
		$query = " UPDATE  " . $this->table_name . " SET bl_no=:bl_no, import_license_no=:import_license_no, lot_no=:lot_no, id_no=:id_no, bounded_approval_code=:bounded_approval_code, `stock_status`=:stock_status, `location`=:location WHERE id=:id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":bl_no", $this->bl_no);
		$stmt->bindParam(":import_license_no", $this->import_license_no);
		$stmt->bindParam(":lot_no", $this->lot_no);
		$stmt->bindParam(":id_no", $this->id_no);
		$stmt->bindParam(":bounded_approval_code", $this->bounded_approval_code);
		$stmt->bindParam(":stock_status", $this->stock_status);
		$stmt->bindParam(":location", $this->location);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function updateSupplyChainReceive(){
		$query = " UPDATE  " . $this->table_name . " SET stock_status=:stock_status WHERE id=:id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":stock_status", $this->stock_status);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getAllStockByLocation(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE `location` =:location AND stock_status='Inhouse' ORDER BY id, `model_year`";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":location", $this->location);
	    $stmt->execute();
		return $stmt;
	}

	function updateLocation(){
		$query = " UPDATE  " . $this->table_name . " SET `location`=:location WHERE id=:id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":location", $this->location);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

	function getAllBrandsByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand ORDER BY brand";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllModelsByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand, model FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand, model ORDER BY brand, model";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllModelYearsByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand, model, model_year FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand, model, model_year ORDER BY brand, model, model_year";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllGradesByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand, model, model_year, grade FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand, model, model_year, grade ORDER BY brand, model, model_year, grade";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllExteriorColorsByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand, model, model_year, grade, exterior_color FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand, model, model_year, grade, exterior_color ORDER BY brand, model, model_year, grade, exterior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllInteriorColorsByOC(){
		$condition = "";
		if($this->vehicle_status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}
		$query = "SELECT brand, model, model_year, grade, exterior_color, interior_color FROM " . $this->table_name . " LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " GROUP BY brand, model, model_year, grade, exterior_color, interior_color ORDER BY brand, model, model_year, grade, exterior_color, interior_color";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	} 

	function getOneInstockPreorderCar(){
		$condition = "";
		if($this->brand){
			$condition .= " AND car_stock.brand = :brand ";
		}
		if($this->model){
			$condition .= " AND car_stock.model = :model ";
		}
		if($this->model_year){
			$condition .= " AND car_stock.model_year = :model_year ";
		}
		if($this->grade){
			$condition .= " AND car_stock.grade = :grade ";
		}
		if($this->exterior_color){
			$condition .= " AND car_stock.exterior_color = :exterior_color ";
		}
		if($this->interior_color){
			$condition .= " AND car_stock.interior_color = :interior_color ";
		}
		if($this->status=="Instock"){
			$condition .= " AND car_stock.stock_status='Inhouse' ";
		}else{
			$condition .= " AND car_stock.stock_status<>'Inhouse' ";
		}

		$query = "SELECT car_stock.car_list_id, car_stock.vin_no, car_stock.engine_no, car_stock.lot_no, IFNULL(cpc.vehicle_price, 0) AS vehicle_price, grade.rtad_tax FROM " . $this->table_name . " LEFT JOIN car_list ON car_stock.car_list_id=car_list.id LEFT JOIN grade ON car_list.grade_id=grade.id LEFT JOIN (SELECT * FROM car_price_change WHERE id IN (SELECT MAX(id) AS id FROM car_price_change WHERE date_from<=:date GROUP BY car_list_id)) AS cpc ON car_stock.car_list_id=cpc.car_list_id WHERE car_stock.oc_no='' AND IFNULL(cpc.vehicle_price, 0)<>0 " . $condition . " ORDER BY car_stock.id LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );

		if($this->brand) $this->brand=htmlspecialchars(strip_tags($this->brand));
		if($this->model) $this->model=htmlspecialchars(strip_tags($this->model));
		if($this->model_year) $this->model_year=htmlspecialchars(strip_tags($this->model_year));
		if($this->grade) $this->grade=htmlspecialchars(strip_tags($this->grade));
		if($this->exterior_color) $this->exterior_color=htmlspecialchars(strip_tags($this->exterior_color));
		if($this->interior_color) $this->interior_color=htmlspecialchars(strip_tags($this->interior_color));

		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);
		if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
		if($this->grade) $stmt->bindParam(":grade", $this->grade);
		if($this->exterior_color) $stmt->bindParam(":exterior_color", $this->exterior_color);
		if($this->interior_color) $stmt->bindParam(":interior_color", $this->interior_color);
		$stmt->bindParam(":date", $this->date);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->car_list_id = $row['car_list_id'];
			$this->vin_no = $row['vin_no'];
			$this->engine_no = $row['engine_no'];
			$this->lot_no = $row['lot_no'];
			$this->vehicle_price = (int)$row['vehicle_price'];
			$this->rtad_tax = (int)$row['rtad_tax'];
		}else{
			$this->car_list_id = 0;
			$this->vin_no = "";
			$this->engine_no = "";
			$this->lot_no = "";
			$this->vehicle_price = 0;
			$this->rtad_tax = 0;
		}
	}

	function updateFromOrder(){
		$query = "UPDATE " . $this->table_name . " SET oc_no=:oc_no WHERE vin_no=:vin_no AND engine_no=:engine_no";
		$stmt = $this->conn->prepare($query);
	
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);

		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function changeCarFromOrder(){
		$query = "UPDATE " . $this->table_name . " SET oc_no='' WHERE oc_no=:oc_no; UPDATE " . $this->table_name . " SET oc_no=:oc_no WHERE vin_no=:vin_no AND engine_no=:engine_no";
		$stmt = $this->conn->prepare($query);
	
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":engine_no", $this->engine_no);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

    function updateSaleID(){
		$query = "UPDATE " . $this->table_name . " SET sales_id=:sales_id WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);
	
		$stmt->bindParam(":sales_id", $this->sales_id);
		$stmt->bindParam(":oc_no", $this->oc_no);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateLocationHandover(){
		$query = "UPDATE " . $this->table_name . " SET `location`=:location WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);
	
		$stmt->bindParam(":location", $this->location);
		$stmt->bindParam(":oc_no", $this->oc_no);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllVinNoByBMYGEI(){
		$condition = "";
		if($this->status=="Instock"){
			$condition .= " AND stock_status='Inhouse' ";
		}else{
			$condition .= " AND stock_status<>'Inhouse' ";
		}
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no='' AND brand=:brand AND model=:model AND model_year=:model_year AND grade=:grade AND exterior_color=:exterior_color AND interior_color=:interior_color " . $condition . " ORDER BY entry_date_time";
		$stmt = $this->conn->prepare($query);
	
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":exterior_color", $this->exterior_color);
		$stmt->bindParam(":interior_color", $this->interior_color);

		$stmt->execute();
		return $stmt;
	} 
}
?>