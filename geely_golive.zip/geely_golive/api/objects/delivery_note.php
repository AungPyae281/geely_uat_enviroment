<?php
class DeliveryNote{
	private $conn;
	private $table_name = "delivery_note";

	public $id;
	public $oc_no;
	public $date;
	public $delivery_to;
	public $phone_no;
	public $address;
	public $model;
	public $grade;
	public $engine;
	public $colour_ext_int;
	public $vin_no;
	public $registration_no;
	public $invoice_no;
	public $sales_person;
	public $generate_by;
	public $generate_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function exist(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET 
		oc_no=:oc_no
		, `date`=:date
		, delivery_to=:delivery_to
		, phone_no=:phone_no
		, address=:address
        , model=:model
        , grade=:grade
        , engine=:engine
        , colour_ext_int=:colour_ext_int
        , vin_no=:vin_no
        , registration_no=:registration_no
        , invoice_no=:invoice_no
        , sales_person=:sales_person
        , generate_by=:generate_by
        , generate_date_time=:generate_date_time";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":delivery_to", $this->delivery_to);
		$stmt->bindParam(":phone_no", $this->phone_no);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine", $this->engine);
		$stmt->bindParam(":colour_ext_int", $this->colour_ext_int);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":invoice_no", $this->invoice_no);
		$stmt->bindParam(":sales_person", $this->sales_person);
		$stmt->bindParam(":generate_by", $this->generate_by);
		$stmt->bindParam(":generate_date_time", $this->generate_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function update(){
		$query = "UPDATE " . $this->table_name . " SET
		`date`=:date
		, delivery_to=:delivery_to
		, phone_no=:phone_no
		, address=:address
        , model=:model
        , grade=:grade
        , engine=:engine
        , colour_ext_int=:colour_ext_int
        , vin_no=:vin_no
        , registration_no=:registration_no
        , invoice_no=:invoice_no
        , sales_person=:sales_person
        , generate_by=:generate_by
        , generate_date_time=:generate_date_time WHERE oc_no=:oc_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":delivery_to", $this->delivery_to);
		$stmt->bindParam(":phone_no", $this->phone_no);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine", $this->engine);
		$stmt->bindParam(":colour_ext_int", $this->colour_ext_int);
		$stmt->bindParam(":vin_no", $this->vin_no);
		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":invoice_no", $this->invoice_no);
		$stmt->bindParam(":sales_person", $this->sales_person);
		$stmt->bindParam(":generate_by", $this->generate_by);
		$stmt->bindParam(":generate_date_time", $this->generate_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function getOneDeliveryNote(){
		$query = "SELECT delivery_note.*, customer.name, customer.nrc_no, customer.mobile_no, staff.signature AS se_sig FROM " . $this->table_name . " LEFT JOIN sales ON delivery_note.oc_no=sales.oc_no LEFT JOIN customer ON sales.customer_id=customer.id LEFT JOIN staff ON sales.staff_id=staff.id WHERE delivery_note.oc_no=:oc_no";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->oc_no = $row['oc_no'];
			$this->date = $row['date'];
			$this->delivery_to = $row['delivery_to'];
			$this->phone_no = $row['phone_no'];
			$this->address = $row['address'];
			$this->model = $row['model'];
			$this->grade = $row['grade'];
			$this->vin_no = $row['vin_no'];
			$this->engine = $row['engine'];
			$this->colour_ext_int = $row['colour_ext_int']; 
			$this->registration_no = $row['registration_no'];
			$this->invoice_no = $row['invoice_no'];
			$this->sales_person = $row['sales_person'];
			$this->name = $row['name'];
			$this->nrc_no = $row['nrc_no'];
			$this->mobile_no = $row['mobile_no'];
			$this->se_sig = $row['se_sig'];
		}
	}
}
?>