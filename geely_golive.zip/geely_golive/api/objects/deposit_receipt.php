<?php
class DepositReceipt{
    private $conn;
    private $table_name = "deposit_receipt";
 
	public $id;
	public $oc_no;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $r_date;
	public $r_payment_type;
	public $receipt_no;
	public $receipt_img;
	public $amount;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    } 

    // function create(){
	// 	$statement = "";
	// 	if($this->receipt_img){
	// 		$statement = ", receipt_img=:receipt_img";
	// 	}
	// 	$query = "UPDATE `sales` SET `payment_due_date_time`=:payment_due_date_time WHERE oc_no=:oc_no; INSERT INTO `" . $this->table_name . "` SET oc_no=:oc_no, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, r_date=:r_date, r_payment_type=:r_payment_type, receipt_no=:receipt_no, amount=:amount, entry_by=:entry_by, entry_date_time=:entry_date_time " . $statement;
	// 	$stmt = $this->conn->prepare($query);

	// 	$stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
	// 	$stmt->bindParam(":oc_no", $this->oc_no);
	// 	$stmt->bindParam(":gl_code", $this->gl_code);
	// 	$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
	// 	$stmt->bindParam(":r_date", $this->r_date);
	// 	$stmt->bindParam(":r_payment_type", $this->r_payment_type);
	// 	$stmt->bindParam(":receipt_no", $this->receipt_no); 
	// 	$stmt->bindParam(":amount", $this->amount); 
	// 	$stmt->bindParam(":entry_by", $this->entry_by);
	// 	$stmt->bindParam(":entry_date_time", $this->entry_date_time);
	// 	if($this->receipt_img) $stmt->bindParam(":receipt_img", $this->receipt_img);
		
	// 	if($stmt->execute()){ 
	// 		$this->id = $this->conn->lastInsertId();
	// 		return true;
	// 	}	 
	// 	return false;
	// } 

    //APP Updated Start
	function create() {
	    $statement = "";
	    if ($this->receipt_img) {
	        $statement = ", receipt_img=:receipt_img";
	    }
	    // Update sales table
	    $update_query = "UPDATE `sales` SET `payment_due_date_time`=:payment_due_date_time WHERE oc_no=:oc_no";
	    $update_stmt = $this->conn->prepare($update_query);
	    $update_stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
	    $update_stmt->bindParam(":oc_no", $this->oc_no);
	    
	    // Insert data into another table
	    $insert_query = "INSERT INTO `" . $this->table_name . "` SET oc_no=:oc_no, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, r_date=:r_date, r_payment_type=:r_payment_type, receipt_no=:receipt_no, amount=:amount, entry_by=:entry_by, entry_date_time=:entry_date_time " . $statement;
	    $insert_stmt = $this->conn->prepare($insert_query);
	    $insert_stmt->bindParam(":oc_no", $this->oc_no);
	    $insert_stmt->bindParam(":gl_code", $this->gl_code);
	    $insert_stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
	    $insert_stmt->bindParam(":r_date", $this->r_date);
	    $insert_stmt->bindParam(":r_payment_type", $this->r_payment_type);
	    $insert_stmt->bindParam(":receipt_no", $this->receipt_no); 
	    $insert_stmt->bindParam(":amount", $this->amount); 
	    $insert_stmt->bindParam(":entry_by", $this->entry_by);
	    $insert_stmt->bindParam(":entry_date_time", $this->entry_date_time);
	    if ($this->receipt_img) {
	        $insert_stmt->bindParam(":receipt_img", $this->receipt_img);
	    }
	    
	    // Execute the update statement
	    $update_success = $update_stmt->execute();
	    if ($update_success) {
	        // Execute the insert statement
	        $insert_success = $insert_stmt->execute();
	        if ($insert_success) {
	            $this->id = $this->conn->lastInsertId();
	            return true;
	        } else {
	            // Rollback the update if insert fails
	            $update_stmt->rollBack();
	        }
	    }
	    return false;
	}
	//End


	function updatePaymentDueDateTime(){
		$query = "UPDATE `sales` SET `payment_due_date_time`=:payment_due_date_time WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
		$stmt->bindParam(":oc_no", $this->oc_no);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getOneRow(){	
		$query = "SELECT deposit_receipt.*, sales.deposit FROM " . $this->table_name . " RIGHT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE sales.oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->r_date = $row['r_date'];
			$this->gl_code = $row['gl_code'];
			$this->gl_code_bank_or_cash = $row['gl_code_bank_or_cash'];
			$this->r_payment_type = $row['r_payment_type'];
			$this->receipt_no = $row['receipt_no'];
			$this->receipt_img = $row['receipt_img'];
			$this->deposit = $row['deposit'];
		}
	}

	function getAllDepositReceipt(){
		$query = "SELECT deposit_receipt.id, deposit_receipt.r_date AS receipt_date, deposit_receipt.receipt_no, sales.oc_no, sales.sales_center, customer.name AS customer_name, customer.mobile_no AS customer_phone, deposit_receipt.amount, sales.selling_price, IFNULL(pm.total_payment, 0) AS total_payment, IFNULL(deposit_refund.amount, 0) AS refund, IFNULL(income.amount, 0) AS income
FROM deposit_receipt
LEFT JOIN deposit_refund ON deposit_receipt.id=deposit_refund.ref_id
LEFT JOIN income ON deposit_receipt.id=income.ref_id
LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no
LEFT JOIN customer ON sales.customer_id=customer.id
LEFT JOIN (SELECT oc_no, SUM(amount) AS total_payment FROM payment GROUP BY oc_no) AS pm ON sales.oc_no=pm.oc_no
WHERE deposit_receipt.amount!=0 AND selling_price=total_payment AND IFNULL(deposit_refund.amount, 0)=0 AND IFNULL(income.amount, 0)=0 ORDER BY deposit_receipt.r_date DESC, sales.oc_no DESC";
		$stmt = $this->conn->prepare($query);		
		$stmt->execute();
		return $stmt;
	} 

	// function getOneDepositReceipt(){	
	// 	$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no";
	// 	$stmt = $this->conn->prepare($query);
			
	// 	$stmt->bindParam(":oc_no", $this->oc_no);

	// 	$stmt->execute();
	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		$this->oc_no = $row['oc_no'];
	// 		$this->r_date = $row['r_date'];
	// 		$this->r_payment_type = $row['r_payment_type'];
	// 		$this->receipt_no = $row['receipt_no'];
	// 		$this->receipt_img = $row['receipt_img'];
	// 	}
	// }
}
?>
