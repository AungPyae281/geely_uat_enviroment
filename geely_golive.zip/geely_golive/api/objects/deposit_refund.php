<?php
class DepositRefund{
    private $conn;
    private $table_name = "deposit_refund";
 
	public $id;
	public $date;
	public $oc_no;
	public $ref_id;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $amount;
	public $description;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    } 

    function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET `date`=:date, oc_no=:oc_no, ref_id=:ref_id, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, amount=:amount, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":ref_id", $this->ref_id);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	} 
}
?>
