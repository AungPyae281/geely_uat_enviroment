<?php
class Event{ 
	private $conn;
	private $table_name = "event";
 
    public $id;	
	public $name;
	public $voucher_no;
	public $date;
	public $done;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET name=:name, voucher_no=:voucher_no, `date`=:date, `done`=:done, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":voucher_no", $this->voucher_no); 
		$stmt->bindParam(":date", $this->date); 
		$stmt->bindParam(":done", $this->done);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET name=:name, voucher_no=:voucher_no, `date`=:date, `done`=:done, entry_by=:entry_by, entry_date_time=:entry_date_time WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":voucher_no", $this->voucher_no); 
		$stmt->bindParam(":date", $this->date); 
		$stmt->bindParam(":done", $this->done);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getOneEvent(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);

		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->name = $row['name'];
			$this->voucher_no = $row['voucher_no'];
			$this->date = $row['date'];
			$this->done = $row['done'];
			return true;
		}
		return false;
	}

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE `id`=:id ORDER BY `date`";
		$stmt = $this->conn->prepare( $query );
		if($this->id) $stmt->bindParam(":id", $this->id);
		$stmt->execute();
		return $stmt;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " where done=0 ORDER BY `name`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function summaryEvents(){
        $query = "SELECT * FROM event JOIN event_detail ON event.id=event_detail.event_id where name=:name GROUP BY description";
		$stmt = $this->conn->prepare( $query );

		if($this->name) $stmt->bindParam(":name", $this->name);

		$stmt->execute();
		return $stmt;
    }

	function search(){
        $condition = "";
        
        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " event.date >= :df";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " event.date <= :dt";
        }

        if($this->name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (event.name LIKE  :name '%' or event.name LIKE '%' :name '%' or event.name Like '%' :name )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        // $query = "SELECT *
		// FROM event
		// JOIN (
		// SELECT voucher_no, SUM(amount) AS total_amount
		// FROM advance_detail
		// JOIN advance ON advance.id=advance_detail.advance_id
		// GROUP BY advance_id) AS tmt ON event.voucher_no=tmt.voucher_no
		// JOIN (SELECT event_id,
		//     SUM(CASE WHEN `description` = 'Number of Attendance (or) Walk In' THEN actual ELSE 0 END) AS `number_of_attendance_or_walk_in_act`,
		//     SUM(CASE WHEN `description` = 'Number of Test Drive' THEN actual ELSE 0 END) AS `number_of_test_drive_act`,
		//     SUM(CASE WHEN `description` = 'Potential' THEN actual ELSE 0 END) AS `potential_act`,
		//     SUM(CASE WHEN `description` = 'Booking' THEN actual ELSE 0 END) AS `booking_act`,
		//     SUM(CASE WHEN `description` = 'Reach' THEN actual ELSE 0 END) AS `reach_act`,
		//     SUM(CASE WHEN `description` = 'React' THEN actual ELSE 0 END) AS `react_act`,
		//     SUM(CASE WHEN `description` = 'Comment' THEN actual ELSE 0 END) AS `comment_act`,
		//     SUM(CASE WHEN `description` = 'Share' THEN actual ELSE 0 END) AS `share_act`
		// FROM 
		//     event_detail
		//     GROUP BY event_id) AS dttgt ON event.id=dttgt.event_id
		//     JOIN (SELECT event_id,
		//     SUM(CASE WHEN `description` = 'Number of Attendance (or) Walk In' THEN target ELSE 0 END) AS `number_of_attendance_or_walk_in_tgt`,
		//     SUM(CASE WHEN `description` = 'Number of Test Drive' THEN target ELSE 0 END) AS `number_of_test_drive_tgt`,
		//     SUM(CASE WHEN `description` = 'Potential' THEN target ELSE 0 END) AS `potential_tgt`,
		//     SUM(CASE WHEN `description` = 'Booking' THEN target ELSE 0 END) AS `booking_tgt`,
		//     SUM(CASE WHEN `description` = 'Reach' THEN target ELSE 0 END) AS `reach_tgt`,
		//     SUM(CASE WHEN `description` = 'React' THEN target ELSE 0 END) AS `react_tgt`,
		//     SUM(CASE WHEN `description` = 'Comment' THEN target ELSE 0 END) AS `comment_tgt`,
		//     SUM(CASE WHEN `description` = 'Share' THEN target ELSE 0 END) AS `share_tgt`
		// FROM 
		//     event_detail
		//     GROUP BY event_id) AS dtatl ON event.id=dtatl.event_id " . $condition;

		$query = "SELECT *
		FROM event
		JOIN (SELECT event_id,
		    SUM(CASE WHEN `description` = 'Number of Attendance (or) Walk In' THEN actual ELSE 0 END) AS `number_of_attendance_or_walk_in_act`,
		    SUM(CASE WHEN `description` = 'Number of Test Drive' THEN actual ELSE 0 END) AS `number_of_test_drive_act`,
		    SUM(CASE WHEN `description` = 'Potential' THEN actual ELSE 0 END) AS `potential_act`,
		    SUM(CASE WHEN `description` = 'Booking' THEN actual ELSE 0 END) AS `booking_act`,
		    SUM(CASE WHEN `description` = 'Reach' THEN actual ELSE 0 END) AS `reach_act`,
		    SUM(CASE WHEN `description` = 'React' THEN actual ELSE 0 END) AS `react_act`,
		    SUM(CASE WHEN `description` = 'Comment' THEN actual ELSE 0 END) AS `comment_act`,
		    SUM(CASE WHEN `description` = 'Share' THEN actual ELSE 0 END) AS `share_act`
		FROM 
		    event_detail
		    GROUP BY event_id) AS dttgt ON event.id=dttgt.event_id
		    JOIN (SELECT event_id,
		    SUM(CASE WHEN `description` = 'Number of Attendance (or) Walk In' THEN target ELSE 0 END) AS `number_of_attendance_or_walk_in_tgt`,
		    SUM(CASE WHEN `description` = 'Number of Test Drive' THEN target ELSE 0 END) AS `number_of_test_drive_tgt`,
		    SUM(CASE WHEN `description` = 'Potential' THEN target ELSE 0 END) AS `potential_tgt`,
		    SUM(CASE WHEN `description` = 'Booking' THEN target ELSE 0 END) AS `booking_tgt`,
		    SUM(CASE WHEN `description` = 'Reach' THEN target ELSE 0 END) AS `reach_tgt`,
		    SUM(CASE WHEN `description` = 'React' THEN target ELSE 0 END) AS `react_tgt`,
		    SUM(CASE WHEN `description` = 'Comment' THEN target ELSE 0 END) AS `comment_tgt`,
		    SUM(CASE WHEN `description` = 'Share' THEN target ELSE 0 END) AS `share_tgt`
		FROM 
		    event_detail
		    GROUP BY event_id) AS dtatl ON event.id=dtatl.event_id " . $condition;
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->name) $stmt->bindParam(":name", $this->name);
        $stmt->execute();
        return $stmt;
    }
}
