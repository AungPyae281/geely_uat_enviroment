<?php
class ExchangeRate{
	private $conn;
	private $table_name = "exchange_rate";

	public $id;
	public $date;
	public $currency;
	public $rate;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	} 

    function create(){
    	$query = "INSERT INTO " . $this->table_name . " SET `date`=:date, `currency`=:currency, `rate`=:rate, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":rate", $this->rate);	
		$stmt->bindParam(":entry_by", $this->entry_by);	
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function update(){
    	$query = "UPDATE " . $this->table_name . " SET `rate`=:rate, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time where id=:id";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":rate", $this->rate);	
		$stmt->bindParam(":entry_by", $this->entry_by);	
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	
		$stmt->bindParam(":id", $this->id);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function isExist(){
    	$query = "SELECT id FROM " . $this->table_name . " WHERE `date`=:date AND `currency`=:currency AND `rate`=:rate";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":rate", $this->rate);	
		
		$stmt->execute();

		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getAllRows(){
    	$query = "SELECT *
			from " . $this->table_name . " t
			inner join (
			    SELECT currency,MAX(entry_date_time) AS last_date FROM " . $this->table_name . " GROUP BY currency
			) tm on t.currency = tm.currency and t.entry_date_time = tm.last_date";
		$stmt = $this->conn->prepare($query);		
		$stmt->execute();
		return $stmt;
	}

	function getAllRowsByCurrency(){
    	$query = "SELECT * from exchange_rate WHERE currency=:currency order BY entry_date_time DESC";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":currency", $this->currency);

		$stmt->execute();
		return $stmt;
	}
}
?>