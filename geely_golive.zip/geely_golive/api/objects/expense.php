<?php
class Expense{ 
	private $conn;
	private $table_name = "expense";
 
    public $id;	
    public $expense_date;
	public $payment_voucher_no;
	public $bank_account_to;
	public $expense_by;
	public $receive_no;
	public $upload_receive;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$statement = "";
		if($this->upload_receive!=""){
			$statement = ", upload_receive=:upload_receive ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET expense_date=:expense_date, payment_voucher_no=:payment_voucher_no, bank_account_to=:bank_account_to, expense_by=:expense_by, receive_no=:receive_no, entry_by=:entry_by, entry_date_time=:entry_date_time" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":expense_date", $this->expense_date);
		$stmt->bindParam(":payment_voucher_no", $this->payment_voucher_no);
		$stmt->bindParam(":bank_account_to", $this->bank_account_to); 
		$stmt->bindParam(":expense_by", $this->expense_by);
		$stmt->bindParam(":receive_no", $this->receive_no);
		$stmt->bindParam(":upload_receive", $this->upload_receive);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function getOneRow(){
		$condition = "";	

		if($this->payment_voucher_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " payment_voucher_no = :payment_voucher_no ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY `date`";
		$stmt = $this->conn->prepare( $query );
		if($this->payment_voucher_no) $stmt->bindParam(":payment_voucher_no", $this->payment_voucher_no);
		$stmt->execute();
		return $stmt;
	}

	function autocompleteVoucherNo(){
		$condition = "";
		
		if($this->payment_voucher_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (payment_voucher_no LIKE  :payment_voucher_no '%' or payment_voucher_no LIKE '%' :payment_voucher_no '%' or payment_voucher_no Like '%' :payment_voucher_no )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY payment_voucher_no";
		$stmt = $this->conn->prepare($query);
		if($this->payment_voucher_no) $stmt->bindParam(":payment_voucher_no", $this->payment_voucher_no);
		$stmt->execute();
		return $stmt;
	}

	function autocompleteReceiveNo(){
		$condition = "";
		
		if($this->receive_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (receive_no LIKE  :receive_no '%' or receive_no LIKE '%' :receive_no '%' or receive_no Like '%' :receive_no )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY receive_no";
		$stmt = $this->conn->prepare($query);
		if($this->receive_no) $stmt->bindParam(":receive_no", $this->receive_no);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";	

		if($this->df){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " IF(LENGTH(expense_date)>7, expense_date>=:df, expense_date>=:df1) ";
		}
		if($this->dt){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " IF(LENGTH(expense_date)>7, expense_date<=:dt, expense_date<=:dt1) ";
		}

		if($this->payment_voucher_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (payment_voucher_no LIKE  :payment_voucher_no '%' or payment_voucher_no LIKE '%' :payment_voucher_no '%' or payment_voucher_no Like '%' :payment_voucher_no ) ";
		}

		if($this->receive_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (receive_no LIKE  :receive_no '%' or receive_no LIKE '%' :receive_no '%' or receive_no Like '%' :receive_no ) ";
		}

		if($this->expense_by){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (expense_by LIKE  :expense_by '%' or expense_by LIKE '%' :expense_by '%' or expense_by Like '%' :expense_by ) ";
		}

		if($this->status=="detail" && $this->particular){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (particular LIKE  :particular '%' or particular LIKE '%' :particular '%' or particular Like '%' :particular ) ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		if($this->status=="summary"){
			$query = " SELECT * FROM expense LEFT JOIN (SELECT expense_id, SUM(amount) AS amount FROM expense_detail GROUP BY expense_id) AS expD ON expense.id=expD.expense_id " . $condition . " ORDER BY expense_date DESC";
		}else{
			$query = " SELECT * FROM expense LEFT JOIN expense_detail ON expense.id=expense_detail.expense_id " . $condition . " ORDER BY expense_date DESC, expense_id";
		}
		$stmt = $this->conn->prepare($query);	

		if($this->df) $stmt->bindParam(":df", $this->df);
		if($this->df) $stmt->bindParam(":df1", $this->df1);
		if($this->dt) $stmt->bindParam(":dt", $this->dt);
		if($this->dt) $stmt->bindParam(":dt1", $this->dt1);
		if($this->payment_voucher_no) $stmt->bindParam(":payment_voucher_no", $this->payment_voucher_no);
		if($this->receive_no) $stmt->bindParam(":receive_no", $this->receive_no);
		if($this->expense_by) $stmt->bindParam(":expense_by", $this->expense_by);			
		if($this->status=="detail" && $this->particular) $stmt->bindParam(":particular", $this->particular);
		$stmt->execute();
		return $stmt;
	}

}
