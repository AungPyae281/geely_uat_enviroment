<?php
class ExpenseDetail{ 
	private $conn;
	private $table_name = "expense_detail";
 
    public $id;	
	public $expense_id;
	public $gl_code;
	public $amount;
	public $remark;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET expense_id=:expense_id, gl_code=:gl_code, amount=:amount, remark=:remark";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":expense_id", $this->expense_id);
		$stmt->bindParam(":gl_code", $this->gl_code); 
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":remark", $this->remark);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function getOneExpense(){
		$query = "SELECT * FROM " . $this->table_name . " where expense_id=:expense_id";
		$stmt = $this->conn->prepare( $query );
		if($this->expense_id) $stmt->bindParam(":expense_id", $this->expense_id);
		$stmt->execute();
		return $stmt;
	}
}
