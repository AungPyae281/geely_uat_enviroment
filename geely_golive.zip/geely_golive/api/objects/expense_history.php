<?php
class ExpenseHistory{ 
	private $conn;
	private $table_name = "expense_history";
 
    public $id;	
	public $expense_id;
	public $advance_id;
	public $voucher_no;
	public $request_no;
	public $amount;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET expense_id=:expense_id, advance_id=:advance_id, voucher_no=:voucher_no, request_no=:request_no, amount=:amount";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":expense_id", $this->expense_id);
		$stmt->bindParam(":advance_id", $this->advance_id); 
		$stmt->bindParam(":voucher_no", $this->voucher_no);
		$stmt->bindParam(":request_no", $this->request_no);
		$stmt->bindParam(":amount", $this->amount);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function getOneExpense(){
		$query = "SELECT * FROM " . $this->table_name . " where expense_id=:expense_id";
		$stmt = $this->conn->prepare( $query );
		if($this->expense_id) $stmt->bindParam(":expense_id", $this->expense_id);
		$stmt->execute();
		return $stmt;
	}
}
