<?php
class GLAccount{ 
	private $conn;
	private $table_name = "gl_account";
 
	public $id;
	public $type;
	public $category;
	public $gl_code;
	public $name;
	public $min_amount;
	public $max_amount;
	public $entry_by;
	public $entry_date_time;

	public $df;
	public $dt;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE gl_code = :gl_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->gl_code = htmlspecialchars(strip_tags($this->gl_code)); 
		$stmt->bindParam(":gl_code", $this->gl_code); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `type`=:type, category=:category, gl_code=:gl_code, name=:name, min_amount=:min_amount, max_amount=:max_amount, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":type", $this->type);
		$stmt->bindParam(":category", $this->category);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":min_amount", $this->min_amount);
		$stmt->bindParam(":max_amount", $this->max_amount);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function search(){
        $condition = "";
        
        // if($this->df){
        //     if($condition!=""){
        //         $condition .= " AND ";
        //     }
        //     $condition .= " advance.date >= :df";
        // }

        // if($this->dt){
        //     if($condition!=""){
        //         $condition .= " AND ";
        //     }
        //     $condition .= " advance.date <= :dt";
        // }

        if($this->type){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " type = :type";
        }

        if($this->category){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " category = :category";
        }

        if($this->requester){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (name LIKE  :name '%' or name LIKE '%' :name '%' or name Like '%' :name )";
        }

        if($this->gl_code){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (gl_code LIKE  :gl_code '%' or gl_code LIKE '%' :gl_code '%' or gl_code Like '%' :gl_code )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT fnls.id, fnls.type, fnls.category, fnls.gl_code, fnls.name, (fnls.advance_detail+fnls.expense_detail+fnls.income+fnls.bank_amount) AS ytd
			FROM (
			SELECT gl_account.*, COALESCE(SUM(advance_detail.amount),0) AS advance_detail, COALESCE(SUM(expense_detail.amount),0) AS expense_detail, COALESCE(SUM(advance_receipt.amount),0) AS advance_receipt, COALESCE(SUM(income.amount),0) AS income, COALESCE(fnl.bank_amount,0) AS bank_amount
			FROM gl_account
			LEFT JOIN advance_detail ON gl_account.gl_code=advance_detail.gl_code_to
			LEFT JOIN expense_detail ON gl_account.gl_code=expense_detail.gl_code
			LEFT JOIN advance_receipt ON gl_account.gl_code= advance_receipt.gl_code
			LEFT JOIN income ON gl_account.gl_code= income.gl_code
			LEFT JOIN (
			SELECT baytd.gl_code, (baytd.opening_balance+baytd.debit)-baytd.credit AS bank_amount
			FROM (
			SELECT gl_code, SUM(opening_balance) AS opening_balance, SUM(debit) AS debit, SUM(credit) AS credit
			FROM (
			SELECT bank_account.gl_code, bank_account.opening_balance, COALESCE(SUM(trial_balance.debit),0) AS debit, COALESCE(SUM(trial_balance.credit),0) AS credit
			FROM bank_account
			LEFT JOIN trial_balance ON bank_account.gl_code=trial_balance.gl_code
			GROUP BY bank_account.gl_code UNION
			SELECT bank_account.gl_code, 0 AS opening_balance, COALESCE(SUM(trial_balance.debit),0) AS debit, COALESCE(SUM(trial_balance.credit),0) AS credit
			FROM bank_account
			LEFT JOIN trial_balance ON bank_account.gl_code=trial_balance.gl_code_ref
			GROUP BY bank_account.gl_code) AS firs
			GROUP BY firs.gl_code) AS baytd) AS fnl ON gl_account.gl_code=fnl.gl_code
			GROUP BY gl_account.gl_code) AS fnls" . $condition;
        $stmt = $this->conn->prepare($query);
        // if($this->df) $stmt->bindParam(":df", $this->df);
        // if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->type) $stmt->bindParam(":type", $this->type);
        if($this->category) $stmt->bindParam(":category", $this->category);
        if($this->name) $stmt->bindParam(":name", $this->name);
        if($this->gl_code) $stmt->bindParam(":gl_code", $this->gl_code);
        $stmt->execute();
        return $stmt;
    }

    function searchForTrialBalance(){
    	if($this->df=='' && $this->dt==''){
    		$query='SELECT DATE, gl_account.type, gl_account.category, fnl.gl_code, gl_account.name, SUM(debit) AS debit, SUM(credit) AS credit, remark
FROM (
SELECT SUBSTRING(date_time, 1, 10) AS DATE, gl_code, SUM(debit) AS debit, SUM(credit) AS credit, statement AS remark
FROM trial_balance 
GROUP BY gl_code UNION
SELECT expense.expense_date AS DATE, gl_code, SUM(amount) AS debit,0 AS credit, remark
FROM expense_detail
JOIN expense ON expense.id=expense_detail.expense_id 
GROUP BY gl_code UNION
SELECT expense.expense_date AS DATE, advance_detail.gl_code_to, 0 AS debit, SUM(expense_detail.amount) AS credit, remark
FROM expense_detail
JOIN expense ON expense.id=expense_detail.expense_id
JOIN advance ON advance.voucher_no=expense.payment_voucher_no
JOIN advance_detail ON advance.id=advance_detail.advance_id 
GROUP BY gl_code_to UNION
SELECT advance.date, advance_detail.gl_code_to, SUM(advance_detail.amount) AS debit, 0 AS credit, advance_detail.description AS remark
FROM advance
JOIN advance_detail ON advance.id=advance_detail.advance_id 
GROUP BY advance_detail.gl_code_to) fnl
JOIN gl_account ON fnl.gl_code=gl_account.gl_code
GROUP BY gl_account.gl_code
order BY fnl.date';
    	}else{
    		$query = "SELECT `date`, gl_account.type, gl_account.category, fnl.gl_code, gl_account.name, SUM(debit) AS debit, SUM(credit) AS credit, remark
FROM (
SELECT SUBSTRING(date_time, 1, 10) AS `date`, gl_code, SUM(debit) AS debit, SUM(credit) AS credit, statement AS remark
FROM trial_balance WHERE SUBSTRING(date_time, 1, 10)>=:df and SUBSTRING(date_time, 1, 10)<=:dt 
GROUP BY gl_code UNION
SELECT expense.expense_date AS `date`, gl_code, SUM(amount) AS debit,0 AS credit, remark
FROM expense_detail
JOIN expense ON expense.id=expense_detail.expense_id WHERE expense_date>=:df AND expense_date<=:dt
GROUP BY gl_code UNION
SELECT expense.expense_date AS `date`, advance_detail.gl_code_to, 0 AS debit, SUM(expense_detail.amount) AS credit, remark
FROM expense_detail
JOIN expense ON expense.id=expense_detail.expense_id
JOIN advance ON advance.voucher_no=expense.payment_voucher_no
JOIN advance_detail ON advance.id=advance_detail.advance_id WHERE expense_date>=:df AND expense_date<=:dt
GROUP BY gl_code_to UNION
SELECT advance.date, advance_detail.gl_code_to, SUM(advance_detail.amount) AS debit, 0 AS credit, advance_detail.description AS remark
FROM advance
JOIN advance_detail ON advance.id=advance_detail.advance_id WHERE `date`>=:df AND `date`<=:dt
GROUP BY advance_detail.gl_code_to) fnl
JOIN gl_account ON fnl.gl_code=gl_account.gl_code
GROUP BY gl_account.gl_code
order BY fnl.date";
    	}
		
        $stmt = $this->conn->prepare($query);
		$stmt->bindParam(":df", $this->df);	
		$stmt->bindParam(":dt", $this->dt);

        $stmt->execute();
        return $stmt;
    }

    function searchForBalanceSheet(){
        $condition = "";

        if($this->type){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " `type` = :type";
        }

        if($this->category){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " category = :category";
        }

        if($this->name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (rnl.name LIKE  :name '%' or rnl.name LIKE '%' :name '%' or rnl.name Like '%' :name )";
        }

        if($this->gl_code){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (rnl.gl_code LIKE  :gl_code '%' or rnl.gl_code LIKE '%' :gl_code '%' or rnl.gl_code Like '%' :gl_code )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }
        
        $query = "SELECT 
				    rnl.type, rnl.category ,rnl.gl_code, rnl.name,
				    (IFNULL(rnl.opening_balance1, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance1,
				    (IFNULL(rnl.opening_balance2, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance2,
				    (IFNULL(rnl.opening_balance3, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance3,
				    (IFNULL(rnl.opening_balance4, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance4,
				    (IFNULL(rnl.opening_balance5, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance5
				FROM bank_account
				RIGHT JOIN (
				    SELECT 
				        gl_account.type, gl_account.category ,gl_account.gl_code, gl_account.name,
				        (0 + fnl_2024.debit - fnl_2024.credit) AS opening_balance1,
				        (0 + fnl_2023.debit - fnl_2023.credit) AS opening_balance2,
				        (0 + fnl_2022.debit - fnl_2022.credit) AS opening_balance3,
				        (0 + fnl_2021.debit - fnl_2021.credit) AS opening_balance4,
				        (0 + fnl_2025.debit - fnl_2025.credit) AS opening_balance5
				    FROM gl_account
				    LEFT JOIN (
				        SELECT 
				            gl_code,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date1 THEN debit ELSE 0 END) AS debit,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date1 THEN credit ELSE 0 END) AS credit
				        FROM trial_balance
				        GROUP BY gl_code
				    ) AS fnl_2024 ON fnl_2024.gl_code = gl_account.gl_code
				    LEFT JOIN (
				        SELECT 
				            IF(SUM(debit) = 0, gl_code_ref, gl_code_ref) AS gl_code,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date2 THEN debit ELSE 0 END) AS debit,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date2 THEN credit ELSE 0 END) AS credit
				        FROM trial_balance
				        GROUP BY gl_code_ref
				    ) AS fnl_2023 ON fnl_2023.gl_code = gl_account.gl_code
				    LEFT JOIN (
				        SELECT 
				            IF(SUM(debit) = 0, gl_code_ref, gl_code_ref) AS gl_code,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date3 THEN debit ELSE 0 END) AS debit,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date3 THEN credit ELSE 0 END) AS credit
				        FROM trial_balance
				        GROUP BY gl_code_ref
				    ) AS fnl_2022 ON fnl_2022.gl_code = gl_account.gl_code
				    LEFT JOIN (
				        SELECT 
				            IF(SUM(debit) = 0, gl_code_ref, gl_code_ref) AS gl_code,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date4 THEN debit ELSE 0 END) AS debit,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date4 THEN credit ELSE 0 END) AS credit
				        FROM trial_balance
				        GROUP BY gl_code_ref
				    ) AS fnl_2021 ON fnl_2021.gl_code = gl_account.gl_code
				    -- Repeat the left join for additional dates
				    LEFT JOIN (
				        SELECT 
				            gl_code,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date5 THEN debit ELSE 0 END) AS debit,
				            SUM(CASE WHEN LEFT(date_time, 10) <:date5 THEN credit ELSE 0 END) AS credit
				        FROM trial_balance
				        GROUP BY gl_code
				    ) AS fnl_2025 ON fnl_2025.gl_code = gl_account.gl_code
				    GROUP BY gl_code
				) AS rnl ON rnl.gl_code = bank_account.gl_code " . $condition . "
				GROUP BY rnl.gl_code
				order BY rnl.type, category, gl_code";

		$stmt = $this->conn->prepare($query);	
        if($this->type) $stmt->bindParam(":type", $this->type);
        if($this->category) $stmt->bindParam(":category", $this->category);
        if($this->name) $stmt->bindParam(":name", $this->name);
        if($this->gl_code) $stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":date1", $this->date1);	
		$stmt->bindParam(":date2", $this->date2);	
		$stmt->bindParam(":date3", $this->date3);
		$stmt->bindParam(":date4", $this->date4);
		$stmt->bindParam(":date5", $this->date5);
		$stmt->execute();
		return $stmt;
    }

	function getAllRows(){
		$condition = "";

		if($this->type){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `type` = :type ";
		}

		if($this->category){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " category = :category ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY gl_code, name";
		$stmt = $this->conn->prepare( $query );
		if($this->type) $stmt->bindParam(":type", $this->type);
		if($this->category) $stmt->bindParam(":category", $this->category);
		$stmt->execute();
		return $stmt;
	}

	function update(){
    	$query = "UPDATE " . $this->table_name . " SET `name`=:name, `min_amount`=:min_amount, `max_amount`=:max_amount, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time where id=:id";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":name", $this->name);	
		$stmt->bindParam(":min_amount", $this->min_amount);	
		$stmt->bindParam(":max_amount", $this->max_amount);	
		$stmt->bindParam(":entry_by", $this->entry_by);	
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	
		$stmt->bindParam(":id", $this->id);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateFromBankAccountCreate(){
    	$query = "UPDATE " . $this->table_name . " SET `currency`=:currency where gl_code=:gl_code";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":currency", $this->currency);	
		$stmt->bindParam(":gl_code", $this->gl_code);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAdvanceBalance(){
		$query = "SELECT gl_account.gl_code,gl_account.name,(IFNULL(opening_balance, 0) + IFNULL(total_debit, 0) - IFNULL(total_credit, 0)) AS balance FROM gl_account
				LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(credit) AS total_credit FROM (
				SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit FROM bank_account_transfer WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM account_transfer WHERE  date<=:date GROUP BY gl_code_from
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM payment WHERE date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit FROM deposit_refund WHERE date<=:date GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS credit FROM deposit_refund WHERE date<=:date GROUP BY gl_code) AS tc GROUP BY gl_code) AS tc1 ON gl_account.gl_code=tc1.gl_code
				LEFT JOIN
				(SELECT gl_code, SUM(debit) AS total_debit FROM (
				SELECT gl_code_to AS gl_code, SUM(amount_to) AS debit FROM bank_account_transfer WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM account_transfer WHERE date<=:date GROUP BY gl_code_to
				UNION ALL SELECT gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE r_date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE  r_date<=:date GROUP BY gl_code_bank_or_cash
				UNION ALL SELECT gl_code, SUM(amount) AS debit FROM payment WHERE  date<=:date GROUP BY gl_code
				UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM payment WHERE  date<=:date GROUP BY gl_code_bank_or_cash) AS td GROUP BY gl_code) AS b ON gl_account.gl_code=b.gl_code
				WHERE gl_account.category = 'advance'";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllUnregisterBankGL(){
		$query = "SELECT gl_account.* FROM " . $this->table_name . " LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code WHERE bank_account.gl_code IS NULL AND gl_account.category='Bank' ORDER BY gl_account.gl_code, gl_account.name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function getBankCash(){
		$query = "SELECT * FROM " . $this->table_name . " where category in ('Bank','Cash')";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 

	function getAllGLAccountForDTG(){
		$query = "SELECT id, `type`, category, gl_code, `name`, currency FROM gl_account";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	// function getAllTransaction(){
	// 	$query   = "SELECT * FROM (SELECT '' as date, gl_account.gl_code, 'Opening Balance' as `transaction`, 0 AS credit, (IFNULL(opening_balance, 0) + IFNULL(total_debit, 0) - IFNULL(total_credit, 0)) AS debit, '' AS entry_date_time FROM gl_account
	// 			LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
	// 			LEFT JOIN
	// 			(SELECT gl_code, SUM(credit) AS total_credit FROM (
	// 			SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit FROM bank_account_transfer WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
	// 			UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
	// 			UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM advance_claim WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
	// 			UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit FROM account_transfer WHERE gl_code_from=:gl_code AND date<:date_from GROUP BY gl_code_from
	// 			UNION ALL SELECT gl_code, SUM(amount) AS credit FROM payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
	// 			UNION ALL SELECT gl_code, SUM(amount) AS credit FROM service_payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
	// 			UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit FROM deposit_refund WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash
	// 			UNION ALL SELECT gl_code, SUM(amount) AS credit FROM deposit_refund WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code) AS tc GROUP BY gl_code) AS tc1 ON gl_account.gl_code=tc1.gl_code
	// 			LEFT JOIN
	// 			(SELECT gl_code, SUM(debit) AS total_debit FROM (
	// 			SELECT gl_code_to AS gl_code, SUM(amount_to) AS debit FROM bank_account_transfer WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
	// 			UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
	// 			UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM advance_claim WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
	// 			UNION ALL SELECT gl_code_to AS gl_code, SUM(amount) AS debit FROM account_transfer WHERE gl_code_to=:gl_code AND date<:date_from GROUP BY gl_code_to
	// 			UNION ALL SELECT gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date<:date_from GROUP BY gl_code
	// 			UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(sales.deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date<:date_from GROUP BY gl_code_bank_or_cash
	// 			UNION ALL SELECT gl_code, SUM(amount) AS debit FROM payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
	// 			UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM payment WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash
	// 			UNION ALL SELECT gl_code, SUM(amount) AS debit FROM service_payment WHERE gl_code=:gl_code AND date<:date_from GROUP BY gl_code
	// 			UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS debit FROM service_payment WHERE gl_code_bank_or_cash=:gl_code AND date<:date_from GROUP BY gl_code_bank_or_cash) AS td GROUP BY gl_code) AS b ON gl_account.gl_code=b.gl_code
	// 			WHERE gl_account.gl_code=:gl_code

	// 			UNION ALL

	// 			SELECT date, crdb.gl_code, `transaction`, credit, debit, entry_date_time FROM (
	// 			SELECT date, gl_code_to AS gl_code, 'Bank Account Transfer' AS `transaction`, 0 AS credit, amount_to AS debit, entry_date_time FROM bank_account_transfer WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_to AS gl_code, 'Advance' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM advance WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_to AS gl_code, 'Advance Claim' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM advance_claim WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_to AS gl_code, 'Account Transfer' AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM account_transfer WHERE gl_code_to=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT r_date AS date, gl_code, CONCAT(deposit_receipt.oc_no, ' (Deposit)') AS `transaction`, 0 AS credit, sales.deposit AS debit, deposit_receipt.entry_date_time FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code=:gl_code AND r_date>=:date_from AND r_date<=:date_to
	// 			UNION ALL
	// 			SELECT r_date AS date, gl_code_bank_or_cash AS gl_code, CONCAT(deposit_receipt.oc_no, ' (Deposit)') AS `transaction`, 0 AS credit, sales.deposit AS debit, deposit_receipt.entry_date_time FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no WHERE gl_code_bank_or_cash=:gl_code AND r_date>=:date_from AND r_date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code, CONCAT(oc_no, ' ', description) AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM payment WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_bank_or_cash AS gl_code, CONCAT(oc_no, ' ', description) AS `transaction`, 0 AS credit, amount AS debit, entry_date_time FROM payment WHERE gl_code_bank_or_cash=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT service_payment.date, gl_code, CONCAT(service.registration_no, ' ', service_payment.description) AS `transaction`, 0 AS credit, amount AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
	// 			UNION ALL
	// 			SELECT service_payment.date, gl_code_bank_or_cash AS gl_code, CONCAT(service.registration_no, ' ', service_payment.description) AS `transaction`, 0 AS credit, service_payment.amount AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code_bank_or_cash=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_from AS gl_code, 'Bank Account Transfer' AS `transaction`, amount_from AS credit, 0 AS debit, entry_date_time FROM bank_account_transfer WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_from AS gl_code, 'Advance' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM advance WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_from AS gl_code, 'Advance Claim' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM advance_claim WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_from AS gl_code, 'Account Transfer' AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM account_transfer WHERE gl_code_from=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code, CONCAT(oc_no, ' ', ' Payment Transfer to Bank or Cash Account') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM payment WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT service_payment.date, gl_code, CONCAT(service.registration_no, ' ', ' Payment Transfer to Bank or Cash Account') AS `transaction`, service_payment.amount AS credit, 0 AS debit, service_payment.entry_date_time FROM service_payment LEFT JOIN service ON service_payment.service_id=service.id WHERE gl_code=:gl_code AND service_payment.date>=:date_from AND service_payment.date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code_bank_or_cash AS gl_code, CONCAT(oc_no, ' (Deposit Refund)') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM deposit_refund WHERE gl_code_bank_or_cash=:gl_code AND date>=:date_from AND date<=:date_to
	// 			UNION ALL
	// 			SELECT date, gl_code, CONCAT(oc_no, ' (Deposit Refund)') AS `transaction`, amount AS credit, 0 AS debit, entry_date_time FROM deposit_refund WHERE gl_code=:gl_code AND date>=:date_from AND date<=:date_to) AS crdb) AS main order by main.date, main.entry_date_time";

	// 	$stmt = $this->conn->prepare($query);
		 
	// 	$this->date_from=htmlspecialchars(strip_tags($this->date_from));
	// 	$this->date_to=htmlspecialchars(strip_tags($this->date_to));
	// 	$this->gl_code=htmlspecialchars(strip_tags($this->gl_code));
		 
	// 	$stmt->bindParam(":date_from", $this->date_from);
	// 	$stmt->bindParam(":date_to", $this->date_to);
	// 	$stmt->bindParam(":gl_code", $this->gl_code);
		
	// 	$stmt->execute();
	// 	return $stmt;
	// }

	function getBankOrCashOpeningBal(){
		$query = "SELECT (IFNULL(rnl.opening_balance, 0) + IFNULL(bank_account.opening_balance, 0)) AS opening_balance
FROM bank_account
RIGHT JOIN (
    SELECT gl_account.gl_code, (0 + fnl.debit - fnl.credit) AS opening_balance
    FROM gl_account
    JOIN (
        SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit
        FROM (
            SELECT IFNULL(gl_code,:gl_code) AS gl_code, SUM(debit) AS debit, SUM(credit) AS credit
            FROM trial_balance
            WHERE LEFT(date_time, 10) <:date_from AND gl_code =:gl_code
            UNION
            SELECT IF(SUM(debit) = 0, gl_code_ref, gl_code_ref) AS gl_code, SUM(debit) AS debit, SUM(credit) AS credit
            FROM trial_balance
            WHERE LEFT(date_time, 10) <:date_from AND gl_code_ref =:gl_code
        ) AS aa
        GROUP BY gl_code
    ) AS fnl ON fnl.gl_code = gl_account.gl_code
    GROUP BY gl_code
) AS rnl ON rnl.gl_code = bank_account.gl_code
WHERE rnl.gl_code =:gl_code";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row['opening_balance'];
		}
		return 0;
	}

// 	function getBankOrCashOpeningBal(){
// 		$query = "SELECT (IFNULL(bank_account.opening_balance, 0) + SUM(IFNULL(debit, 0)) - SUM(IFNULL(credit, 0))) AS opening_balance FROM gl_account
// LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
// LEFT JOIN (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit FROM trial_balance WHERE LEFT(date_time, 10)<:date_from AND gl_code=:gl_code) AS tb ON bank_account.gl_code=tb.gl_code
// WHERE gl_account.category IN ('Bank', 'Cash') AND gl_account.gl_code=:gl_code";

// 		$stmt = $this->conn->prepare( $query );
// 		$stmt->bindParam(":date_from", $this->date_from);
// 		$stmt->bindParam(":gl_code", $this->gl_code);
// 		$stmt->execute();
// 		if($stmt->rowCount()>0){
// 			$row = $stmt->fetch(PDO::FETCH_ASSOC);
// 			return $row['opening_balance'];
// 		}
// 		return 0;
// 	}

	function getAllAccountBal(){
		$query = "SELECT gl_account.*, IFNULL(bank_account.id, 0) as bank_id, (IFNULL(bank_account.opening_balance, 0) + SUM(IFNULL(debit, 0)) - SUM(IFNULL(credit, 0))) AS balance, IFNULL(er.rate, 0) AS rate FROM gl_account
LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
LEFT JOIN (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit FROM (SELECT gl_code, SUM(debit) AS debit, SUM(credit) AS credit
FROM trial_balance group by gl_code
UNION
SELECT gl_code_ref AS gl_code, SUM(debit) AS debit, SUM(credit) AS credit
FROM trial_balance group by gl_code_ref) AS fir group by fir.gl_code) AS tb ON gl_account.gl_code=tb.gl_code
LEFT JOIN (SELECT currency, rate FROM exchange_rate WHERE id IN (SELECT MAX(id) FROM exchange_rate WHERE `date`<=:date GROUP BY currency)) AS er ON gl_account.currency=er.currency
WHERE gl_account.category IN ('Bank', 'Cash')
GROUP BY gl_account.gl_code
ORDER BY gl_account.gl_code, gl_account.`name`";
		$stmt = $this->conn->prepare($query);	
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	} 


	function searchForGlReport(){
    	if($this->df=='' && $this->dt==''){
        	$query = "SELECT date, gl_account.type, gl_account.category, fnl.gl_code, gl_account.name,debit,credit, remark
			FROM (
			SELECT SUBSTRING(date_time, 1, 10) AS DATE, gl_code, debit, credit, statement AS remark
			FROM trial_balance
			UNION
			SELECT expense.expense_date AS DATE, gl_code, amount AS debit,0 AS credit, remark
			FROM expense_detail
			JOIN expense ON expense.id=expense_detail.expense_id
			UNION
			SELECT expense.expense_date AS DATE, advance_detail.gl_code_to, 0 AS debit, expense_detail.amount AS credit, remark
			FROM expense_detail
			JOIN expense ON expense.id=expense_detail.expense_id
			JOIN advance ON advance.voucher_no=expense.payment_voucher_no
			JOIN advance_detail ON advance.id=advance_detail.advance_id
			UNION
			SELECT advance.date, advance_detail.gl_code_to, advance_detail.amount AS debit, 0 AS credit, advance_detail.description AS remark
			FROM advance
			JOIN advance_detail ON advance.id=advance_detail.advance_id
			GROUP BY advance_detail.gl_code_to) fnl
			JOIN gl_account ON fnl.gl_code=gl_account.gl_code
			WHERE fnl.gl_code=:gl_code
			ORDER BY fnl.date";
		}else{
			$query = "SELECT date, gl_account.type, gl_account.category, fnl.gl_code, gl_account.name,debit,credit, remark
			FROM (
			SELECT SUBSTRING(date_time, 1, 10) AS DATE, gl_code, debit, credit, statement AS remark
			FROM trial_balance
			WHERE SUBSTRING(date_time, 1, 10)>=:df AND SUBSTRING(date_time, 1, 10)<=:dt
			UNION
			SELECT expense.expense_date AS DATE, gl_code, amount AS debit,0 AS credit, remark
			FROM expense_detail
			JOIN expense ON expense.id=expense_detail.expense_id
			WHERE expense_date>=:df AND expense_date<=:dt
			UNION
			SELECT expense.expense_date AS DATE, advance_detail.gl_code_to, 0 AS debit, expense_detail.amount AS credit, remark
			FROM expense_detail
			JOIN expense ON expense.id=expense_detail.expense_id
			JOIN advance ON advance.voucher_no=expense.payment_voucher_no
			JOIN advance_detail ON advance.id=advance_detail.advance_id
			WHERE expense_date>=:df AND expense_date<=:dt
			UNION
			SELECT advance.date, advance_detail.gl_code_to, advance_detail.amount AS debit, 0 AS credit, advance_detail.description AS remark
			FROM advance
			JOIN advance_detail ON advance.id=advance_detail.advance_id
			WHERE DATE>=:df AND DATE<=:dt
			GROUP BY advance_detail.gl_code_to) fnl
			JOIN gl_account ON fnl.gl_code=gl_account.gl_code
			WHERE fnl.gl_code=:gl_code
			ORDER BY fnl.date";
		}
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->gl_code) $stmt->bindParam(":gl_code", $this->gl_code);
        $stmt->execute();
        return $stmt;
    }
}
?>