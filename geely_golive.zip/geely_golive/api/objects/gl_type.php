<?php
class GLType{ 
	private $conn;
	private $table_name = "gl_type";
 
	public $id;
	public $type;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `type`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET type=:type"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":type", $this->type); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `type` = :type LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->type = htmlspecialchars(strip_tags($this->type)); 
		$stmt->bindParam(":type", $this->type); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getExist(){		
		$query = "SELECT gl_type.id,gl_type.type, gl_category.type as gl_category_type FROM `" . $this->table_name . "` 
		LEFT JOIN (SELECT `type` FROM gl_category GROUP BY `type`) as gl_category ON gl_type.type=gl_category.type";
		$stmt = $this->conn->prepare( $query );

		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM `" . $this->table_name . "` WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
    }
}
?>