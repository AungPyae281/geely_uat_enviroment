<?php
class Grade{
    // database connection and table name
	private $conn;
	private $table_name = "grade";

	// object properties 
	public $id;
	public $model_id;
	public $grade;
	public $engine_power;
	public $rtad_tax;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE model_id = :model_id AND `grade` = :grade AND engine_power = :engine_power LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );

		$this->grade = htmlspecialchars(strip_tags($this->grade));
		$this->engine_power = htmlspecialchars(strip_tags($this->engine_power));

		$stmt->bindParam(":model_id", $this->model_id);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET model_id=:model_id, `grade`=:grade, engine_power=:engine_power, rtad_tax=:rtad_tax"; 
		$stmt = $this->conn->prepare($query); 

		$stmt->bindParam(":model_id", $this->model_id);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":rtad_tax", $this->rtad_tax); 

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT grade.*, brand, model, model_year FROM " . $this->table_name . " LEFT JOIN model ON grade.model_id=model.id ORDER BY grade";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllGrade(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE model_id=:model_id GROUP BY grade ORDER BY grade";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":model_id", $this->model_id);
		$stmt->execute();
		return $stmt;
	}

	function getEnginePowerByGrade(){ 
		$query = "SELECT * FROM " . $this->table_name . " WHERE model_id = :model_id AND `grade` = :grade ORDER BY engine_power";
		$stmt = $this->conn->prepare($query);
		$this->grade = htmlspecialchars(strip_tags($this->grade));
		$stmt->bindParam(":model_id", $this->model_id);
		$stmt->bindParam(":grade", $this->grade);
		$stmt->execute();
		return $stmt;
	}

	function getAllGradeList(){
		$condition = "";	

		if($this->brand){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `brand` =:brand ";
		}
		if($this->model){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `model` =:model ";
		}
		if($this->model_year){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `model_year` =:model_year ";
		}

		if($this->grade){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `grade` =:grade ";
		}
		
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT grade.*, `brand`, `model`, `model_year` FROM " . $this->table_name . " LEFT JOIN model ON grade.model_id=model.id " . $condition . " ORDER BY brand, model, model_year, grade";

		$stmt = $this->conn->prepare($query);
		
		if($this->brand) $this->brand=htmlspecialchars(strip_tags($this->brand));
		if($this->model) $this->model=htmlspecialchars(strip_tags($this->model));
		if($this->model_year) $this->model_year=htmlspecialchars(strip_tags($this->model_year));
		if($this->grade) $this->grade=htmlspecialchars(strip_tags($this->grade));
		
		if($this->brand) $stmt->bindParam(":brand", $this->brand);
		if($this->model) $stmt->bindParam(":model", $this->model);
		if($this->model_year) $stmt->bindParam(":model_year", $this->model_year);
		if($this->grade) $stmt->bindParam(":grade", $this->grade);
		
		$stmt->execute();
		return $stmt;
	}

	function update(){
		$query = " UPDATE  " . $this->table_name . " SET rtad_tax=:rtad_tax WHERE id=:id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":rtad_tax", $this->rtad_tax);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}  
}
?>