<?php
class Income{ 
	private $conn;
	private $table_name = "income";
 
    public $id;	
	public $date;
	public $oc_no;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $amount; 
	public $description; 
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$statement = "";
		if($this->upload_receipt){
			$statement .= ", upload_receipt=:upload_receipt ";
		}
		if($this->oc_no){
			$statement .= ", oc_no=:oc_no ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET date=:date, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, amount=:amount, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":description", $this->description);
		if($this->upload_receipt) $stmt->bindParam(":upload_receipt", $this->upload_receipt);
		if($this->oc_no) $stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}
}
?>