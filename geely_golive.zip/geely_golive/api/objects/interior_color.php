<?php
class InteriorColor{
    // database connection and table name
	private $conn;
	private $table_name = "interior_color";

    // object properties
    public $id;	
	public $color;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY color";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
	
}
