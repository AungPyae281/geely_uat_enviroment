<?php
class Journal{ 
	private $conn;
	private $table_name = "journal";
 
    public $id;	
	public $date;
	public $ref_number;
	public $gl_code;
	public $debit;
	public $credit;
	public $description;
	public $entry_by;
	public $entry_date_time; 
	public $is_done;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET date=:date, ref_number=:ref_number, gl_code=:gl_code, debit=:debit, credit=:credit, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":ref_number", $this->ref_number);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":debit", $this->debit);
		$stmt->bindParam(":credit", $this->credit);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET settlement_date=:settlement_date, gl_code_bank_or_cash_credit=:gl_code_bank_or_cash_credit, settlement_by=:settlement_by, settlement_date_time=:settlement_date_time WHERE id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":settlement_date", $this->settlement_date);
		$stmt->bindParam(":gl_code_bank_or_cash_credit", $this->gl_code_bank_or_cash_credit);
		$stmt->bindParam(":settlement_by", $this->settlement_by);
		$stmt->bindParam(":settlement_date_time", $this->settlement_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";

		if($this->date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `date` = :date ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT journal.*, gl_account.name
		FROM journal JOIN gl_account ON journal.gl_code=gl_account.gl_code " . $condition . " GROUP BY journal.gl_code, ref_number order BY id";
		$stmt = $this->conn->prepare($query);
		if($this->date) $stmt->bindParam(":date", $this->date);		
		$stmt->execute();
		return $stmt;
	}

	function getAllRefNumber(){
		$query = "SELECT journal.*
		FROM journal
		LEFT JOIN advance_detail
		ON journal.ref_number = advance_detail.journal_ref_number
		WHERE advance_detail.journal_ref_number IS NULL GROUP BY ref_number;
";
		$stmt = $this->conn->prepare($query);	
		$stmt->execute();
		return $stmt;
	} 

	function getGenerateRefNo($prefix){
		$query = "SELECT ref_number FROM `" . $this->table_name . "` WHERE ref_number like ? ORDER BY ref_number DESC LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		$keywords = htmlspecialchars(strip_tags($prefix));
		$keywords = "{$keywords}%";
		
		$stmt->bindParam(1, $keywords);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%05d", ((int)str_replace($prefix, "", $row['ref_number']) + 1));
		}else{
			return $prefix . "00001";
		}
	}

	function getOneJournal(){
		$query = "SELECT journal.*, gl_account.name FROM " . $this->table_name . " JOIN gl_account ON gl_account.gl_code=journal.gl_code WHERE ref_number=:ref_number order BY id LIMIT 0,1";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":ref_number", $this->ref_number);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->date = $row['date'];
			$this->ref_number = $row['ref_number'];	
			$this->gl_code = $row['gl_code'];
			$this->debit = $row['debit'];
			$this->credit = $row['credit'];
			$this->description = $row['description'];
			$this->entry_by = $row['entry_by'];
			$this->entry_date_time = $row['entry_date_time'];
			$this->name = $row['name'];
		}
	}
}
?>