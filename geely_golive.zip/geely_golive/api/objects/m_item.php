<?php
class MItem{
    // database connection and table name
	private $conn;
	private $table_name = "m_item";

    // object properties
    public $id;	
	public $category;
	public $type;
	public $item_name;
	public $capital_price;
	public $description;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$condition = "";

		if($this->type){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `type` = :type ";
		}

		if($this->category){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " category = :category ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY item_name";
		$stmt = $this->conn->prepare($query); 

		$stmt->bindParam(":type", $this->type); 
		$stmt->bindParam(":category", $this->category); 
		
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `category` = :category and `type` = :type and `item_name` = :item_name LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->category = htmlspecialchars(strip_tags($this->category)); 
		$this->type = htmlspecialchars(strip_tags($this->type)); 
		$this->item_name = htmlspecialchars(strip_tags($this->item_name)); 
		$stmt->bindParam(":category", $this->category); 
		$stmt->bindParam(":type", $this->type); 
		$stmt->bindParam(":item_name", $this->item_name); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);

		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->type = $row['type'];
			$this->category = $row['category'];
			$this->item_name = $row['item_name'];
			$this->capital_price = $row['capital_price'];
			$this->description = $row['description'];
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET category=:category, `type`=:type, item_name=:item_name, capital_price=:capital_price, `description`=:description"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":category", $this->category); 
		$stmt->bindParam(":type", $this->type); 
		$stmt->bindParam(":item_name", $this->item_name); 
		$stmt->bindParam(":capital_price", $this->capital_price); 
		$stmt->bindParam(":description", $this->description); 
		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET category=:category, `type`=:type, item_name=:item_name, capital_price=:capital_price, `description`=:description where id=:id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":id", $this->id); 
		$stmt->bindParam(":category", $this->category); 
		$stmt->bindParam(":type", $this->type); 
		$stmt->bindParam(":item_name", $this->item_name); 
		$stmt->bindParam(":capital_price", $this->capital_price); 
		$stmt->bindParam(":description", $this->description); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllItem(){
		$query = "SELECT * from " . $this->table_name . " order by item_name";

		$stmt = $this->conn->prepare( $query );

		$stmt->execute();
		return $stmt;
	}  
	
	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$this->id = htmlspecialchars(strip_tags($this->id));
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
