<?php
class MStockBalance{

	private $conn;
	private $table_name = "m_stock_balance";

	//filed list start
	public $id;	
	public $store;	
	public $item_id;
	public $item_name;
	public $total_stock;	
	public $transfer_in;
	public $use;
    public $lost;
    public $damage;
    public $expire;
	public $transfer_out;
	//field list end

	//condition start
	public $quantity;
	public $stock_out_id;
	public $df;
	public $dt;
	//condition end
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getItemInOut(){

		$condition = "";
		
		if($this->amminity==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='amminity' ";
		}

		if($this->minibar==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='MiniBar' ";
		}

		if($this->laundry==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='Laundary' ";
		}

		if($this->phonebill==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='Phone Bill' ";
		}

		if($this->fb==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='F&B' ";
		}

		if($this->other==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='Other' ";
		}

		if($this->stain==1){
			if($condition!=""){ $condition .= " OR "; }
			$condition .= " category='Stain' ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT item.*, IFNULL(in_qty, 0) AS in_qty, IFNULL(out_qty, 0) AS out_qty, (IFNULL(iqty, 0) - IFNULL(oqty, 0)) AS open_balance, (IFNULL(iqty, 0) - IFNULL(oqty, 0) - IFNULL(out_qty, 0) + IFNULL(in_qty, 0)) AS balance,
REPLACE(IFNULL(in_price, price),',','') AS in_price, IFNULL(in_amount, 0) AS in_amount, IFNULL(out_amount, 0) AS out_amount, IFNULL(getavg.avg,0) AS avgp
FROM item
LEFT JOIN (
SELECT item_id, SUM(quantity) AS in_qty, price AS in_price
FROM stock_in
WHERE SUBSTRING(stock_in_date,1,10)>=:df AND SUBSTRING(stock_in_date,1,10)<=:dt
GROUP BY item_id) AS stkin ON item.code=stkin.item_id
LEFT JOIN (
SELECT item_id, SUM(quantity) AS out_qty
FROM stock_out
WHERE SUBSTRING(stock_out_date,1,10)>=:df AND SUBSTRING(stock_out_date,1,10)<=:dt
GROUP BY item_id) AS stkout ON item.code=stkout.item_id
LEFT JOIN (
SELECT item_id, SUM(quantity) AS iqty
FROM stock_in
WHERE SUBSTRING(stock_in_date,1,10)<:df
GROUP BY item_id) AS ssin ON item.code=ssin.item_id
LEFT JOIN (
SELECT item_id, SUM(quantity) AS oqty
FROM stock_out
WHERE SUBSTRING(stock_out_date,1,10)<:df
GROUP BY item_id) AS ssout ON item.code=ssout.item_id
LEFT JOIN (
SELECT item_id, SUM(amount) AS in_amount
FROM (
SELECT *
FROM stock_in
GROUP BY stock_in.item_id, voucher_no) AS stin
LEFT JOIN (
SELECT purchase.voucher_no, purchase_detail.id, purchase_detail.code, purchase_detail.price AS amount
FROM purchase
LEFT JOIN purchase_detail ON purchase.id=purchase_detail.purchase_id) AS purch ON stin.item_id=purch.code AND stin.voucher_no=purch.voucher_no
WHERE stock_in_date >= :df AND stock_in_date <= :dt
GROUP BY item_id) AS sinama ON item.code=sinama.item_id
LEFT JOIN (
SELECT other_service_charges.item_id, SUM(other_service_charges.amount) AS out_amount
FROM other_service_charges
WHERE SUBSTRING(other_service_charges.payment_date_time,1,10)>=:df AND SUBSTRING(other_service_charges.payment_date_time,1,10)<=:dt
GROUP BY item_id) as soutama on item.code=soutama.item_id 
LEFT JOIN (
SELECT stock_in.item_id, ROUND((SUM(stock_in.quantity*
REPLACE(stock_in.price, ',', ''))/ SUM(stock_in.quantity))) AS AVG
FROM stock_in
GROUP BY stock_in.item_id) AS getavg ON item.code=getavg.item_id
" . $condition . " AND type<>'Services'
ORDER BY code";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":df", $this->df);
		$stmt->bindParam(":dt", $this->dt);
		// $stmt->bindParam(":sale", $this->sale);
		// $stmt->bindParam(":housekeeping", $this->housekeeping);
		// $stmt->bindParam(":service", $this->service);
		$stmt->execute();
		return $stmt;
	}

	function getAllRowsForStockOut(){
		$query = "SELECT m_item.*, store, ((total_stock)-(`use`+lost+damage+expire)) AS total FROM " . $this->table_name . " LEFT JOIN m_item ON m_stock_balance.item_id=m_item.id WHERE m_stock_balance.store=:store";
		$stmt = $this->conn->prepare($query);

		// $this->store=htmlspecialchars(strip_tags($this->store));

		$stmt->bindParam(":store", $this->store);
	    $stmt->execute();
		return $stmt;

	}
    
    function checkItem(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE store=:store AND item_id=:item_id ";
		$stmt = $this->conn->prepare($query);

		$this->store=htmlspecialchars(strip_tags($this->store));
        $this->item_id=htmlspecialchars(strip_tags($this->item_id));

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;

	}
	
	function checkItemForStockOut(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE store=:store AND item_id=:item_id ";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;

	}
	
	function checkMaterialForStockOut(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE store=:store AND item_id=:item_id AND ((total_stock)-(`use`+lost+damage+`expire`))>=:quantity";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":quantity", $this->quantity);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
	}	
    
	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET store=:store, item_id=:item_id, item_name=:item_name, total_stock=:quantity";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":store", $this->store);
		$stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":item_name", $this->item_name);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function createFromsale(){
		$query = "INSERT INTO " . $this->table_name . " SET store=:store, item_id=:item_id, item_name=:item_name, `use`=:quantity";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":store", $this->store);
		$stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":item_name", $this->item_name);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	}
	
	function stockOut($quantity){

		$condition = "";
		
		if($this->field){
			$condition .= $this->field . "=" . $this->field ;
		}

		$query = "UPDATE " . $this->table_name . " SET " . $condition . " + :quantity where item_id=:item_id and store=:store";
		$stmt = $this->conn->prepare($query);	
		
		$stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":store", $this->store);
		$stmt->bindParam(":quantity", $quantity);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getLowStockItemsCount(){
		$query = "SELECT COUNT(item_id) AS total_stock_item_count
FROM " . $this->table_name . " LEFT JOIN item ON stock_balance.item_id = item.code
WHERE (total_stock)-(`use`+lost+damage+`expire`)<=minimum_stock_level";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row['total_stock_item_count'];
		}
	}

	function checkMaterial(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE store=:store AND item_id=:item_id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;

	}

	function updateFromStockIn(){
		$query = "UPDATE " . $this->table_name . " SET total_stock=total_stock " . (($this->plus==1)?"+":"-") .  " :quantity where store=:store AND item_id=:item_id ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
        $stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}else{
			return false;
		}
	}


    function updateFromStockOut(){
		$condition = "";
		if($this->use==1){
			$condition .= " `use` =`use` " . (($this->plus==1)?"+":"-") .  " :quantity ";
		}
		if($this->lost==1){
			$condition .= " lost =lost " . (($this->plus==1)?"+":"-") .  " :quantity ";
		}
		if($this->damage==1){
			$condition .= " damage =damage " . (($this->plus==1)?"+":"-") .  " :quantity ";
		}
		if($this->expire==1){
			$condition .= " expire =expire " . (($this->plus==1)?"+":"-") .  " :quantity ";
		}

		$query = "UPDATE " . $this->table_name . " SET " . $condition .  " WHERE `store`=:store AND item_id=:item_id ";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
        $stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}else{
			return false;
		}
	}

	function updateFromStockTransfer(){
		$condition = "";
		if($this->plus==0){
			$condition .= " `transfer_out` =`transfer_out` + :quantity ";
		}
		if($this->plus==1){
			$condition .= " `transfer_in` =`transfer_in` + :quantity ";
		}
		$query = "UPDATE " . $this->table_name . " SET ".$condition." where store=:store AND item_id=:item_id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":store", $this->store);
        $stmt->bindParam(":item_id", $this->item_id);
        $stmt->bindParam(":quantity", $this->quantity);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function updateByReturn(){
		$condition = "";
		
		if($this->reason=="use"){
			$condition .= " `use` =`use`-:quantity";
		}		
		if($this->reason=="lost"){
			$condition .= " lost =lost-:quantity";
		}
		if($this->reason=="damage"){
			$condition .= " damage =damage-:quantity";
		}
		if($this->reason=="expire"){
			$condition .= " expire =expire-:quantity";
		}
		
		$query = "UPDATE " . $this->table_name . " SET " . $condition . " WHERE item_id= :item_id and store=:store";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":store", $this->store);
	 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function search(){
		$condition = "";

		if($this->category){
			if($condition!=""){ $condition .= " AND "; } $condition .= " category =:category ";
		}	

		if($this->type){
			if($condition!=""){ $condition .= " AND "; } $condition .= " type =:type ";
		}	

		if($this->item_name){
			if($condition!=""){ $condition .= " AND "; } $condition .= " (m_item.item_name LIKE  :item_name '%' or m_item.item_name LIKE '%' :item_name '%' or m_item.item_name Like '%' :item_name ) ";
		}	

		if($this->chk_qty==1){
			if($this->sign){
				if($condition!=""){
					$condition .= " AND ";
				}
				if($this->sign =="between"){	
					$condition .= " ((total_stock)-(`use`+lost+damage+expire)) between :qtyfrom and :qtyto ";
				}	
				else if($this->sign =="<"){
					$condition .= " ((total_stock)-(`use`+lost+damage+expire)) < :qtyfrom ";
				}
				else if($this->sign ==">"){
					$condition .= " ((total_stock)-(`use`+lost+damage+expire)) > :qtyfrom ";
				}
				else if($this->sign =="="){
					$condition .= " ((total_stock)-(`use`+lost+damage+expire)) = :qtyfrom ";
				}

			}
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT m_stock_balance.*,(((total_stock)-(`use`+lost+damage+`expire`))) AS quantity, category, type, capital_price
		FROM m_stock_balance
		LEFT JOIN m_item ON m_stock_balance.item_id=m_item.id " . $condition . " order by m_item.id";
		$stmt = $this->conn->prepare($query);

		
		if($this->type) $stmt->bindParam(":type", $this->type);
		if($this->category) $stmt->bindParam(":category", $this->category);
		if($this->item_name) $stmt->bindParam(":item_name", $this->item_name);
		if($this->chk_qty==1){
			$stmt->bindParam(":qtyfrom", $this->qtyfrom);
			if($this->sign == "between"){
				$stmt->bindParam(":qtyto", $this->qtyto);
			}
		} 
		$stmt->execute();
		return $stmt;
	}

	function searchsb(){
		$condition = "";
		
		if($this->category){
			if($condition!=""){ $condition .= " AND "; } $condition .= " category =:category ";
		}	

		if($this->item_id){
			if($condition!=""){ $condition .= " AND "; } $condition .= " item_id =:item_id ";
		}	
		if($this->item_name){
			if($condition!=""){ $condition .= " AND "; } $condition .= " (item_name LIKE  :item_name '%' or item_name LIKE '%' :item_name '%' or item_name Like '%' :item_name ) ";
		}	
		if($this->store){
			if($condition!=""){ $condition .= " AND "; } $condition .= " store =:store ";
		}	
		if($this->qtyfrom){
			if($this->sign){
				if($condition!=""){
					$condition .= " AND ";
				}
				if($this->sign =="between"){	
					$condition .= " ((total_stock)-(`use`+lost+damage+`expire`)) between :qtyfrom and :qtyto ";
				}	
				else if($this->sign =="<"){
					$condition .= " ((total_stock)-(`use`+lost+damage+`expire`)) < :qtyfrom ";
				}
				else if($this->sign ==">"){
					$condition .= " ((total_stock)-(`use`+lost+damage+`expire`)) > :qtyfrom ";
				}
				else if($this->sign =="="){
					$condition .= " ((total_stock)-(`use`+lost+damage+`expire`)) = :qtyfrom ";
				}

			}
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT stock_balance.*,(((total_stock)-(`use`+lost+damage+`expire`))) AS quantity, category, price, minimum_stock_level
		FROM stock_balance
		LEFT JOIN item ON stock_balance.item_id=item.code " . $condition . " order by item_id";
		$stmt = $this->conn->prepare($query);

		
		if($this->category) $stmt->bindParam(":category", $this->category);
		if($this->item_id) $stmt->bindParam(":item_id", $this->item_id);
		if($this->item_name) $stmt->bindParam(":item_name", $this->item_name);
		if($this->store) $stmt->bindParam(":store", $this->store);
		if($this->qtyfrom){
			$stmt->bindParam(":qtyfrom", $this->qtyfrom);
			if($this->sign == "between"){
				$stmt->bindParam(":qtyto", $this->qtyto);
			}
		} 
		
		$stmt->execute();
		return $stmt;
	}

	function getLowStockItem(){
		$condition = "";	

		if($this->category){
			$condition = " AND category =:category ";
		}

		if($this->category){
			if($condition!=""){ $condition .= " AND "; }
			$condition .= " category=:category ";
		}

		// if($condition!=""){
		// 	$condition = " WHERE " . $condition;
		// }

		$query = " SELECT code, name, category, supplier, price, total_stock, minimum_stock_level, (total_stock)-(`use`+lost+damage+`expire`) AS remain FROM stock_balance
		LEFT JOIN item ON stock_balance.item_id = item.code WHERE (total_stock)-(`use`+lost+damage+`expire`)<=minimum_stock_level " . $condition;

		$stmt = $this->conn->prepare($query);
		$this->category=htmlspecialchars(strip_tags($this->category));

		if($this->category) $stmt->bindParam(":category", $this->category);
		$stmt->execute();
		return $stmt;
	}

}
