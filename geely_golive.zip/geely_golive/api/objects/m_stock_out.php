<?php
class MStockOut{

	private $conn;
	private $table_name = "m_stock_out";
	//field list start
	public $id;	
	public $stock_out_date;	
	public $store;
	public $item_id;
	public $item_name;	
	public $quantity;	
	public $use;
	public $lost;
	public $damage;
	public $expire;
	public $stock_out_by;
	public $stock_out_receive_by;
	public $remark;
	public $entry_by;
	public $entry_date_time;
	//field list end
	//condition start
	public $df;
	public $dt;
	//condition end
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET stock_out_date=:stock_out_date, `store`=:store, item_id=:item_id, item_name=:item_name, quantity=:quantity, `use`=:use, lost=:lost, damage=:damage, expire=:expire, stock_out_by=:stock_out_by, stock_out_receive_by=:stock_out_receive_by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":stock_out_date", $this->stock_out_date);
		$stmt->bindParam(":store", $this->store);
		$stmt->bindParam(":item_id", $this->item_id);
		$stmt->bindParam(":item_name", $this->item_name);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":use", $this->use);
		$stmt->bindParam(":lost", $this->lost);
		$stmt->bindParam(":damage", $this->damage);
		$stmt->bindParam(":expire", $this->expire);
		$stmt->bindParam(":stock_out_by", $this->stock_out_by);
		$stmt->bindParam(":stock_out_receive_by", $this->stock_out_receive_by);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}	 
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllRows(){
		$condition = "";

		if($this->stock_out_date){
			if($condition!=""){ $condition .= " AND "; }
			$condition .= " SUBSTRING(stock_out_date,1,10) =:stock_out_date ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM " . $this->table_name . $condition . "  ORDER BY  id, stock_out_date";
		$stmt = $this->conn->prepare($query);

		if($this->stock_out_date) $stmt->bindParam(":stock_out_date", $this->stock_out_date);
		$stmt->execute();
		return $stmt;
	}
	
	function searchReturn(){
		$condition = "";		
		if($this->df){
			if($condition!=""){ $condition .= " AND "; } $condition .= " SUBSTRING(m_stock_out.stock_out_date,1,10) >= :df ";
		}	
		if($this->dt){
			if($condition!=""){ $condition .= " AND "; } $condition .= " SUBSTRING(m_stock_out.stock_out_date,1,10) <= :dt ";
		}	
		if($this->item_name){
			if($condition!=""){ $condition .= " AND "; } $condition .= " (m_stock_out.item_name LIKE  :item_name '%' or m_stock_out.item_name LIKE '%' :item_name '%' or m_stock_out.item_name Like '%' :item_name ) ";
		}
		if($this->item_id){
			if($condition!=""){ $condition .= " AND "; }
			$condition .= " m_stock_out.item_id =:item_id ";
		}	

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT m_stock_out.*,m_item.size, IFNULL(return_quantity,0) AS rq
		FROM m_stock_out
		LEFT JOIN m_stock_return ON m_stock_out.id=m_stock_return.stock_out_id
		JOIN m_item ON m_stock_out.item_id=m_item.id " . $condition . "
		ORDER BY m_stock_out.id";
		$stmt = $this->conn->prepare($query);
	 
		if($this->df) $stmt->bindParam(":df", $this->df);
		if($this->dt) $stmt->bindParam(":dt", $this->dt);
		if($this->item_name) $stmt->bindParam(":item_name", $this->item_name);
		if($this->item_id) $stmt->bindParam(":item_id", $this->item_id);
		
		$stmt->execute();
		return $stmt;
	}

	function getOneRow($id){
		$query = "SELECT m_stock_out.*, SUM(IFNULL(return_quantity,0)) as rq FROM " . $this->table_name . "  
		LEFT JOIN m_stock_return ON m_stock_out.id=m_stock_return.stock_out_id WHERE m_stock_out.id = ?";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(1, $id);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";
        if($this->df){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " m_stock_out.stock_out_date >=:df ";
        }

        if($this->dt){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " m_stock_out.stock_out_date <=:dt ";
        }
        
        if($this->store){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " m_stock_out.store =:store ";
        }

        if($this->item_name){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " (m_stock_out.item_name LIKE  :item_name '%' or m_stock_out.item_name LIKE '%' :item_name '%' or m_stock_out.item_name Like '%' :item_name ) ";
        }

        if($this->stock_out_by){
            if($condition!=""){ $condition .= " AND "; }
            $condition .= " (m_stock_out.stock_out_by LIKE  :stock_out_by '%' or m_stock_out.stock_out_by LIKE '%' :stock_out_by '%' or m_stock_out.stock_out_by Like '%' :stock_out_by ) ";
        }
		if($this->use){
			if($condition!=""){ $condition .= " AND "; } $condition .= " `use` =:use ";
		}
		if($this->lost){
			if($condition!=""){ $condition .= " AND "; } $condition .= " lost =:lost ";
		}
		if($this->damage){
			if($condition!=""){ $condition .= " AND "; } $condition .= " damage =:damage ";
		}
		if($this->expire){
			if($condition!=""){ $condition .= " AND "; } $condition .= " expire =:expire ";
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT m_stock_out.*, m_item.*FROM m_stock_out JOIN m_item ON m_stock_out.item_id=m_item.id " . $condition . " order by stock_out_date";
		$stmt = $this->conn->prepare($query);
		$this->df=htmlspecialchars(strip_tags($this->df));
        $this->dt=htmlspecialchars(strip_tags($this->dt));
        $this->store=htmlspecialchars(strip_tags($this->store));
        $this->item_name=htmlspecialchars(strip_tags($this->item_name));
        $this->stock_out_by=htmlspecialchars(strip_tags($this->stock_out_by));
        
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->store) $stmt->bindParam(":store", $this->store);
        if($this->item_name) $stmt->bindParam(":item_name", $this->item_name);
        if($this->stock_out_by) $stmt->bindParam(":stock_out_by", $this->stock_out_by);
		if($this->use) $stmt->bindParam(":use", $this->use);
		if($this->lost) $stmt->bindParam(":lost", $this->lost);
		if($this->damage) $stmt->bindParam(":damage", $this->damage);
		if($this->expire) $stmt->bindParam(":expire", $this->expire);

		$stmt->execute();
		return $stmt;
	}

}
