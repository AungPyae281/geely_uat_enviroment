<?php
class MTargetByMonth{ 
	private $conn;
	private $table_name = "m_target_by_month";
 
    public $id;	
	public $page_id;
	public $name;
	public $month_from;
	public $month_to;
	public $target_like;
	public $target_reach;
	public $target_engagement;
	public $target_booking;
	public $target_lead;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET page_id=:page_id, name=:name, month_from=:month_from, month_to=:month_to, target_like=:target_like, target_reach=:target_reach, target_engagement=:target_engagement, target_booking=:target_booking, target_lead=:target_lead, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":page_id", $this->page_id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":month_from", $this->month_from);
		$stmt->bindParam(":month_to", $this->month_to);
		$stmt->bindParam(":target_like", $this->target_like);
		$stmt->bindParam(":target_reach", $this->target_reach);
		$stmt->bindParam(":target_engagement", $this->target_engagement);
		$stmt->bindParam(":target_booking", $this->target_booking);
		$stmt->bindParam(":target_lead", $this->target_lead);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET page_id=:page_id, name=:name, month_from=:month_from, month_to=:month_to, target_like=:target_like, target_reach=:target_reach, target_engagement=:target_engagement, target_booking=:target_booking, target_lead=:target_lead, entry_by=:entry_by, entry_date_time=:entry_date_time where id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":page_id", $this->page_id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":month_from", $this->month_from);
		$stmt->bindParam(":month_to", $this->month_to);
		$stmt->bindParam(":target_like", $this->target_like);
		$stmt->bindParam(":target_reach", $this->target_reach);
		$stmt->bindParam(":target_engagement", $this->target_engagement);
		$stmt->bindParam(":target_booking", $this->target_booking);
		$stmt->bindParam(":target_lead", $this->target_lead);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function exist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE name = ?";
		$stmt = $this->conn->prepare( $query );
		$this->name=htmlspecialchars(strip_tags($this->name));	
	 
		$stmt->bindParam(1, $this->name);	
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function getAllRows(){
		$query = "SELECT m_target_by_month.*, m_pages.name AS page_name FROM " . $this->table_name . " join m_pages on " . $this->table_name . ".page_id=m_pages.id order by entry_date_time desc";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllTargetForDTG(){
		$query = "SELECT * FROM " . $this->table_name;
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function search(){
        $condition = "";
        
        if($this->month_from){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " m_target_pages.month >= :month_from";
        }

        if($this->month_to){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " m_target_pages.month <= :month_to";
        }

        if($this->name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " m_target_by_month.name = :name";
        }

        // if($this->page_id){
        //     if($condition!=""){
        //         $condition .= " AND ";
        //     }
        //     $condition .= " m_target_by_month.page_id = :page_id";
        // }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT  m_target_pages.page_id, m_target_by_month.name AS target_name, m_pages.name AS page_name,m_target_by_month.month_from, m_target_by_month.month_to, 
		SUM(p_like) AS total_like, IFNULL(m_target_by_month.target_like,0) AS target_like, CEIL(IFNULL((SUM(p_like)/m_target_by_month.target_like)*100,0)) AS ach_like,
		SUM(p_reach) AS total_reach, IFNULL(m_target_by_month.target_reach,0) AS target_reach, CEIL(IFNULL((SUM(p_reach)/m_target_by_month.target_reach)*100,0)) AS ach_reach,
		SUM(p_engagement) AS total_engagement, IFNULL(m_target_by_month.target_engagement,0) AS target_engagement, CEIL(IFNULL((SUM(p_engagement)/m_target_by_month.target_engagement)*100,0)) AS ach_engagement,
		SUM(p_booking) AS total_booking, IFNULL(m_target_by_month.target_booking,0) AS target_booking, CEIL(IFNULL((SUM(p_booking)/m_target_by_month.target_booking)*100,0)) AS ach_booking,
		SUM(p_lead) AS total_lead, IFNULL(m_target_by_month.target_lead,0) AS target_lead, CEIL(IFNULL((SUM(p_lead)/m_target_by_month.target_lead)*100,0)) AS ach_lead
		FROM m_target_pages
		right JOIN m_target_by_month ON m_target_pages.page_id=m_target_by_month.page_id left JOIN m_pages ON m_target_pages.page_id=m_pages.id" . $condition . " GROUP BY m_target_by_month.id";

        $stmt = $this->conn->prepare($query);
        if($this->month_from) $stmt->bindParam(":month_from", $this->month_from);
        if($this->month_to) $stmt->bindParam(":month_to", $this->month_to);
        if($this->name) $stmt->bindParam(":name", $this->name);
        $stmt->execute();
        return $stmt;
    }

    function summaryTarget(){
        $query = "SELECT target_like AS targets FROM m_target_by_month WHERE name=:name
		UNION all
		SELECT target_reach AS targets FROM m_target_by_month WHERE name=:name
		UNION all
		SELECT target_engagement AS targets FROM m_target_by_month WHERE name=:name
		UNION all
		SELECT target_booking AS targets FROM m_target_by_month WHERE name=:name
		UNION all
		SELECT target_lead AS targets FROM m_target_by_month WHERE name=:name";
		$stmt = $this->conn->prepare( $query );

		if($this->name) $stmt->bindParam(":name", $this->name);

		$stmt->execute();
		return $stmt;
    }

    function summaryActual(){
        $query = "SELECT sum(p_like) AS actuals FROM m_target_pages WHERE page_id=:page_id AND month<=:month_to AND month>=:month_from
		UNION ALL
		SELECT sum(p_reach) AS actuals FROM m_target_pages WHERE page_id=:page_id AND month<=:month_to AND month>=:month_from
		UNION ALL
		SELECT sum(p_engagement) AS actuals FROM m_target_pages WHERE page_id=:page_id AND month<=:month_to AND month>=:month_from
		UNION ALL
		SELECT sum(p_booking) AS actuals FROM m_target_pages WHERE page_id=:page_id AND month<=:month_to AND month>=:month_from
		UNION ALL
		SELECT sum(p_lead) AS actuals FROM m_target_pages WHERE page_id=:page_id AND month<=:month_to AND month>=:month_from";
		$stmt = $this->conn->prepare( $query );

		if($this->page_id) $stmt->bindParam(":page_id", $this->page_id);
		if($this->month_from) $stmt->bindParam(":month_from", $this->month_from);
		if($this->month_to) $stmt->bindParam(":month_to", $this->month_to);

		$stmt->execute();
		return $stmt;
    }
}
