<?php
class MTargetPages{
 
    // database connection and table name
    private $conn;
    private $table_name = "m_target_pages";
 
	// object properties
	
	public $id;
	public $page_id;		
    public $month;    
	public $p_like;
	public $p_reach;		
	public $p_engagement;
	public $p_lead;
	public $p_booking;
	public $entry_by;
	public $entry_date_time;

	public $page_name;
	public $name;
	public $year;

    public function __construct($db){
        $this->conn = $db;
    }	

    function getAllRows(){
		$condition = "";	

		if($this->month){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `month` =:month";
		}
		if($this->page_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " m_pages.name =:page_name";
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT m_target_pages.*, m_pages.name as page_name FROM " . $this->table_name . " LEFT JOIN m_pages ON m_target_pages.page_id=m_pages.id " . $condition . " ORDER BY `month`, m_pages.name";
		$stmt = $this->conn->prepare($query);
		
		if($this->month) $stmt->bindParam(":month", $this->month);
		if($this->page_name) $stmt->bindParam(":page_name", $this->page_name);

		$stmt->execute();
		return $stmt;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET `" . $this->col_name . "`=:amount WHERE page_id=:page_id AND `month`=:month";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":page_id", $this->page_id);
		$stmt->bindParam(":month", $this->month);
		$stmt->bindParam(":amount", $this->amount);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET page_id=:page_id, `month`=:month, p_like=:p_like, p_reach=:p_reach, p_engagement=:p_engagement, p_lead=:p_lead, p_booking=:p_booking"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":page_id", $this->page_id); 
		$stmt->bindParam(":month", $this->month); 
		$stmt->bindParam(":p_like", $this->p_like); 
		$stmt->bindParam(":p_reach", $this->p_reach); 
		$stmt->bindParam(":p_engagement", $this->p_engagement); 
		$stmt->bindParam(":p_lead", $this->p_lead); 
		$stmt->bindParam(":p_booking", $this->p_booking); 

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function search(){
		$condition = "";	

		if($this->page_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " m_pages.name =:page_name";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM m_pages JOIN (SELECT
		  page_id,
		  'like' AS reason,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%01' THEN p_like END), 0) AS january,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%02' THEN p_like END), 0) AS february,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%03' THEN p_like END), 0) AS march,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%04' THEN p_like END), 0) AS april,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%05' THEN p_like END), 0) AS may,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%06' THEN p_like END), 0) AS june,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%07' THEN p_like END), 0) AS july,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%08' THEN p_like END), 0) AS august,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%09' THEN p_like END), 0) AS september,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%10' THEN p_like END), 0) AS october,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%11' THEN p_like END), 0) AS november,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%12' THEN p_like END), 0) AS december
		FROM m_target_pages WHERE MONTH LIKE :year
		GROUP BY page_id
		UNION ALL
		SELECT
		  page_id,
		  'Reach' AS reason,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%01' THEN p_reach END), 0) AS january,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%02' THEN p_reach END), 0) AS february,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%03' THEN p_reach END), 0) AS march,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%04' THEN p_reach END), 0) AS april,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%05' THEN p_reach END), 0) AS may,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%06' THEN p_reach END), 0) AS june,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%07' THEN p_reach END), 0) AS july,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%08' THEN p_reach END), 0) AS august,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%09' THEN p_reach END), 0) AS september,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%10' THEN p_reach END), 0) AS october,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%11' THEN p_reach END), 0) AS november,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%12' THEN p_reach END), 0) AS december
		FROM m_target_pages WHERE MONTH LIKE :year
		GROUP BY page_id
		UNION ALL
		SELECT
		  page_id,
		  'Engagement' AS reason,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%01' THEN p_engagement END), 0) AS january,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%02' THEN p_engagement END), 0) AS february,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%03' THEN p_engagement END), 0) AS march,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%04' THEN p_engagement END), 0) AS april,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%05' THEN p_engagement END), 0) AS may,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%06' THEN p_engagement END), 0) AS june,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%07' THEN p_engagement END), 0) AS july,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%08' THEN p_engagement END), 0) AS august,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%09' THEN p_engagement END), 0) AS september,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%10' THEN p_engagement END), 0) AS october,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%11' THEN p_engagement END), 0) AS november,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%12' THEN p_engagement END), 0) AS december
		FROM m_target_pages WHERE MONTH LIKE :year
		GROUP BY page_id
		UNION ALL
		SELECT
		  page_id,
		  'Lead' AS reason,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%01' THEN p_lead END), 0) AS january,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%02' THEN p_lead END), 0) AS february,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%03' THEN p_lead END), 0) AS march,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%04' THEN p_lead END), 0) AS april,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%05' THEN p_lead END), 0) AS may,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%06' THEN p_lead END), 0) AS june,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%07' THEN p_lead END), 0) AS july,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%08' THEN p_lead END), 0) AS august,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%09' THEN p_lead END), 0) AS september,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%10' THEN p_lead END), 0) AS october,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%11' THEN p_lead END), 0) AS november,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%12' THEN p_lead END), 0) AS december
		FROM m_target_pages WHERE MONTH LIKE :year
		GROUP BY page_id
		UNION ALL
		SELECT
		  page_id,
		  'Booking' AS reason,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%01' THEN p_booking END), 0) AS january,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%02' THEN p_booking END), 0) AS february,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%03' THEN p_booking END), 0) AS march,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%04' THEN p_booking END), 0) AS april,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%05' THEN p_booking END), 0) AS may,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%06' THEN p_booking END), 0) AS june,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%07' THEN p_booking END), 0) AS july,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%08' THEN p_booking END), 0) AS august,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%09' THEN p_booking END), 0) AS september,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%10' THEN p_booking END), 0) AS october,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%11' THEN p_booking END), 0) AS november,
		  COALESCE(MAX(CASE WHEN MONTH LIKE '%12' THEN p_booking END), 0) AS december
		FROM m_target_pages WHERE MONTH LIKE :year
		GROUP BY page_id) AS fnl ON m_pages.id=fnl.page_id" . $condition;
			
		$stmt = $this->conn->prepare($query);
		
		if($this->year) $stmt->bindParam(":year", $this->year);
		if($this->page_name) $stmt->bindParam(":page_name", $this->page_name);
		
		$stmt->execute();
		return $stmt;
	}

	function getPageLike(){
		$condition = "";	

		if($this->year){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " substring(month,1,4) =:year";
		}
		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " name =:name";
		}
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT * FROM m_target_pages JOIN `m_pages` ON `m_pages`.id=m_target_pages.page_id " . $condition;
		$stmt = $this->conn->prepare($query);
		
		if($this->year) $stmt->bindParam(":year", $this->year);
		if($this->name) $stmt->bindParam(":name", $this->name);

		$stmt->execute();
		return $stmt;
	}
}
