<?php
class MType{
    // database connection and table name
	private $conn;
	private $table_name = "m_type";

    // object properties
    public $id;	
	public $type;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY type";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `type` = :type LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->type = htmlspecialchars(strip_tags($this->type)); 
		$stmt->bindParam(":type", $this->type); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$this->id = htmlspecialchars(strip_tags($this->id));
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET type=:type"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":type", $this->type); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
	
}
