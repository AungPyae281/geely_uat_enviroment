<?php
class Purchase_Permit{
    private $conn;
    private $table_name = "purchase_permit";
 
	public $id;
	public $entry_date;
	public $permit_submission_date;
	public $permit_received_date;
	public $oc_no;
	public $name;
	public $nrc;
	public $mobile_no;
	public $email;
	public $address;
	public $sales_center;
    public $bank;
    public $ac_no;
    public $foreign_currency_balance;
    public $balance_date;

    public $vehicle_type;
	public $brand;	
	public $model_year;
	public $engine_power;
	public $value;
	public $country_of_origin;
	public $commission;
	public $according_to;

    public $other_name;
    public $other_nrc;
    public $other_address; 

    public function __construct($db){
        $this->conn = $db;
    }

    function exist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE oc_no=:oc_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}
    
    function create(){
		$query = "INSERT INTO " . $this->table_name . " SET 
		 entry_date=:entry_date
		,permit_submission_date=:permit_submission_date
		,permit_received_date=:permit_received_date
		,oc_no=:oc_no
		,`name`=:name
		,nrc=:nrc
		,mobile_no=:mobile_no
		,email=:email
		,address=:address
		,sales_center=:sales_center
		,bank=:bank
		,ac_no=:ac_no
		,foreign_currency_balance=:foreign_currency_balance
		,balance_date=:balance_date

		,`vehicle_type`=:vehicle_type
		,`brand`=:brand	
		,`model_year`=:model_year
		,`engine_power`=:engine_power
		,`value`=:value
		,`country_of_origin`=:country_of_origin
		,`commission`=:commission
		,`according_to`=:according_to

		,other_name=:other_name
		,other_nrc=:other_nrc
		,other_address=:other_address";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":entry_date", $this->entry_date);
		$stmt->bindParam(":permit_submission_date", $this->permit_submission_date);
		$stmt->bindParam(":permit_received_date", $this->permit_received_date);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":nrc", $this->nrc);
		$stmt->bindParam(":mobile_no", $this->mobile_no);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":sales_center", $this->sales_center);
		$stmt->bindParam(":bank", $this->bank);
		$stmt->bindParam(":ac_no", $this->ac_no);
		$stmt->bindParam(":foreign_currency_balance", $this->foreign_currency_balance);
		$stmt->bindParam(":balance_date", $this->balance_date);

		$stmt->bindParam(":vehicle_type", $this->vehicle_type);
		$stmt->bindParam(":brand", $this->brand	);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":value", $this->value);
		$stmt->bindParam(":country_of_origin", $this->country_of_origin);
		$stmt->bindParam(":commission", $this->commission);
		$stmt->bindParam(":according_to", $this->according_to);

		$stmt->bindParam(":other_name", $this->other_name);
		$stmt->bindParam(":other_nrc", $this->other_nrc);
		$stmt->bindParam(":other_address", $this->other_address); 

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function update(){
		$query = "UPDATE `" . $this->table_name . "` SET 
		 entry_date=:entry_date
		,permit_submission_date=:permit_submission_date
		,permit_received_date=:permit_received_date
		,name=:name
		,nrc=:nrc
		,mobile_no=:mobile_no
		,email=:email
		,address=:address
		,sales_center=:sales_center
		,bank=:bank
		,ac_no=:ac_no
		,foreign_currency_balance=:foreign_currency_balance
		,balance_date=:balance_date
		,vehicle_type=:vehicle_type
		,brand=:brand	
		,model_year=:model_year
		,engine_power=:engine_power
		,value=:value
		,country_of_origin=:country_of_origin
		,commission=:commission
		,according_to=:according_to
		,other_name=:other_name
		,other_nrc=:other_nrc
		,other_address=:other_address WHERE oc_no=:oc_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":entry_date", $this->entry_date);
		$stmt->bindParam(":permit_submission_date", $this->permit_submission_date);
		$stmt->bindParam(":permit_received_date", $this->permit_received_date);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":nrc", $this->nrc);
		$stmt->bindParam(":mobile_no", $this->mobile_no);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":sales_center", $this->sales_center);
		$stmt->bindParam(":bank", $this->bank);
		$stmt->bindParam(":ac_no", $this->ac_no);
		$stmt->bindParam(":foreign_currency_balance", $this->foreign_currency_balance);
		$stmt->bindParam(":balance_date", $this->balance_date);
		$stmt->bindParam(":vehicle_type", $this->vehicle_type);
		$stmt->bindParam(":brand", $this->brand	);
		$stmt->bindParam(":model_year", $this->model_year);
		$stmt->bindParam(":engine_power", $this->engine_power);
		$stmt->bindParam(":value", $this->value);
		$stmt->bindParam(":country_of_origin", $this->country_of_origin);
		$stmt->bindParam(":commission", $this->commission);
		$stmt->bindParam(":according_to", $this->according_to);
		$stmt->bindParam(":other_name", $this->other_name);
		$stmt->bindParam(":other_nrc", $this->other_nrc);
		$stmt->bindParam(":other_address", $this->other_address);	

		if($stmt->execute()){ 
			return true;
		}
		return false;
    }

    function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no LIMIT 0,1";

		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":oc_no", $this->oc_no);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->entry_date = $row['entry_date'];
			$this->permit_submission_date = $row['permit_submission_date'];
			$this->permit_received_date = $row['permit_received_date'];
			$this->oc_no = $row['oc_no'];
			$this->name = $row['name'];
			$this->nrc = $row['nrc'];
			$this->mobile_no = $row['mobile_no'];
			$this->email = $row['email'];
			$this->address = $row['address'];
			$this->sales_center = $row['sales_center'];
			$this->bank = $row['bank'];
			$this->ac_no = $row['ac_no'];
			$this->foreign_currency_balance = $row['foreign_currency_balance'];
			$this->balance_date = $row['balance_date'];
			$this->vehicle_type = $row['vehicle_type'];
			$this->brand = $row['brand'];
			$this->model_year = $row['model_year'];
			$this->engine_power = $row['engine_power'];
			$this->value = $row['value'];
			$this->country_of_origin = $row['country_of_origin'];
			$this->commission = $row['commission'];
			$this->according_to = $row['according_to'];
			$this->other_name = $row['other_name'];
			$this->other_nrc = $row['other_nrc'];
			$this->other_address = $row['other_address']; 
		}
	}
}
?>