<?php
class ServiceCustomerCar{
    private $conn;
    private $table_name = "service_customer_car";
 
	public $id;
	public $service_customer_id;
	public $service_car_id;
	public $plate_no;
	public $entry_by;
	public $entry_date_time;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_customer_id=:service_customer_id, service_car_id=:service_car_id, plate_no=:plate_no, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->bindParam(":service_car_id", $this->service_car_id);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}  
}
?>