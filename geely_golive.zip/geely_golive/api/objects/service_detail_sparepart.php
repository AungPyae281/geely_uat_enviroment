<?php
class ServiceDetailSparepart{ 
	private $conn;
	private $table_name = "service_detail_sparepart";

	public $id;
	public $service_id;
	public $code;
	public $name;
	public $qty;
	public $receive_qty; 
	public $warranty;
	public $fixed_price;

	public function __construct($db){
		$this->conn = $db;
	}

	function getSparepartDetail(){
		$query = "SELECT service_detail_sparepart.*, sales_price AS price FROM " . $this->table_name . " LEFT JOIN sparepart ON service_detail_sparepart.code=sparepart.code WHERE service_id=:service_id ORDER BY id, code, name";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->execute();
		return $stmt;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_id=:service_id, code=:code, name=:name, qty=:qty, warranty=:warranty";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":qty", $this->qty); 
		$stmt->bindParam(":warranty", $this->warranty);

		if($stmt->execute()){ 
			return true;
		}
		return false;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET qty=qty + :qty WHERE service_id=:service_id AND `code`=:code AND warranty=:warranty";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":warranty", $this->warranty);
		$stmt->bindParam(":qty", $this->qty); 

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getSparepartDetailForIN(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE service_id=:service_id ORDER BY (qty - receive_qty)";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->execute();
		return $stmt;
	}

	function updateIssueNote(){
		$query = "UPDATE " . $this->table_name . " SET receive_qty = receive_qty + :quantity WHERE service_id=:service_id AND code=:code AND warranty=:warranty";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":warranty", $this->warranty);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

	function checkSparepart(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE service_id=:service_id AND `code`=:code AND warranty=:warranty LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":code", $this->code);
		$stmt->bindParam(":warranty", $this->warranty);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;	
		}
		return false;
	}

	function updateByFinalInspection(){
		$query = "UPDATE sparepart_stock_balance AS ssb RIGHT JOIN (SELECT `code`, (SUM(qty) - SUM(receive_qty)) AS unlock_qty FROM service_detail_sparepart WHERE qty>receive_qty GROUP BY `code`) AS sds ON ssb.sparepart_code=sds.`code` SET ssb.total_lock = (ssb.total_lock - unlock_qty) WHERE ssb.store_name=:store_name;
			UPDATE service_detail_sparepart AS sds LEFT JOIN sparepart ON sds.code=sparepart.code SET sds.qty=sds.receive_qty, sds.fixed_price=sparepart.sales_price WHERE service_id=:service_id;
			DELETE FROM service_detail_sparepart WHERE service_id=:service_id AND qty=0;
			UPDATE service SET invoice_date=:invoice_date, payment_due_date_time=:payment_due_date_time WHERE service.id=:service_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->bindParam(":invoice_date", $this->invoice_date);
		$stmt->bindParam(":payment_due_date_time", $this->payment_due_date_time);
		if($stmt->execute()){ 
			return true;
		}
		return false;
	}
}
?>