<?php
class ServicePayment{ 
	private $conn;
	private $table_name = "service_payment";

	public $id;
	public $service_id;
	public $date;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $amount;
	public $paid_by;
	public $description;
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$statement = "";
		if($this->upload_receipt){
			$statement = ", upload_receipt=:upload_receipt ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET service_id=:service_id, date=:date, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, amount=:amount, paid_by=:paid_by, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":paid_by", $this->paid_by);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		if($this->upload_receipt) $stmt->bindParam(":upload_receipt", $this->upload_receipt);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	} 
}
?>