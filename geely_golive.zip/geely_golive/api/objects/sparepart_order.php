<?php
class SparepartOrder{ 
	private $conn;
	private $table_name = "sparepart_order"; 

	public $id;
	public $gic_code;
	public $order_date;
	public $service_center_id;
	public $service_center;
	public $store_name;
	public $order_by;
	public $remark; 
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE LOWER(gic_code)=LOWER(:gic_code) LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":gic_code", $this->gic_code);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gic_code=:gic_code, order_date=:order_date, service_center_id=:service_center_id, service_center=:service_center, store_name=:store_name, `order_by`=:order_by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gic_code", $this->gic_code);
		$stmt->bindParam(":order_date", $this->order_date);
		$stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->bindParam(":order_by", $this->order_by);
		$stmt->bindParam(":remark", $this->remark); 
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	} 

	function getAllOrderList(){	 
		$query = "SELECT so1.id, so1.gic_code, so1.service_center, so1.store_name, so1.order_date, so1.order_by, so1.remark, so1.total_items FROM (SELECT sparepart_order_id FROM sparepart_order_detail WHERE order_quantity>receive_quantity GROUP BY sparepart_order_id) AS sod
			LEFT JOIN (SELECT so.*, total_items FROM sparepart_order AS so
			LEFT JOIN (SELECT sparepart_order_id, COUNT(DISTINCT(sparepart_code)) AS total_items FROM sparepart_order_detail GROUP BY sparepart_order_id) AS sod_ti ON so.id=sod_ti.sparepart_order_id) AS so1 ON sod.sparepart_order_id=so1.id WHERE so1.service_center=:service_center ORDER BY so1.gic_code, so1.order_date";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}
}
?>