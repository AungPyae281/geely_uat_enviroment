<?php
class SparepartOrderDetail{ 
	private $conn;
	private $table_name = "sparepart_order_detail"; 

	public $id;
	public $sparepart_order_id;
	public $sparepart_pre_order_id;
	public $sparepart_code;
	public $sparepart_name; 
	public $order_quantity;
	public $receive_quantity;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET sparepart_order_id=:sparepart_order_id, sparepart_pre_order_id=:sparepart_pre_order_id, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, order_quantity=:order_quantity";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_order_id", $this->sparepart_order_id);
		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name); 
		$stmt->bindParam(":order_quantity", $this->order_quantity);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllOrderDetailByOrderID(){ 
		$query = "SELECT sod.*, IFNULL(spo.wl_id, '') AS wl_id FROM sparepart_order_detail AS sod
			LEFT JOIN sparepart_pre_order AS spo ON sod.sparepart_pre_order_id=spo.id WHERE sod.sparepart_order_id=:sparepart_order_id ORDER BY sod.sparepart_pre_order_id, sod.sparepart_code";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":sparepart_order_id", $this->sparepart_order_id);
		$stmt->execute();
		return $stmt;
	}

	function updateReceiveQty(){
		$query = "UPDATE " . $this->table_name . " SET receive_quantity=receive_quantity + :receive_quantity WHERE sparepart_order_id=:sparepart_order_id AND sparepart_pre_order_id=:sparepart_pre_order_id AND sparepart_code=:sparepart_code";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_order_id", $this->sparepart_order_id);
		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":receive_quantity", $this->receive_quantity);

		if($stmt->execute()){
			return true;
		}
		return false;	
	}
}
?>