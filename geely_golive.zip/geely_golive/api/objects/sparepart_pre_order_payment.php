<?php
class SparepartPreOrderPayment{ 
	private $conn;
	private $table_name = "sparepart_pre_order_payment";

	public $id;
	public $sparepart_pre_order_id;
	public $date;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $amount;
	public $paid_by;
	public $description;
	public $upload_receipt;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$statement = "";
		if($this->upload_receipt){
			$statement = ", upload_receipt=:upload_receipt ";
		}
		$query = "INSERT INTO " . $this->table_name . " SET sparepart_pre_order_id=:sparepart_pre_order_id, date=:date, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, amount=:amount, paid_by=:paid_by, description=:description, entry_by=:entry_by, entry_date_time=:entry_date_time" . $statement;

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);
		$stmt->bindParam(":amount", $this->amount);
		$stmt->bindParam(":paid_by", $this->paid_by);
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		if($this->upload_receipt) $stmt->bindParam(":upload_receipt", $this->upload_receipt);

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function getPreOrderPaymentDetail(){	
		$query = "SELECT * FROM " . $this->table_name . " WHERE sparepart_pre_order_id=:sparepart_pre_order_id ORDER BY id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->execute();
		return $stmt;
	}
}
?>