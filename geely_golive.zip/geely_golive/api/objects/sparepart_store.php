<?php
class SparepartStore{ 
	private $conn;
	private $table_name = "sparepart_store";

    public $id;	
	public $name;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `name` = :name LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":name", $this->name);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `name`=:name";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":name", $this->name);
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `name`";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	} 

	function getAllStoreExceptSelfStore(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE `name`<>:store_name ORDER BY `name`";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->execute();
		return $stmt;
	} 
}
?>
