<?php
class SparepartSubGroup{ 
    private $conn;
    private $table_name = "sparepart_sub_group";
  
	public $id;
	public $group_name; 
	public $name;
  
	public function __construct($db){
	    $this->conn = $db;
	}
	
	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `name` = :name LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":name", $this->name);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `group_name`=:group_name, `name`=:name";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":group_name", $this->group_name);
		$stmt->bindParam(":name", $this->name);
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `group_name`, `name`";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	} 	

	function getSubGroupByGroup(){ 
		$query = "SELECT * FROM " . $this->table_name . " WHERE group_name = :group_name ORDER BY `name`";
		$stmt = $this->conn->prepare($query);
		$this->group_name = htmlspecialchars(strip_tags($this->group_name));
		$stmt->bindParam(":group_name", $this->group_name);
		$stmt->execute();
		return $stmt;
	} 
}
