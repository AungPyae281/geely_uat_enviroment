<?php
class StaffSalesCenter{
    private $conn;
    private $table_name = "staff_sales_center";
 
	public $id;	
	public $staff_id;
	public $sales_center_id;
    public $sales_center;
	public $entry_by;
	public $entry_date_time; 
 
    public function __construct($db){
        $this->conn = $db;
    }	

    function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE staff_id=:staff_id AND sales_center_id=:sales_center_id"; 
		$stmt = $this->conn->prepare($query); 

		$stmt->bindParam(":staff_id", $this->staff_id); 
		$stmt->bindParam(":sales_center_id", $this->sales_center_id); 

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;		
	}
 
 	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET staff_id=:staff_id, sales_center_id=:sales_center_id, sales_center=:sales_center, entry_by=:entry_by, entry_date_time=:entry_date_time"; 
		$stmt = $this->conn->prepare($query); 

		$stmt->bindParam(":staff_id", $this->staff_id); 
		$stmt->bindParam(":sales_center_id", $this->sales_center_id); 
		$stmt->bindParam(":sales_center", $this->sales_center); 
		$stmt->bindParam(":entry_by", $this->entry_by); 
		$stmt->bindParam(":entry_date_time", $this->entry_date_time); 

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	 

		if($this->staff_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " staff_id = :staff_id ";
		}

		if($this->sales_center_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " sales_center_id = :sales_center_id ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT ssc.*, `name` FROM " . $this->table_name . " AS ssc LEFT JOIN staff ON ssc.staff_id = staff.id " . $condition . " ORDER BY `name`, sales_center_id ";
		$stmt = $this->conn->prepare($query); 		 

		if($this->staff_id) $stmt->bindParam(":staff_id", $this->staff_id);
		if($this->sales_center_id) $stmt->bindParam(":sales_center_id", $this->sales_center_id);
		
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id=:id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":id", $this->id); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

    function getAllRowsByStaff(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE staff_id=:staff_id ORDER BY sales_center";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->execute();
		return $stmt;
	}
}
?>