<?php
class TrialBalance{
    private $conn;
    private $table_name = "trial_balance";
 
	public $id;
	public $gl_code;
	public $date_time;
	public $transaction_id;
	public $gl_code_ref;
	public $statement;
	public $debit;
	public $credit;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    } 

    function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET gl_code=:gl_code, date_time=:date_time, transaction_id=:transaction_id, gl_code_ref=:gl_code_ref, statement=:statement, debit=:debit, credit=:credit, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":date_time", $this->date_time);
		$stmt->bindParam(":transaction_id", $this->transaction_id);
		$stmt->bindParam(":gl_code_ref", $this->gl_code_ref);
		$stmt->bindParam(":statement", $this->statement);
		$stmt->bindParam(":debit", $this->debit);
		$stmt->bindParam(":credit", $this->credit); 
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getAllTransactionByGLCode(){
		$query = "SELECT
		    LEFT(date_time, 10) AS date,
		    statement AS `transaction`,
		    debit,
		    credit,
		    entry_date_time
		FROM
		    trial_balance
		WHERE
		    gl_code =:gl_code AND
		    LEFT(date_time, 10) >=:date_from AND
		    LEFT(date_time, 10) <=:date_to AND
		    `statement` IS NOT NULL
		UNION
		SELECT
		    LEFT(date_time, 10) AS date,
		    statement AS `transaction`,
		    debit,
		    credit,
		    entry_date_time
		FROM
		    trial_balance
		WHERE
		    gl_code_ref =:gl_code AND
		    LEFT(date_time, 10) >=:date_from AND
		    LEFT(date_time, 10) <=:date_to AND
		    `statement` IS NOT NULL
		ORDER BY
		    date, entry_date_time";
		$stmt = $this->conn->prepare( $query );

		$this->date_from=htmlspecialchars(strip_tags($this->date_from));
		$this->date_to=htmlspecialchars(strip_tags($this->date_to));
		$this->gl_code=htmlspecialchars(strip_tags($this->gl_code));
		 
		$stmt->bindParam(":date_from", $this->date_from);
		$stmt->bindParam(":date_to", $this->date_to);
		$stmt->bindParam(":gl_code", $this->gl_code);
		
		$stmt->execute();
		return $stmt;
	} 
}
?>
