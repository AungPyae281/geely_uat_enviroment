<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/customer.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $customer = new Customer($db);
    $data = json_decode(file_get_contents("php://input"));

    $customer->sales_center = $data->sales_center;   
    $customer->name = $data->name;
    $customer->staff_name = $data->staff_name;

    $stmt = $customer->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => (int)$id,
                "registration_no" => ($registration_no)?$registration_no:"",
                "staff_name" => ($staff_name)?$staff_name:"",
                "name" => ($name)?$name:"",
                "sales_center" => ($sales_center)?$sales_center:"",
    			"mobile_no" => ($mobile_no)?$mobile_no:"",            
                "nrc_no" => ($nrc_no)?$nrc_no:"",
                "vehicle_of_interest" => ($vehicle_of_interest)?$vehicle_of_interest:"",	
                "sales_status" => ($sales_status)?$sales_status:"",
                "township" => ($township)?$township:""
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>