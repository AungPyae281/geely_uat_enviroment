<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/deposit_receipt.php';
	 
	$database = new Database();
	$db = $database->getConnection();

	$deposit_receipt = new DepositReceipt($db);
	$data = json_decode(file_get_contents("php://input"));

	$deposit_receipt->oc_no = $data->oc_no;
	$deposit_receipt->getOneRow();	

	$arr = array(
	    "r_date" =>  $deposit_receipt->r_date,
	    "gl_code" =>  $deposit_receipt->gl_code,
	    "gl_code_bank_or_cash" =>  $deposit_receipt->gl_code_bank_or_cash,
	    "r_payment_type" =>  $deposit_receipt->r_payment_type,
		"receipt_no" => $deposit_receipt->receipt_no,
		"receipt_img" => $deposit_receipt->receipt_img,
		"deposit" => number_format($deposit_receipt->deposit)
	);
	echo json_encode($arr);
?>