<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/order.php';
	include_once '../../objects/car_stock.php';
	include_once '../../objects/customer.php';
	include_once '../../objects/approval.php';
	// include_once '../objects/notification.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$order = new Order($db);
	$car_stock = new CarStock($db);
	$customer = new Customer($db);
	$approval = new Approval($db);
	// $notification = new Notification($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		$order->date = $data->date;

		$order->vehicle_status = $data->vehicle_status; 
		$order->brand_b = $data->brand_b; 
		$order->year = date("Y"); 
		$order->oc_no = $order->getGenerateOCNo();
		$order->customer_id = $data->customer_id;
		$order->broker_id = ($data->broker_id!="")?$data->broker_id:0;
		$order->broker_name = $data->broker_name;

		$order->brand = $data->brand;
		$order->model = $data->model;
		$order->grade = $data->grade;
		$order->model_year = $data->model_year;
		$order->vin_no = $data->vin_no;
		$order->engine_no = $data->engine_no; 
		$order->exterior_color = $data->exterior_color;
		$order->interior_color = $data->interior_color;

		$order->sales_center = $data->sales_center;

		$order->sales_type = $data->sales_type;
		$order->vehicle_price = $data->vehicle_price;
		$order->commercial_tax = $data->commercial_tax;
		$order->rtad_tax = $data->rtad_tax;
		$order->promotion_code = $data->promotion_code;
		$order->promotion_discount = $data->promotion_discount;
		$order->selling_price = $data->selling_price;
		$order->payment_type = $data->payment_type;
		$order->bank = $data->bank;	
		$order->payment_percent = $data->payment_percent;	
		$order->payment_term = $data->payment_term;	
		$order->deposit = $data->deposit;

		$order->same_as_buyer = $data->same_as_buyer;
		$order->rtad_name = $data->rtad_name;
		$order->rtad_nrc_no = $data->rtad_nrc_no;
		$order->rtad_mobile_no = $data->rtad_mobile_no;
		$order->rtad_township = $data->rtad_township;

		$order->customer_type = $data->customer_type;
		$order->company_name = $data->company_name;
		$order->company_register_no = $data->company_register_no;

		$order->staff_id = $_SESSION['staff_id']; 
		$order->entry_by = $_SESSION['user'];
		$order->entry_date_time = date("Y-m-d H:i:s");  

		if($order->create()){ 
			$customer->id = $data->customer_id;
			$customer->nrc_no = $data->nrc_no;

			$customer->updateFromOrder();

			if($data->vehicle_status!="Production"){
				$car_stock->oc_no = $order->oc_no;
				$car_stock->vin_no = $data->vin_no;
				$car_stock->engine_no = $data->engine_no;
				$car_stock->updateFromOrder();
			}

			$approval->staff_id = $order->staff_id;
			$approval->main_id = $order->oc_no;
			$approval->process = 'Confirm Order'; 
			$approval->create();

			// $notification->sender_id = $_SESSION['staff_id'];
			// $notification->process = "Confirm Order";
			// $notification->message = $order->oc_no . '<br>Request Approval';
			// $notification->entry_date_time = date("Y-m-d H:i:s");
			// $notification->create(); 

			$arr = array( 
				"message" => "created",
				"oc_no" => $order->oc_no
			);
		}else{
			$arr = array(
				"message" => "error",
				"oc_no" => $order->oc_no
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>	