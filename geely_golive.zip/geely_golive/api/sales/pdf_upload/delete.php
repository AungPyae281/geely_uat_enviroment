<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';   
    
    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $sales = new Sales($db);  
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;
    $sales->column_name = $data->column_name;
    $sales->file_name = "|" . $data->file_name . "|";

    if($sales->deleteDC()){
        if(file_exists("./upload/" . $data->oc_no . "/" . $data->file_name)){
            unlink("./upload/" . $data->oc_no . "/" . $data->file_name);
        }
        $arr = array(
            "message" => "deleted"
        );
    }else{
        $arr = array(
            "message" => "error"
        );
    }
    echo json_encode($arr);
?>

