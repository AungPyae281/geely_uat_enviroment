<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/ready_to_deliver.php';
    include_once '../../objects/sales.php';
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $ready_to_deliver = new ReadyToDeliver($db);
    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['staff_id']!=""){
        $ready_to_deliver->oc_no = $data->oc_no;

        $ready_to_deliver->ai_sidestep = $data->ai_sidestep; 
        $ready_to_deliver->ai_floor_mat = $data->ai_floor_mat; 
        $ready_to_deliver->ai_power_tail_gate = $data->ai_power_tail_gate;
        $ready_to_deliver->ai_other = $data->ai_other;

        $ready_to_deliver->wfi_60 = $data->wfi_60;
        $ready_to_deliver->wfi_80 = $data->wfi_80;
        $ready_to_deliver->wfi_other = $data->wfi_other;

        $ready_to_deliver->detailing_complete = $data->detailing_complete;
        $ready_to_deliver->detailing_general = $data->detailing_general;

        $ready_to_deliver->gift = $data->gift;

        if($ready_to_deliver->exist()){
            if(!$ready_to_deliver->update()){
                $arr = array(
                    "message" => "RTD Update Error"
                );
                echo json_encode($arr);
                die();
            }
        }else{
            if(!$ready_to_deliver->create()){
                $arr = array(
                    "message" => "RTD Create Error"
                );
                echo json_encode($arr);
                die();
            }
        }

        $sales->oc_no = $data->oc_no;
        $sales->column_name = "rtd_done";

        if($sales->updateDone()){

            $sales->status = "Ready to Deliver";
            $sales->processing = "Handover";
            
            if(!$sales->updateStatus()){
                $arr = array(
                    "message" => "Status Update Error"
                );
                echo json_encode($arr);
                die();
            }
        }else{
            $arr = array(
                "message" => "error"
            );
            echo json_encode($arr);
            die();
        }

        $arr = array(
            "message" => "updated"
        );
    }else{
        $arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($arr);
?>