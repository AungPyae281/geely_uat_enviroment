<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../../config/database.php';
	include_once '../../objects/ready_to_deliver.php';
	include_once '../../objects/sales.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$ready_to_deliver = new ReadyToDeliver($db);
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));

	$ready_to_deliver->oc_no = $data->oc_no;
	$ready_to_deliver->getOneRow();

	$sales->oc_no = $data->oc_no;
	$sales->getOneRow();

	$arr = array(
		"oc_no" => $ready_to_deliver->oc_no,

		"ai_sidestep" => $ready_to_deliver->ai_sidestep, 
		"ai_floor_mat" => $ready_to_deliver->ai_floor_mat, 
		"ai_power_tail_gate" => $ready_to_deliver->ai_power_tail_gate,
		"ai_other" => $ready_to_deliver->ai_other,

		"wfi_60" => $ready_to_deliver->wfi_60,
		"wfi_80" => $ready_to_deliver->wfi_80,
		"wfi_other" => $ready_to_deliver->wfi_other,

		"detailing_complete" => $ready_to_deliver->detailing_complete,
		"detailing_general" => $ready_to_deliver->detailing_general,

		"gift" => $ready_to_deliver->gift,

		"rtd_done" => $sales->rtd_done
	);

	echo json_encode($arr);
		
?>