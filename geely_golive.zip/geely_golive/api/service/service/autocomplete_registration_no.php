<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $service = new Service($db);
    $data = json_decode(file_get_contents("php://input"));

    $arr = array();

    if($_SESSION['service_center']!=""){

        $service->service_center = $data->service_center;
        $service->registration_no = $data->registration_no;

        $stmt = $service->autocompleteRegistrationNo();
        $num = $stmt->rowCount();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    "registration_no" => $registration_no
                );
                array_push($arr, $detail);
            }
        }
    }
    echo json_encode($arr);
?>