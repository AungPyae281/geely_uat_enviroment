<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service.php';
	include_once '../../objects/warranty_car.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service = new Service($db);
	$warranty_car = new WarrantyCar($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$img_path = "";
		if (!is_dir('./upload/' . $service->registration_no)) {
	        mkdir('./upload/' . $service->registration_no, 0777, true);
	    }
	    if(file_exists("./upload/" . $service->registration_no . "/car-inspection-sheet.png")){
	        unlink("./upload/" . $service->registration_no . "/car-inspection-sheet.png");
	    }
		if($data->car_inspection_img!=""){
	        $img = $data->car_inspection_img;
	        $img_data = base64_decode(explode(',', $img)[1]);
	        $img_path = "./upload/" . $service->registration_no . "/car-inspection-sheet.png";
	        $success = file_put_contents($img_path, $img_data);
		}
		$service->car_inspection_img = $img_path;

		$service->id = $data->id; 
		$service->kilometer = $data->kilometer;
		$service->car_receive_date = $data->car_receive_date;
		$service->car_receive_time = date("H:i", strtotime($data->car_receive_time));
		$service->insp_service_booklet = $data->insp_service_booklet;
		$service->insp_jack_and_handle = $data->insp_jack_and_handle;
		$service->insp_paking_sign = $data->insp_paking_sign;
		$service->insp_spare_wheel = $data->insp_spare_wheel;
		$service->insp_mobile_charger = $data->insp_mobile_charger;
		$service->insp_car_key = $data->insp_car_key;
		$service->insp_wheel_tax = $data->insp_wheel_tax;
		$service->insp_fuel_level = $data->insp_fuel_level;
		$service->insp_other_items = $data->insp_other_items;
		$service->insp_remark = $data->insp_remark;

		if($service->update()){
			$warranty_car->date = date("Y-m-d");
			$warranty_car->kilometer = (int)$data->kilometer;
			$warranty_car->status = "Expire (Kilometer)";
			$warranty_car->update_by = "System";
			$warranty_car->update_date_time = date("Y-m-d H:i:s");

			$warranty_car->updateStatusExpireKilometer();

			$msg_arr = array(
				"message" => "updated"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>