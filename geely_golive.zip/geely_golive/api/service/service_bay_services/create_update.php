<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_bay_services.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$service_bay_services = new ServiceBayServices($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service_bay_services->service_center_bay_id = $data->service_center_bay_id;
		$service_bay_services->entry_by = $_SESSION['user'];
		$service_bay_services->entry_date_time = date("Y-m-d H:i:s");

		$service_bay_services->delete();

		foreach ($data->sbs_lists as $sbslist) {
			$service_bay_services->service_item_id = $sbslist->service_item_id;

			if(!$service_bay_services->create()){
				$msg_arr = array(
					"message" => "error"
				);
				echo json_encode($msg_arr);
				die();
			}
		}

		$msg_arr = array(
			"message" => (($data->action=="Create")?"created":"updated")
		);
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	
	echo json_encode($msg_arr);
?>