<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_bay_services.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_bay_services = new ServiceBayServices($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_bay_services->service_center_bay_id = $data->service_center_bay_id;

    $stmt = $service_bay_services->getServiceBayServicesDetail();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
    		$detail = array(
                "service_center_bay_id" => $service_center_bay_id,
                "service_item_id" => $service_item_id,
                "name" => $name,
                "bay_no" => $bay_no,
                "code" => $code,
                "service_item" => $service_item
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>