<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_car.php';
	include_once '../../objects/service_customer_car.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$service_car = new ServiceCar($db);
	$service_customer_car = new ServiceCustomerCar($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service_car->service_customer_id = $data->customer_id;
		$service_car->brand = $data->brand;	
		$service_car->model = $data->model;
		$service_car->model_year = $data->model_year;
		$service_car->exterior_color = $data->exterior_color;
		$service_car->vin_no = "";
		$service_car->engine_no = "";
		$service_car->plate_no = $data->plate_no;
		$service_car->entry_by = $_SESSION['user'];
		$service_car->entry_date_time = date("Y-m-d H:i:s");

		$service_customer_car->service_customer_id = $data->customer_id;
		$service_customer_car->plate_no = $data->plate_no;
		$service_customer_car->entry_by = $service_car->entry_by;
		$service_customer_car->entry_date_time = $service_car->entry_date_time;

		if($service_car->isExist()){
			$msg_arr = array(
				"message" => "duplicate"
			);
		}else{
			if($service_car->create()){
				$service_customer_car->service_car_id = $service_car->id;	
				if(!$service_customer_car->create()){
					$msg_arr = array(
						"message" => "errorCC"
					);
					echo json_encode($msg_arr);
					die();
				}
			  	$msg_arr = array(
					"message" => "created"
				);
			}else{
				$msg_arr = array(
					"message" => "error"
				);
			}
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>