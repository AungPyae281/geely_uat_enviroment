<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_car.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_car = new ServiceCar($db);   

    $service_car->service_customer_id = $_GET["cid"];

    $stmt = $service_car->getAllServiceCarExceptOwner();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array();
    $i = 0;

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                ++$i,
                $plate_no,
                $name,
                $brand,
                $model,
                $model_year, 
                $exterior_color, 
                $id,
                $service_customer_id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>