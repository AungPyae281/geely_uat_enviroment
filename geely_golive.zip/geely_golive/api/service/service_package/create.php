<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_package.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$service_package = new ServicePackage($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		
		$service_package->package_name = $data->package_name;
		$service_package->entry_by = $_SESSION['user'];
		$service_package->entry_date_time = date("Y-m-d H:i:s");

		if($service_package->isExist()){
			$arr = array(
				"message" => "duplicate"
			);
		}else{
			if($service_package->create()){
			  	$arr = array(
					"message" => "created"
				);
			}else{
				$arr = array(
					"message" => "error"
				);
			}
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	
	echo json_encode($arr);
?>	