<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_package.php';
	include_once '../../objects/service_package_detail.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$service_package = new ServicePackage($db);
	$service_package_detail = new ServicePackageDetail($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){

		$service_package->id = $data->service_package_id;
		$service_package->discount= $data->discount; 

		$service_package_detail->service_package_id = $data->service_package_id;

		if($service_package->updatePackage()){

			$service_package_detail->delete();
			foreach ($data->sp_lists as $splist) {
				$service_package_detail->service_item_id = $splist->service_item_id;

				if(!$service_package_detail->create()){
					$msg_arr = array(
						"message" => "errorDU"
					);
					echo json_encode($msg_arr);
					die();
				}
			}
			$msg_arr = array(
				"message" => (($data->action=="Create")?"created":"updated")
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	
	echo json_encode($msg_arr);
?>