<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	 
	include_once '../../config/database.php';
	include_once '../../objects/staff_service_center.php';
	
	$database = new Database();
	$db = $database->getConnection();
	
	$staff_service_center = new StaffServiceCenter($db);
	$data = json_decode(file_get_contents("php://input"));

	$staff_service_center->service_center_id = $data->service_center_id;

	$stmt = $staff_service_center->getAllRows();
	$num = $stmt->rowCount();
	
	$arr = array();
	$arr["records"] = array();

	if($num>0){	
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id, 
				"staff_id" => $staff_id,
				"staff_name" => $name,
				"service_center_id" => $service_center_id,
				"service_center" => $service_center
			);	
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>