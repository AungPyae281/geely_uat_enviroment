<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sparepart_order.php';
	include_once '../../objects/sparepart_order_detail.php';
	include_once '../../objects/sparepart_pre_order.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start(); 

	$database = new Database();
	$db = $database->getConnection();

	$sparepart_order = new SparepartOrder($db);
	$sparepart_order_detail = new SparepartOrderDetail($db);
	$sparepart_pre_order = new SparepartPreOrder($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$sparepart_order->gic_code = $data->gic_code;
		$sparepart_order->order_date = $data->order_date;
		$sparepart_order->service_center_id = $data->service_center_id;
		$sparepart_order->service_center = $data->service_center;
		$sparepart_order->store_name = $data->store_name;
		$sparepart_order->order_by = $data->order_by;
		$sparepart_order->remark = $data->remark;
		$sparepart_order->entry_by = $_SESSION['user'];
		$sparepart_order->entry_date_time = date("Y-m-d H:i:s");
	 
		if($sparepart_order->isExist()){
			$msg_arr = array(
				"message" => "duplicate"
			);
		}else if($sparepart_order->create()){

			foreach ($data->spareparts_lists as $splist) {
				$sparepart_order_detail->sparepart_order_id = $sparepart_order->id;
				$sparepart_order_detail->sparepart_pre_order_id = $splist->sparepart_pre_order_id;
				$sparepart_order_detail->sparepart_code = $splist->sparepart_code;
				$sparepart_order_detail->sparepart_name = $splist->sparepart_name; 
				$sparepart_order_detail->order_quantity = $splist->quantity;

				if(!$sparepart_order_detail->create()){
					$msg_arr = array(
						"message" => "errorDetail"
					);
					echo json_encode($msg_arr);
					die();
				}
			}

			$sparepart_pre_order->id = $data->pre_order_ids;
			$sparepart_pre_order->updateMakeOrder();
			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "errorC"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}	
	echo json_encode($msg_arr);
?>