<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../../config/database.php';
	include_once '../../objects/sparepart_origin.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	 
	$sparepart_origin = new SparepartOrigin($db);

	$stmt = $sparepart_origin->getAllRows();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"name" => $name
			);
			array_push($arr["records"], $detail);
		} 
	}
	echo json_encode($arr);
?>