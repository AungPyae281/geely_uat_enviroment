<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/brand.php';

	$database = new Database();
	$db = $database->getConnection();

	$brand = new Brand($db);
	$data = json_decode(file_get_contents("php://input"));

	$brand->brand = $data->brand;

	if($brand->isExist()){
		$arr = array(
			"message" => "duplicate"
		);
	}else{
		if($brand->create()){
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>