<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/grade.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $grade = new Grade($db);
    $data = json_decode(file_get_contents("php://input"));

    $grade->model_id = $data->model_id;
    $grade->grade = $data->grade;

    $stmt = $grade->getEnginePowerByGrade();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => $id,
                "grade" => $grade,
                "engine_power" => $engine_power
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>