<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/route.php';

	$database = new Database();
	$db = $database->getConnection();

	$route = new Route($db);
	$data = json_decode(file_get_contents("php://input"));

	$route->dashboard = $data->dashboard;
	$route->module = $data->modules;
	$route->route = $data->route;
	$route->process = $data->processs;
	$route->title = $data->title;
	$route->create = $data->create;
	$route->read = $data->read;
	$route->update = $data->update;
	$route->delete = $data->deletes;
	$route->export = $data->exportss;
	$route->print = $data->print;

		if($route->create()){
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	echo json_encode($arr);
?>