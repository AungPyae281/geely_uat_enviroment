<?php
	// required headers
	header("Access-Control-Allow-Origin: *"); 
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/test_drive_car.php';
	 
	$database = new Database();
	$db = $database->getConnection();

	$test_drive_car = new TestDriveCar($db);
	$data = json_decode(file_get_contents("php://input"));

	$test_drive_car->id = $data->id;
	 
	if($test_drive_car->delete()){
	    echo 'deleted';
	}else{
	    echo 'error';
	}
?>