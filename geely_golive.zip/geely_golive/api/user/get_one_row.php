<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	 
	include_once '../config/database.php';
	include_once '../objects/user.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$user = new User($db);
	$data = json_decode(file_get_contents("php://input"));

	$user->id = $data->id;
	$user->getOneRow();

	$arr = array(
		"staff_id" => $user->staff_id,
		"staff_name" => $user->staff_name,
		"username" => $user->username,
		"userrole" => $user->userrole,
		"dashboard" => $user->dashboard,
		"profilepicture" => (($user->profilepicture)?explode("./", $user->profilepicture)[1]:""),
		"department" => $user->department,
		"position" => $user->position
	);
	echo json_encode($arr);
?>