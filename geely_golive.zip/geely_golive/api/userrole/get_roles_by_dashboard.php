<?php 
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: POST");
	header("Content-Type: application/json; charset=UTF-8");
	  
	include_once '../config/database.php';
	include_once '../objects/user_role.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$user_role = new UserRole($db);
	$data = json_decode(file_get_contents("php://input"));

	$user_role->dashboard = $data->dashboard;
	$stmt = $user_role->getRolesByDashboard();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();
	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"dashboard" => $dashboard,
				"role_name" => $role_name
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>