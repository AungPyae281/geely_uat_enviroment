<?php
	header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../config/database.php';
	include_once '../objects/m_target_by_month.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$m_target_by_month = new MTargetByMonth($db);

	$data = json_decode(file_get_contents("php://input"));

	$m_target_by_month->page_id = $data->page_id;
	$m_target_by_month->month_from = $data->month_from;
	$m_target_by_month->month_to = $data->month_to;
	$m_target_by_month->name = $data->name;

	$target = array();
	$actual = array();

	$stmt = $m_target_by_month->summaryTarget();	
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		extract($row);
		array_push($target, (int)$targets);
	}

	$stmt = $m_target_by_month->summaryActual();	
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		extract($row);
		array_push($actual, (int)$actuals);
	}

	$percentages = [];

	// Calculate percentages
	for ($i = 0; $i < count($target); $i++) {
	    // Calculate percentage
	    $percentage = ($actual[$i] / $target[$i]) * 100;
	    
	    // Round to 2 decimal places
	    $percentage = round($percentage, 2);
	    
	    // Store the percentage in the result array
	    $percentages[] = $percentage;
	}

	$arr=array(
		"target" => $target,
		"actual" => $actual,
		"achievements" => $percentages
	);

	echo json_encode($arr);

?>