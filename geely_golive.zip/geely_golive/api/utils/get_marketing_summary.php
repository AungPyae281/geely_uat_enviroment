<?php
	header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../config/database.php';
	include_once '../objects/m_target_pages.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$m_target_pages = new MTargetPages($db);

	$data = json_decode(file_get_contents("php://input"));

	$m_target_pages->year = date("Y");
	$m_target_pages->name = $data->name;

	$pagelikeArr = array();
	$pagereachArr = array();
	$pageengagementArr = array();
	$pageleadArr = array();
	$pagebookingArr = array();

	$stmt = $m_target_pages->getPageLike();	
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		extract($row);
		array_push($pagelikeArr, (int)$p_like);
		array_push($pagereachArr, (int)$p_reach);
		array_push($pageengagementArr, (int)$p_engagement);
		array_push($pageleadArr, (int)$p_lead);
		array_push($pagebookingArr, (int)$p_booking);
	}

	$arr=array(
		"page_like" => $pagelikeArr,
		"page_reach" => $pagereachArr,
		"page_engagement" => $pageengagementArr,
		"page_lead" => $pageleadArr,
		"page_booking" => $pagebookingArr
	);

	echo json_encode($arr);

?>