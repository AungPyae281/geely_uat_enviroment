<?php
	$app_name = "Geely";
	$app_url = "http://103.101.16.250:9090/geely_golive/"; 
	$current_url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] .parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
?>
