<?php include '../header.php'; ?>
<?php
	date_default_timezone_set('Asia/Rangoon'); 
	$start_date = date("Y-m") . "-01";

	$accno = "";
    if(isset($_GET['accno'])){
        if(!empty($_GET['accno'])){
            $accno = $_GET['accno'];
        }
    }
?>
<style>
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Account Transaction</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (From):</label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (To):</label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
									</div>		
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboAccount"></select>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search </button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Transaction List <span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">#</th>
								<th>Date</th>
								<th>Transaction</th>
								<th>Debit</th>
								<th>Credit</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var start_date = '<?= $start_date; ?>';
	var accno = '<?= $accno; ?>';
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date", start_date);
	$("#txtDatePicker1").val(start_date);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker();
		getAllAccount(); 
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	}); 

	function getAllAccount(){
		$("#cboAccount").find("option").remove();
		$.ajax({
			url: APP_URL + "api/finance/gl_account/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.account_no==accno){
					$("#cboAccount").append("<option value = '" + v.gl_code + "' selected>" + v.gl_code + " (" + v.name + ")</option>");
					search();
				}else{
					$("#cboAccount").append("<option value = '" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
				}
			});
			search();
		});
	}

	function search(){
		$("#loading").css("display","block");
		var df = $("#txtDatePicker1").val();	
		var dt = $("#txtDatePicker2").val();
		var gl_code = $("#cboAccount").val();

		$("#myTable").find("tbody").find("tr").remove(); 
		$.ajax({
			type: "POST",
			url: APP_URL + "api/finance/gl_account/get_all_transaction.php",
			data: JSON.stringify({ df: df, dt: dt, gl_code: gl_code })
		}).done(function(data) {	
			$("#loading").css("display","none");
			if((data.records.length - 1)>1){
				$("#total_records").text(" - " + (data.records.length - 1) + " records found.");
			}else{
				$("#total_records").text(" - " + (data.records.length - 1) + " record found.");
			}
			$.each(data.records, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr style="' + ((i==0)?'font-size: 16px; font-weight: bold;':'') + '">')
					.append("<td>" + ((i>0)?(i):'') + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.transaction + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + ((i>0)?((v.debit>0)?parseFloat(v.debit).toLocaleString():''):parseFloat(v.debit).toLocaleString()) + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + ((v.credit>0)?parseFloat(v.credit).toLocaleString():'') + "</td>")
				);
			});
			$("#myTable").find("tbody")
			.append($('<tr style="font-size: 16px; font-weight: bold;">')
				.append("<td></td>")
				.append("<td></td>")
				.append("<td>Closing Balance</td>")
				.append("<td style='text-align: right; padding-right: 20px;'>" + parseFloat(data.closing_balance).toLocaleString() + "</td>")
				.append("<td style='text-align: right; padding-right: 20px;'></td>")
			);
       });
	}
</script>
