<?php include '../header.php'; ?>
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Define Purchase Price - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Car List</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row"> 
									<div class="col-md-8"></div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Order No.: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboOrderNo"></select>
											</div>
										</div>
									</div>
								</div>	
								<div class="card-header">
									<h3 class="card-title">Production Order List</h3>
								</div>
								<div class="card-body table-responsive p-0" style="height:265px; overflow-y: auto;">
									<table id="myTable" class="table table-bordered table-hover text-nowrap">
										<thead style="background-color: #ecedee;">
											<tr>
												<th>#</th>
												<th>Brand</th>
												<th>Model</th>
												<th>Model Year</th>
												<th>Grade</th>
												<th>Engine Power</th>
												<th>Interior Color</th>
												<th>Exterior Color</th>
												<th>Vehicle Price</th>
											</tr>
										</thead>
										<tbody style="cursor: pointer;"></tbody>
									</table>
								</div>
								<div class="row" style="margin-top: 25px;">
									<div class="col-md-10"></div>
									<div class="col-md-2">
										<div class="form-group row">
											<div class="col-md-12">
												<button type="button" class="btn btn-primary btn-block" onclick="validateAndUpdate()">Save</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>

						<center>
							<div class="modal fade" id="myModalVehiclePrice">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 35%; top: 29px;">
										<div class="modal-header">
											<h4 class="modal-title">Define Purchase Price</h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<div class="row">
												<div class="col-md-12">
													<div class="form-group row">
														<label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Price:</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="txtVehiclePrice" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" value="0" maxlength="15" style="text-align: right;">
														</div>
														<div class="col-md-1"></div>
													</div>
												</div>
												<div class="col-md-12">
													<div class="form-group row" style="margin-bottom: 0px;">
														<div class="col-md-7"></div>
														<div class="col-md-4">
															<button type="button" class="btn btn-primary btn-block" onclick="update()">Update</button>
														</div>
														<div class="col-md-1"></div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</center>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date", customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();   
		fillOrderNo();
	});

	$("#cboOrderNo").change(function(){
		getAllProductionOrderList();
    });

	function fillOrderNo(){
        $("#cboOrderNo").find("option").remove();
        $("#cboOrderNo").append("<option value='' data-id=''></option>");
        $.ajax({
            url: APP_URL + "api/supply_chain/production_order/get_all_order_no.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboOrderNo").append("<option value='" + v.order_no + "' data-id='" + v.id + "'>" + v.order_no + "</option>");
            });
        });
    }

	function getAllProductionOrderList(){ 
		var order_no = $("#cboOrderNo").val();
		$("#myTable").find("tbody").find("tr").remove();
		if(order_no){
			$.ajax({
				type: "POST",
				url: APP_URL + "api/supply_chain/production_order/get_all_production_list_by_order_no.php",
				data: JSON.stringify({ order_no: order_no })
			}).done(function(data) { 
				$.each(data.records, function(i, v) {
					$("#myTable").find("tbody")
					.append($('<tr data-id="' + v.id + '">')
						.append("<td>" + (i + 1) + "</td>")
						.append("<td>" + v.brand + "</td>")
						.append("<td>" + v.model + "</td>")
						.append("<td>" + v.model_year + "</td>")
						.append("<td>" + v.grade + "</td>")
						.append("<td>" + v.engine_power + "</td>")
						.append("<td>" + v.interior_color + "</td>")
						.append("<td>" + v.exterior_color + "</td>")
						.append("<td style='text-align: right; background-color: #bddbce; cursor: pointer;' onclick='VehiclePrice(this)'>" + v.vehicle_price + "</td>") 
					)
				});
			});
		}
	}

	function VehiclePrice(obj){
		$("#myModalVehiclePrice").modal('show'); 
		$("#txtVehiclePrice").val($(obj).text());
		OBJ = obj;
	}

	function update(){
		$("#myModalVehiclePrice").modal('hide');
		$(OBJ).text($("#txtVehiclePrice").val());
	} 

	function validateAndUpdate(){ 
		var car_lists = [];
		$("#myTable tbody tr").each(function (){
			var vehicle_price = parseInt($(this).find("td").eq(8).text().replace(/,/g, ''));
			if(vehicle_price>0){
				var car_list = {
					"id" : $(this).attr("data-id"),
					"vehicle_price" : vehicle_price
				};
				car_lists.push(car_list);
			}
		}); 

		if(car_lists.length==0){
			bootbox.alert("Please fill at least one vehicle price.");
		}else{ 
			bootbox.confirm({
	        	message: "<h4>Are you sure that you want to define price?</h4>",
	        	buttons: {
	        		confirm: {
	        			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
	        			className: 'btn-primary'
	        		},
	        		cancel: {
	        			label: '<span class="glyphicon glyphicon-remove"></span> No',
	        			className: 'btn-danger'
	        		}
	        	},
	        	callback: function (result) {
	        		if(result){
						$("#loading").css("display", "block");
	        			$.ajax({
							url: APP_URL + "api/supply_chain/production_order/update.php",
							type: "POST",
							data: JSON.stringify({ car_lists: car_lists })
						}).done(function(data) {
							$("#loading").css("display", "none");
							if(data.message=="updated"){
								fillOrderNo();
								$("#myTable tbody tr").remove();
								bootbox.alert("Vehicle Price Successfully Updated.");
							}else{
								bootbox.alert("Error on server side.");
							}
						});
	        		}
	        	}
	        });
		}
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}	

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }	
</script>	
