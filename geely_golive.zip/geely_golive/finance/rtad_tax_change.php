<?php include '../header.php'; ?> 
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>RTAD TAX - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div> 
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-3">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Brand: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboBrand"></select>
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Model: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboModel"></select>
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Model Year: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboModelYear"></select>
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Grade: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboGrade"></select>
											</div>
										</div>
									</div>
								</div>	
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-9">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">
								List <span id="total_records" style="font-weight:bold;"></span>
							</h3>
						</div>
						<div class="card-body p-0" style="max-height: 340px; overflow: auto;">
							<table class="table table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%; text-align: center; vertical-align: middle;">#</th>
										<th style="text-align: center; vertical-align: middle;">Brand</th>
										<th style="text-align: center; vertical-align: middle;">Model</th>
										<th style="text-align: center; vertical-align: middle;">Model Year</th>
										<th style="text-align: center; vertical-align: middle;">Grade</th>
										<th style="text-align: center; vertical-align: middle;">Engine Power</th>
										<th style="text-align: center; vertical-align: middle;">RTAD Tax</th>
										<th style="width: 8%; text-align: center; vertical-align: middle;"><div class="col-lg-12 icheck-success d-inline"><input type="checkbox" id="chkSelectAll"><label for="chkSelectAll">All</label></div></th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">
								<span id="txtAcademicYear" style="font-weight:bold;">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Date: </label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">RTAD Tax: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtRTADTax" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" value="0" style="text-align:right">
										</div>
									</div>
									<div class="form-group row">
										<div class="col-md-4"></div>
										<div class="col-md-8">
											<button type="button" class="btn btn-success btn-block" onclick="validateAndUpdate()">Change Tax</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker').datepicker();
		
		fillBrand();
		getAllGradeList(); 
	});

	$("#chkSelectAll").click(function() {
	    if ($(this).is(':checked')) {
	        $('input:checkbox').prop('checked', true);	
	    } else {
	        $('input:checkbox').prop('checked', false);	
	    }
	});

	$("#cboBrand").change(function(){
		fillModel();
		getAllGradeList();
    });

	$("#cboModel").change(function(){
		getModelYear();
		getAllGradeList();
	});

	$("#cboModelYear").change(function(){
		fillGrade();
		getAllGradeList();
	});

	$("#cboGrade").change(function(){
		getAllGradeList();
	});

	function fillBrand(){
        $("#cboBrand").find("option").remove();
        $("#cboBrand").append("<option value='' data-id=''></option>");

        $.ajax({
            url: APP_URL + "api/supply_chain/brand/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBrand").append("<option value='" + v.brand + "' data-id='" + v.id + "'>" + v.brand + "</option>");
            });
            fillModel();
        });
    }

    function fillModel(){
        var brand = $("#cboBrand option:selected").val();
        $("#cboModel").find("option").remove();
        $("#cboModelYear").find("option").remove();
        $("#cboGrade").find("option").remove();

        if(brand){
            $.ajax({
                url: APP_URL + "api/supply_chain/model/get_model_by_brand.php",
                type: "POST",
                data: JSON.stringify({ brand: brand })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboModel").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboModel").append("<option value='" + v.model + "' data-id='" + v.id + "'>" + v.model + "</option>");
                });
                getModelYear();
            });
        }
    }

    function getModelYear(){
        var model = $("#cboModel").val();
        $("#cboModelYear").find("option").remove();
        $("#cboGrade").find("option").remove();

        if(model){
            $.ajax({
                url: APP_URL + "api/supply_chain/model/get_model_year_by_model.php",
                type: "POST",
                data: JSON.stringify({ model: model })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboModelYear").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboModelYear").append("<option value='" + v.model_year + "' data-id='" + v.id + "'>" + v.model_year + "</option>");
                });
                fillGrade();
            });
        }
    }

    function fillGrade(){
        var model_id = $("#cboModelYear option:selected").attr("data-id");
        $("#cboGrade").find("option").remove();

        if(model_id){
            $.ajax({
                url: APP_URL + "api/supply_chain/grade/get_all_grade.php",
                type: "POST",
                data: JSON.stringify({ model_id: model_id })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboGrade").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboGrade").append("<option value='" + v.grade + "' data-id='" + v.id + "'>" + v.grade + "</option>");
                });
            });
        }
    }

	function getAllGradeList(){ 
		var brand = $("#cboBrand").val();
		var model = $("#cboModel").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		$("#myTable").find("tbody").find("tr").remove();

		$.ajax({
			type: "POST",
			url: APP_URL + "api/supply_chain/grade/get_all_grade_list.php",
			data: JSON.stringify({ brand: brand, model: (model)?model:"", model_year: (model_year)?model_year:"", grade: (grade)?grade:"" })
		}).done(function(data) {
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}

			$.each(data.records, function(i, v) { 
				$("#myTable").find("tbody")
				.append($('<tr data-id="' + v.id + '">')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.brand + "</td>")
					.append("<td>" + v.model + "</td>")
					.append("<td>" + v.model_year + "</td>")
					.append("<td>" + v.grade + "</td>")
					.append("<td>" + v.engine_power + "</td>")
					.append("<td style='text-align: right;'>" + v.rtad_tax + "</td>")
					.append("<td style='text-align:center;'><div class='icheck-success d-inline'><input type='checkbox' id='" + v.id + "'><label for='" + v.id + "'></label></div></td>")
				);
			});
		});
	}

	function validateAndUpdate(){ 
		var date = $("#txtDatePicker").val();
		var rtad_tax = parseInt($("#txtRTADTax").val().replace(/,/g, ''));
		var rtad_list = [];
		$("#myTable tbody tr td input[type='checkbox']").each(function (){
			var ischecked = $(this).is(":checked");
			if(ischecked){
				var rtad = {
					"id" : $(this).parent().parent().parent().attr("data-id")
				}
				rtad_list.push(rtad);
			}
		}); 

		if(rtad_list.length==0){
			bootbox.alert("Please choose at least one car.");
		}else if(rtad_tax==0){
			bootbox.alert("Please fill rtad tax."); 
		}else{ 
			bootbox.confirm({
	        	message: "<h4>Are you sure that you want to change rtad tax?</h4>",
	        	buttons: {
	        		confirm: {
	        			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
	        			className: 'btn-primary'
	        		},
	        		cancel: {
	        			label: '<span class="glyphicon glyphicon-remove"></span> No',
	        			className: 'btn-danger'
	        		}
	        	},
	        	callback: function (result) {
	        		if(result){
						$("#loading").css("display", "block");
	        			$.ajax({
							url: APP_URL + "api/supply_chain/grade/update_rtad_tax.php",
							type: "POST",
							data: JSON.stringify({ date: date, rtad_tax: rtad_tax, rtad_list: rtad_list })
						}).done(function(data) {
							$("#loading").css("display", "none");
							if(data.message=="updated"){
								$("#txtDatePicker").val(customDate);
								$("#datePicker").datepicker("setDate", customDate);
								$("#txtRTADTax").val(0);
								$("#myTable tbody tr").remove();
								$("input[type='checkbox']").prop('checked', false);
								bootbox.alert("Successfully change rtad tax.");
								getAllGradeList();
							}else{
								bootbox.alert("Error on server side.");
							}
						});
	        		}
	        	}
	        });
		}
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }
</script>