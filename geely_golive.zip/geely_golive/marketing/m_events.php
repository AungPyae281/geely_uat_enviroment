<?php include '../header.php'; ?>
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.displaY{
		display: none;
	}
	.align{
		text-align: right;
	}
</style>

<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Events - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div> 
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Input</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-8">
										<div class="row" style="padding-top: 9px;">
											<div class="col-md-6">				
												<div class="form-group row">
													<label class="col-md-4 col-form-label" style="text-align: right;">Description<span style="color: red; font-size: 20px;">*</span>: </label>
													<div class="col-md-8">
														<select type="text" class="form-control" id="cboDescription">
															<option value=""></option>
															<option value="Number of Attendance (or) Walk In">Number of Attendance (or) Walk In</option>
															<option value="Number of Test Drive">Number of Test Drive</option>
															<option value="Potential">Potential</option>
															<option value="Booking">Booking</option>
															<option value="Reach">Reach</option>
															<option value="React">React</option>
															<option value="Comment">Comment</option>
															<option value="Share">Share</option>
														</select>
													</div>
												</div>
											</div>
											<div class="col-md-1"></div>
											<div class="col-md-3">
												<div class="form-group row">
													<label class="col-md-4 col-form-label" style="text-align: right;">Target<span style="color: red; font-size: 20px;">*</span>: </label>
													<div class="col-md-8">
														<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" id="txtTarget" name="txtTarget" value="0" min="1" style="text-align:right;">
													</div>
												</div>
											</div>
											<div class="col-md-2">												
												<div class="form-group row">
													<div class="col-md-12">
														<button type="button" class="btn btn-primary btn-block" id="addBt" onclick="add();">Add</button>
													</div>
												</div>
											</div>
										</div>
										<div class="card-body p-0" style="height:300px; overflow-y: auto;background-color: #e6e7e8 !important;">
											<table class="table table-striped table-bordered" id="myTable">
												<thead>                  
													<tr>
														<th style="width: 3%">No.</th>
														<th>Description</th>
														<th style="width: 20%">Target</th>
														<th style="display: none;" id="taR">Actual</th>
														<th style="width: 3%">Delete</th>
													</tr>
												</thead>
												<tbody>                                                
												</tbody>
											</table>
										</div>
										
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Event Name<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtEventName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15">
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Expense Amount.<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" id="txtVoucherNo" name="txtVoucherNo" value="0" min="1" style="text-align:right;">
													<!-- <input type="text" class="form-control" id="txtVoucherNo" disabled>
													<span class="input-group-btn">
														<button type="button" class="btn btn-success" onclick="getAllVoucherNo();" id="btnVoucherNo" style="padding-left: 10px;">. . .</button>
													</span>  -->        
												</div>
											</div>
										</div>
										<!-- <div class="form-group row">
											<div class="col-md-8 col-form-label"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Save</button>
											</div>
										</div> -->
										 <div class="form-group row" id="dFunction" style="display:none;">
	                                        <label class="col-md-4 col-form-label" style="text-align: right;"></label>
	                                        <label class="col-md-3 col-form-label">
	                                        	<div class="icheck-success d-inline" style="padding-left: 3px;">
	                                                <input type="checkbox" id="chkFFDone">
	                                                <label for="chkFFDone"></label>
	                                            </div>
	                                            Done	                                            
	                                        </label>
	                                    </div> 
										<div class="form-group row" style="margin-bottom: 0px;">
											<div class="col-md-8

											"></div>
											<div class="col-md-4 btnAdd">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Add</button>
											</div>
										<!-- 	<div class="col-md-4 btnEdit"></div>
											<div class="col-md-4 btnEdit" style="display: none;">
												<button type="button" class="btn btn-danger btn-block" onclick="clearForm()">Cancel</button>
											</div> -->
											<div class="col-md-4 btnEdit" style="display: none;">
												<button type="button" class="btn btn-primary btn-block" onclick="validateAndSave()" id="doneU">Update</button>
											</div>
										</div> 
									</div>
								</div>
							</div>
						</form>
					</div>

					<center>
						<div class="modal fade" id="myModalVoucherNo">
							<div class="modal-dialog" style="max-width: 100% !important;">
								<div class="modal-content" style="width: 70%;top: 29px;">
									<div class="modal-header" style="padding: 12px;">
										<h4 class="modal-title">Payment List</h4>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<table class="table table-head-fixed" id="myTable1" style="cursor:pointer;">
											<thead>                  
												<tr>
													<th>Date</th>
													<th>Voucher No.</th>
													<th>Request No.</th>
													<th>Receive By</th>
													<th>Description</th>
													<th style="display:none;">Total Payment</th>
													<th style="display:none;">ID</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</center>

				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var id = '<?=$id;?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$('#datePicker').datepicker();
		$("body").addClass("sidebar-collapse");
		if(id){
			$(".btnEdit").css('display', 'block');
			$(".btnAdd").css('display', 'none');	
			$("#cboDescription").prop( "disabled", true );
			$("#txtTarget").prop( "disabled", true );
			$("#addBt").prop( "disabled", true );
			$("#btnVoucherNo").prop( "disabled", true );
			$("#txtDatePicker").prop( "disabled", true );
			$("#txtEventName").prop( "disabled", true );
			$("#taR").css('display', 'block');
			$("#dFunction").css('display', 'block');
			getOneEvent();
		}else{
			$(".btnEdit").css('display', 'none');
			$(".btnAdd").css('display', 'block');	
		}
	});

	function getOneEvent(){
		$.ajax({
			url: APP_URL + "api/marketing/event/get_one_event.php",
			type: "POST",
			data: JSON.stringify({ id: id})
		}).done(function(data) {
			console.log(data);
			$('#txtDatePicker').val(data.date);
			$('#datePicker').datepicker("setDate", data.date);
			$('#txtVoucherNo').val(data.voucher_no);
			$('#txtEventName').val(data.name);
			if(data.done==1){
                $("#chkFFDone").prop( "checked", true );
                $("#doneU").prop("disabled", true);
            }
			$('#txtEventName').val(data.name);
			$.each(data.event_details, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + ($("#myTable tbody tr").length +1) + "</td>")
					.append("<td>" + v.description + "</td>")
					.append("<td style='text-align:right; padding-right:33px;'>" + v.target + "</td>")
					.append("<td><input type='text' style='text-align:right;' class='form-control' value='" + v.actual + "'></td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm'  style='padding: 0px 19px;font-size: 18px;' onclick='$(this).parent().parent().remove();' disabled>×</button></td>")
				);
			});
		});
	}

	function getAllVoucherNo(){
		$("#myModalVoucherNo").modal('show');
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/finance/advance/get_all_rows_for_marketing_dtg.php",
			"columnDefs": [
				{
					'targets': [5, 6],
					"className": 'displaY'
				}
			]
		});	
	} 

	$('#myTable1').on('click', 'tbody tr', function(e){ 
		$("#myTable1 tbody tr").css("color", "");
		$("#myTable1 tbody tr").css("background-color", "");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtVoucherNo").val($(this).find("td").eq(1).text());
		$("#myModalVoucherNo").modal('hide');
	});

	function add(){
		var description = $("#cboDescription").val();
		var target = parseInt($("#txtTarget").val().replace(/,/g, ''));
		var actual = 0;

		if(description==""){
			bootbox.alert("Please fill the description.");
		}else if(target ==0){
			bootbox.alert("Please fill the target.");
		}else{
			$("#myTable").find("tbody")
			.append($('<tr data-id="">')
				.append("<td style='width: 10px'>" + ($("#myTable tbody tr").length +1) + "</td>")
				.append("<td>" + description + "</td>")
				.append("<td style='text-align:right; padding-right: 25px !important;'>" + target.toLocaleString() + "</td>")
				// .append("<td style='display:none;'>" + actual + "</td>")
				.append("<td><input type='text' style='text-align:right;display:none;' class='form-control' value='" + actual + "'></td>")
				.append("<td><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px; font-size: 18px;' onclick='$(this).parent().parent().remove();'>×</button></td>")
			);	
		}
		$("#cboDescription").val("");
		$("#txtTarget").val(0);
	}

	function validateAndSave(){
		var event_details = [];
		$("#myTable tbody tr").each(function (){
			var event_detail = {
				"description" : ($(this).find("td").eq(1).text()),
				"target" : $(this).find("td").eq(2).text().replace(/,/g, ''),
				"actual" : (parseInt($(this).find("td").eq(3).find("input").val().replace(/,/g, '')))? (parseInt($(this).find("td").eq(3).find("input").val().replace(/,/g, ''))):0
			}
			event_details.push(event_detail);
		});

		var event = {
			"id":id,
			"date": $("#txtDatePicker").val(),
			"voucher_no": $("#txtVoucherNo").val(),
			"name": $("#txtEventName").val(),
			"done": ($("#chkFFDone").prop("checked"))?1:0,
			"event_details":event_details
		};
		if($("#txtVoucherNo").val() == "0"){
			bootbox.alert("Please fill Expense Amount.");
		}else if($("#txtEventName").val() == ""){
			bootbox.alert("Please fill the event name.");
		}else if( $("#myTable tbody tr").length==0){
			bootbox.alert("Please fill event details.");
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/event/create_update.php",
				type: "POST",
				data: JSON.stringify(event)
			}).done(function(data) {
				if(data.message=="created"){
					document.location = APP_URL + "marketing/m_events.php";
					// clearForm();
					// gotoView(data.purchase_id,this);
				}else if(data.message=="updated"){
					document.location = APP_URL + "reports/m_events.php";
					// clearForm();
					// gotoView(data.purchase_id,this);
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }
</script>
