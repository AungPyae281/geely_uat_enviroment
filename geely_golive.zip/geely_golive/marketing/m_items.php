<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Item - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<form role="form" id="frmEntry">	
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">Info</h3>
							</div>
							<div class="card-body">	
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Brand<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtType" value='' class="form-control" disabled value="-">
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllType()" id="btnType" style="padding-left: 10px;">. . .</button>
													</span>         
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Category<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtCategory" value='' class="form-control" disabled value="-">
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllCategory()" id="btnCategory" style="padding-left: 10px;">. . .</button>
													</span>         
												</div>
											</div>
										</div>	
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemName">
												<input class="form-control" type="text" id="txtID" style="display:none;">
											</div>
										</div>	
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Capital Price<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCapitalPrice" onkeypress="return isNumber(event)" onkeyup="btozero(this);" maxlength="9" style="text-align:right;" value="0">
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Description:
											</label>
											<div class="col-md-8">
												<textarea type="text" class="form-control" id="txtDescription"></textarea>
											</div>
										</div>
									</div>
									<div class="col-md-6">										
										<div class="form-group row">
											<div class="col-md-8 col-form-label"></div>
											<div class="col-md-2 btnAdd">
												<button type="button" class="btn btn-success btn-block"onclick="createItem()" id="btnAdd">Create</button>	
											</div>
											<div class="col-md-2 btnEdit" style="display: none;">
												<button type="button" class="btn btn-danger btn-block" onclick="clearForm()">Cancel</button>
											</div>
											<div class="col-md-2 btnEdit" style="display: none;">
												<button type="button" class="btn btn-primary btn-block" onclick="createItem()">Update</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card card-outline card-primary">
							<div class="card-header">
								<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"></span></h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
									<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
								</div>
							</div>
							<div class="card-body p-0">
								<table class="table table-striped table-responsive table-bordered" id="myTable">
									<thead>                  
										<tr>
											<th style="width: 3%">No.</th>
											<th>Brand</th>	
											<th>Category</th>	
											<th>Name</th>							
											<th style="width: 12%">Capital Price</th>	
											<th>Description</th>								
											<th style="width: 3%">Edit</th> 
											<th style="width: 3%">Delete</th> 
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						</div>
					</form>
				</div>

				<div class="modal fade" id="myCategory" style="padding-right: 76px !important;">
					<div class="modal-dialog">
						<div class="modal-content" style="width: 130%;">
							<div class="modal-header">
								<h4 class="modal-title">Category - Entry<span id="total_records" style="font-weight:bold;"> </span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<section class="content">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-12">
											<div class="card card-outline card-primary">
												<div class="card-header">
													<h3 class="card-title">Entry</h3>
												</div>
												<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
													<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
												</div>
												<form role="form">
													<div class="card-body">
														<div class="row">
															<div class="col-md-12">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Category<span style="color: red; font-size: 20px;">*</span>:  </label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCategoryL">
																	</div>
																</div>
															</div>
															<div class="col-md-12">
																<div class="form-group row" style="margin-bottom: 0px;">
																	<div class="col-md-8"></div>
																	<div class="col-md-4">
																		<button type="button" class="btn btn-primary btn-block" onclick="createCategory()">Add</button>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</form>
											</div>
										</div>
										<div class="col-md-12">
											<div class="card card-outline card-primary">
												<div class="card-header">
													<h3 class="card-title">List<span id="total_records" style="font-weight:bold;"> </span></h3>
												</div>
												<div class="card-body table-responsive p-0" style="height: 270px;">
													<table class="table table-head-fixed" id="myTable1" style="cursor:pointer;">
														<thead>                  
															<tr>
																<th style="width: 3%">No.</th>
																<th>Category</th>
															</tr>
														</thead>
														<tbody>
														</tbody>
													</table>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>	
						</div>
					</div>
				</div>

				<div class="modal fade" id="myModalType" style="padding-right: 76px !important;">
					<div class="modal-dialog">
						<div class="modal-content" style="width: 130%;">
							<div class="modal-header">
								<h4 class="modal-title">Type - Entry<span id="total_records" style="font-weight:bold;"> </span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<section class="content">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-12">
											<div class="card card-outline card-primary">
												<div class="card-header">
													<h3 class="card-title">Entry</h3>
												</div>
												<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
													<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
												</div>
												<form role="form">
													<div class="card-body">
														<div class="row">
															<div class="col-md-12">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Brand<span style="color: red; font-size: 20px;">*</span>:  </label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtTypeL">
																	</div>
																</div>
															</div>
															<div class="col-md-12">
																<div class="form-group row" style="margin-bottom: 0px;">
																	<div class="col-md-8"></div>
																	<div class="col-md-4">
																		<button type="button" class="btn btn-primary btn-block" onclick="createType()">Add</button>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</form>
											</div>
										</div>
										<div class="col-md-12">
											<div class="card card-outline card-primary">
												<div class="card-header">
													<h3 class="card-title">List<span id="total_records" style="font-weight:bold;"> </span></h3>
												</div>
												<div class="card-body table-responsive p-0" style="height: 270px;">
													<table class="table table-head-fixed" id="myTable2" style="cursor:pointer;">
														<thead>                  
															<tr>
																<th style="width: 3%">No.</th>
																<th>Brand</th>
															</tr>
														</thead>
														<tbody>
														</tbody>
													</table>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>	
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
  	var n = d.getTime();

	$(function() {
		$("body").addClass("sidebar-collapse");
		getAllItem();
	});

	function getAllCategory(){
		$("#myCategory").modal('show');
		fillCategory();
	}

	function getAllType(){
		$("#myModalType").modal('show');
		fillType();
	}

	function fillCategory(){
		$("#myTable1").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/category/get_all_rows.php?t=" + n
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#myTable1").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i+1) + "</td>")
					.append("<td>" + v.category + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='delCategory(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
				);
			});
		});

		
		$('#myTable1').on('click', 'tbody tr td', function(e){
			$("#myCategory").modal('hide');
			$("#txtCategory").val($(this).parent().find("td").eq(1).text());
			if($("#txtCategory").val()!=""){
				getAllItem();
			}
		});

	}

	function fillType(){
		$("#myTable2").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/type/get_all_rows.php?t=" + n
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#myTable2").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i+1) + "</td>")
					.append("<td>" + v.type + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm' onclick='delBrand(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
				);
			});
		});

		
		$('#myTable2').on('click', 'tbody tr td', function(e){
			$("#myModalType").modal('hide');
			$("#txtType").val($(this).parent().find("td").eq(1).text());
			if($("#txtType").val()!=""){
				getAllItem();
			}
		});

	}

	function createItem(){	
		$("#loading").css("display","block");
		var id = $("#txtID").val();
		var type = $("#txtType").val();	
		var category = $("#txtCategory").val();	
		var item_name = $("#txtItemName").val();	
		var capital_price = parseInt($("#txtCapitalPrice").val().replace(/,/g, ''));
		var description = $("#txtDescription").val();	

		if(type==""){
			bootbox.alert("Please fill the type.");
			$("#loading").css("display","none");
			return false;
		}else if(category==""){
			bootbox.alert("Please fill the category.");
			$("#loading").css("display","none");
			return false;
		}else if(item_name==""){
			bootbox.alert("Please fill the item name.");
			$("#loading").css("display","none");
			return false;
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/item/create.php",
				type: "POST",
				data: JSON.stringify({ id: id, type: type, category: category, item_name: item_name, capital_price: capital_price, description: description }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					getAllItem();
					bootbox.confirm({
						message: "<h4>Item Successfully created. Do you want to make stock entry?</h4>",
						buttons: {
							confirm: {
								label: '<span class="glyphicon glyphicon-ok"></span> Yes',
								className: 'btn-danger'
							},
							cancel: {
								label: '<span class="glyphicon glyphicon-remove"></span> No',
								className: 'btn-primary'
							}
						},
						callback: function (result) {
							if(result){
								// var item_name=$("#txtItemName").val();
								window.location.href = APP_URL + "marketing/m_stock_in.php?act=edit&item_id=" + data.item_id;
							}else{
								$("#frmEntry")[0].reset();
							}
						}
					});
				}else if(data.message=="updated"){
					getAllItem();
					bootbox.confirm({
						message: "<h4>Item Successfully Updated. Do you want to make stock entry?</h4>",
						buttons: {
							confirm: {
								label: '<span class="glyphicon glyphicon-ok"></span> Yes',
								className: 'btn-danger'
							},
							cancel: {
								label: '<span class="glyphicon glyphicon-remove"></span> No',
								className: 'btn-primary'
							}
						},
						callback: function (result) {
							if(result){
								// var item_name=$("#txtItemName").val();
								window.location.href = APP_URL + "marketing/m_stock_in.php?act=edit&item_id=" + data.item_id;
							}else{
								$("#frmEntry")[0].reset();
							}
						}
					});
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate rows.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function getAllItem(){
		var type = $("#txtType").val();
		var category = $("#txtCategory").val();

		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/item/get_all_rows.php?",
			type: "POST",
			data: JSON.stringify({ type: type, category: category })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i+1) + "</td>")
					.append("<td>" + v.type + "</td>")
					.append("<td>" + v.category + "</td>")
					.append("<td>" + v.item_name + "</td>")
					.append("<td style='text-align:right;'>" + v.capital_price + "</td>")
					.append("<td>" + v.description + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-primary btn-sm fas' onclick='editItem(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'><i class='fas fa-edit' style='font-size: 17px;'></i></button></td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-danger btn-sm fas' onclick='delItem(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'>&times;</button></td>")
				);
			});
		});
	}

	function editItem(id, obj){
		$(".btnAdd").css("display", "none");
		$(".btnEdit").css("display", "block");
		$(".btnCancel").css("display", "block");
		$(".fas").attr("disabled", true);
		$(obj).attr("disabled", false);
		var tr = $(obj).parent().parent();
		$("#txtID").val(id);
		$("#txtType").val($(tr).find("td").eq(1).text());
		$("#txtCategory").val($(tr).find("td").eq(2).text());
		$("#txtItemName").val($(tr).find("td").eq(3).text());
		$("#txtCapitalPrice").val($(tr).find("td").eq(4).text().replace(/,/g, ''));
		$("#txtDescription").val($(tr).find("td").eq(5).text());
	}

	function clearForm(){
		$(".btnAdd").css("display", "block");
		$(".btnEdit").css("display", "none");
		$(".fas").attr("disabled", false);
		$("#txtID").val("");
		$("#txtType").val("");
		$("#txtCategory").val("");
		$("#txtItemName").val("");
		$("#txtCapitalPrice").val(0);
		$("#txtDescription").val("");
	}

	function createCategory(){	
		$("#loading").css("display","block");
		var category = $("#txtCategoryL").val();

		if(category==""){
			bootbox.alert("Please fill the box.");
			$("#loading").css("display","none");
			return false;
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/category/create.php",
				type: "POST",
				data: JSON.stringify({ category: category }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#txtCategoryL").val("");
					bootbox.alert("Successfully Added.");
					fillCategory();
					// $("#myCategory")[0].reset();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate rows.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function createType(){	
		$("#loading").css("display","block");
		var type = $("#txtTypeL").val();

		if(type==""){
			bootbox.alert("Please fill the box.");
			$("#loading").css("display","none");
			return false;
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/type/create.php",
				type: "POST",
				data: JSON.stringify({ type: type }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#txtTypeL").val("");
					bootbox.alert("Successfully Added.");
					fillType();
					// $("#myCategory")[0].reset();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate rows.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function delBrand(id, obj){
		bootbox.confirm({
			message: "<h4>Are you sure want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/marketing/type/delete.php",
						data: JSON.stringify({ id: id }),
					}).done(function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							fillType();
							$("#txtType").val("");
						}else{
							bootbox.alert("Error on server side.");
						}
					});
				}
			}
		});
	}

	function delItem(id, obj){
		bootbox.confirm({
			message: "<h4>Are you sure want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/marketing/item/delete.php",
						data: JSON.stringify({ id: id }),
					}).done(function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							getAllItem();
						}else{
							bootbox.alert("Error on server side.");
						}
					});
				}
			}
		});
	}

	function delCategory(id, obj){
		bootbox.confirm({
			message: "<h4>Are you sure want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/marketing/category/delete.php",
						data: JSON.stringify({ id: id }),
					}).done(function(data){
						if(data.message=="deleted"){
							$(obj).parent().parent().remove();
							fillCategory();
							$("#txtCategory").val("");
						}else{
							bootbox.alert("Error on server side.");
						}
					});
				}
			}
		});
	}
</script>
