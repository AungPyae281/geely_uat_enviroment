<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Pages - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtName" onkeypress="return isString(event)">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-7">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="height:450px; overflow-y: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 10%">No.</th>
										<th>Name</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() { 
		getAllRows();
	}); 
	
	function create(){	
		$("#loading").css("display","block");
		var name = $("#txtName").val();

		if(name==""){
			bootbox.alert("Please fill name.");
			$("#loading").css("display","none"); 
		}else{
			$.ajax({
				url: APP_URL + "api/marketing/pages/create.php",
				type: "POST",
				data: JSON.stringify({ name: name }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#frmEntry")[0].reset();
					bootbox.alert("Successfully Added.");
					getAllRows();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate name.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function getAllRows(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/pages/get_all_rows.php"
		}).done(function(data) {	
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			
			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i + 1) + "</td>")
					.append("<td>" + v.name + "</td>")
				);
			});
		});
	}
</script>	
