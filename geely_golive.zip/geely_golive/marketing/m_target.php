<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Pages Target - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Pages<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboPages"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Month From<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboMonthFrom">
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Month To<span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboMonthTo">
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Target Name<span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtName">
												<input class="form-control" type="text" id="txtID" style="display:none;">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Tgt. Like:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTLike" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Tgt. Reach:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTReach" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Tgt. Engagement:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTEngagement" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Tgt. Booking:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTBooking" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Tgt. Lead:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTLead" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-8"></div>
									<div class="col-md-4">
										<div class="form-group row">
											<div class="col-md-6"></div>
											<div class="col-md-3 btnAdd">
												<button type="button" class="btn btn-success btn-block"onclick="validateAndSave()" id="btnAdd">Create</button>	
											</div>
											<div class="col-md-3 btnEdit" style="display: none;">
												<button type="button" class="btn btn-danger btn-block" onclick="clearForm()">Cancel</button>
											</div>
											<div class="col-md-3 btnEdit" style="display: none;">
												<button type="button" class="btn btn-primary btn-block" onclick="validateAndSave()">Update</button>
											</div>
										</div> 
									</div>
								</div>
							</div>
						</form>
					</div>

					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"></span></h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div>
						</div>
						<div class="card-body p-0">
							<table class="table table-striped table-responsive table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Page Name</th>
										<th>Month From</th>
										<th>Month To</th>
										<th>Tgt. Name</th>
										<th>Tgt. Like</th>
										<th>Tgt. Reach</th>
										<th>Tgt. Engagement</th>
										<th>Tgt. Booking</th>
										<th>Tgt. Lead</th>
										<!-- <th>Delete</th> -->
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>
					
				</div>
			</div>		
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>

	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm);
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
		// $("body").addClass("sidebar-collapse");	
		
		fillMonth();
		fillPages();
		getAllRows();
	});	

	function fillMonth(){
		var today = new Date();
	    var fromMonth = new Date(today);
	    fromMonth.setMonth(today.getMonth() - 6); // Start from previous 6 months

	    var totMonth = new Date(today);
	    totMonth.setMonth(today.getMonth()); // Start from previous 6 months

	    var toMonth = new Date(today);
	    toMonth.setMonth(today.getMonth() + 50); // Up to next 50 months

	    for (var d = new Date(fromMonth); d <= toMonth; d.setMonth(d.getMonth() + 1)) {
	        var mm = d.getMonth() + 1;
	        var yyyy_mm = d.getFullYear() + "-" + ((mm < 10) ? "0" + mm : mm);

	        // Populate cboMonthFrom select
	        $("#cboMonthFrom").append("<option value='" + yyyy_mm + "'>" + yyyy_mm + "</option>");
	    }

	    for (var d = new Date(totMonth); d <= toMonth; d.setMonth(d.getMonth() + 1)) {
	        var mm = d.getMonth() + 1;
	        var yyyy_mm = d.getFullYear() + "-" + ((mm < 10) ? "0" + mm : mm);

	        // Populate cboMonthTo select
	        $("#cboMonthTo").append("<option value='" + yyyy_mm + "'>" + yyyy_mm + "</option>");
	    }
	}
 

	function fillPages(dp){
	   $("#cboPages").find("option").remove();
	   $("#cboPages").append("<option value = '' data-id = ''></option>");
	   $.ajax({
	      url: APP_URL + "api/marketing/pages/get_all_rows.php"
	   }).done(function(data) {   
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboPages").append("<option value= '" + v.name + "' data-id = '"+ v.id +"' selected>" + v.name + "</option>");
	         }else{
	            $("#cboPages").append("<option value= '" + v.name + "' data-id = '"+ v.id +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	function validateAndSave(){ 
		var id = $("#txtID").val();
		var page_id = $("#cboPages option:selected").attr('data-id');
		var name = $("#txtName").val();
		var month_from = $("#cboMonthFrom").val();
		var month_to = $("#cboMonthTo").val();
		var target_like = parseInt($("#txtTLike").val().replace(/,/g, ''));
		var target_reach = parseInt($("#txtTReach").val().replace(/,/g, ''));
		var target_engagement = parseInt($("#txtTEngagement").val().replace(/,/g, ''));
		var target_booking = parseInt($("#txtTBooking").val().replace(/,/g, ''));
		var target_lead = parseInt($("#txtTLead").val().replace(/,/g, ''));
		if(page_id==""){
	  		bootbox.alert("Please fill the page.");
	  	}else if(name==""){
	  		bootbox.alert("Please fill the target name.");
	  	}else if(month_from==""){
	  		bootbox.alert("Please fill the month from.");
	  	}else if(month_to==""){
	  		bootbox.alert("Please fill the month to.");
	  	}else{
			$.ajax({
				type: "POST",
				url: APP_URL + "api/marketing/target/create.php",
				data: JSON.stringify({ id: id, page_id: page_id, name: name, month_from: month_from, month_to: month_to, target_like: target_like, target_reach: target_reach, target_engagement: target_engagement, target_booking: target_booking, target_lead: target_lead }),
				success: function(data){
					if(data.message=="created"){
						bootbox.alert("New Target Created");
						getAllRows();
						$("#frmEntry")[0].reset();
					}else if(data.message=="updated"){
						bootbox.alert("Target Updated");
						getAllRows();
						$("#frmEntry")[0].reset();
					}else if(data.message=="duplicate"){
						bootbox.alert("Target Name already exist.");
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			});
	  	}  
	}	

	function getAllRows(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/marketing/target/get_all_rows.php"
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				if(data.records){$("#total_records").text(" - " + data.records.length + " record(s) found.");}else{$("#total_records").text(0 + " record(s) found.");}
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.page_name + "</td>")
					.append("<td>" + v.month_from + "</td>")
					.append("<td>" + v.month_to + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align:right;'>" + v.target_like + "</td>")
					.append("<td style='text-align:right;'>" + v.target_reach + "</td>")
					.append("<td style='text-align:right;'>" + v.target_engagement + "</td>")
					.append("<td style='text-align:right;'>" + v.target_booking + "</td>")
					.append("<td style='text-align:right;'>" + v.target_lead + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-block btn-primary btn-sm fas' onclick='editItem(" + v.id + ", this)' style='padding: 0px 10px;font-size: 20px; min-width: 35px'><i class='fas fa-edit' style='font-size: 17px;'></i></button></td>")
					// .append("<td style='text-align:center;'  ><button class='btn btn-danger btn-sm fas fas fa-trash-alt' style=' cursor:pointer;' id='a" + v.id + "'  onclick='del(\"" + v.id + "\",this)' ></button> </td>")
				);
			});
		});
	}

	function editItem(id, obj){
		$(".btnAdd").css("display", "none");
		$(".btnEdit").css("display", "block");
		$(".btnCancel").css("display", "block");
		$(".fas").attr("disabled", true);
		$(obj).attr("disabled", false);
		var tr = $(obj).parent().parent();
		$("#txtID").val(id);
		$("#cboPages").val($(tr).find("td").eq(1).text());
		$("#cboMonthTo").val($(tr).find("td").eq(3).text());
		$("#cboMonthFrom").val($(tr).find("td").eq(2).text());
		$("#txtName").val($(tr).find("td").eq(4).text());
		$("#txtTLike").val($(tr).find("td").eq(5).text().replace(/,/g, ''));
		$("#txtTReach").val($(tr).find("td").eq(6).text().replace(/,/g, ''));
		$("#txtTEngagement").val($(tr).find("td").eq(7).text().replace(/,/g, ''));
		$("#txtTBooking").val($(tr).find("td").eq(8).text().replace(/,/g, ''));
		$("#txtTLead").val($(tr).find("td").eq(9).text().replace(/,/g, ''));
	}

	function clearForm(){
		$(".btnAdd").css("display", "block");
		$(".btnEdit").css("display", "none");
		$(".fas").attr("disabled", false);
		$("#txtID").val("");
		$("#cboPages").val("");
		$("#cboMonthTo").val("");
		$("#cboMonthFrom").val("");
		$("#txtName").val("");
		$("#txtTLike").val(0);
		$("#txtTReach").val(0);
		$("#txtTEngagement").val(0);
		$("#txtTBooking").val(0);
		$("#txtTLead").val(0);
	}

	function del(id, obj){
        // bootbox for good looking 'confirm pop up'
        bootbox.confirm({
        	message: "<h4>Are you sure that you want to delete?</h4>",
        	buttons: {
        		confirm: {
        			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
        			className: 'btn-danger'
        		},
        		cancel: {
        			label: '<span class="glyphicon glyphicon-remove"></span> No',
        			className: 'btn-primary'
        		}
        	},
        	callback: function (result) {
        		if(result){
        			$.ajax({
        				type: "POST",
        				url: APP_URL + "api/marketing/target/delete.php",
        				data: JSON.stringify({ id: id }),
        				success: function(data){
        					if(data=="deleted"){
        						// $(obj).parent().parent().remove();
        						getAllRows();
        					}else{
        						bootbox.alert("Error on server side.");
        					}
        				}
        			});
        		}
        	}
        });
    }

	function btozero(obj){
		if($(obj).val() == "" || $(obj).val() == "0")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	} 

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
        $(obj).val(parseInt(amount).toLocaleString());
    }
</script>
