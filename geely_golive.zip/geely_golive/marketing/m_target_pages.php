<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Pages Actual- Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Month:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboMonth">
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Pages:</label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboPages"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4"></div>
								</div>
							</div>
						</form>
					</div>

					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"></span></h3>
							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
								<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
							</div>
						</div>
						<div class="card-body p-0">
							<table class="table table-striped table-responsive table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Month</th>
										<th>Page Name</th>
										<th>Like</th>
										<th>Reach</th>
										<th>Engagement</th>
										<th>Lead</th>
										<th>Booking</th>
									</tr>
								</thead>
								<tbody>
								</tbody>
							</table>
						</div>
					</div>
					
				</div>
			</div>		
		</div>

		<div class="modal fade modal-primary" id="myModalTargetEdit">
			<center>
				<div class="modal-dialog" style="max-width: 100% !important;">
					<div class="modal-content" style="width: 35%; top: 29px;">
						<div class="modal-header">
							<h4 class="modal-title" style="font-size: 18px !important;"><span id="mtxtTitle" style="font-weight:bold;"></span> - Entry </h4>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" style="padding-left: 0px padding-right: 0px;">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;"><span id="mLabel"></span></label>
										<div class="col-md-8">
											<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);" id="txtTarget" name="txtTarget" value="0" min="1" style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-8 col-form-label" style="text-align: right;"></label>
										<div class="col-md-4">
											<button type="button" class="btn btn-primary btn-block" onclick="updateTarget()">Update</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</center>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>

	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm);
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
		// $("body").addClass("sidebar-collapse");	
		// $("#cboMonth option[data-select='" + yyyy +"']").attr("selected","selected");
		
		fillMonth();
		fillPages();
		getAllTargetPage();
	});	

	function fillMonth(){
		for(var i = 0; i<17; i++){
			var d = new Date();
			d.setMonth(d.getMonth() -i);
			var mm = (d.getMonth("MM")+1);
			$("#cboMonth").append("<option value= '" + d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "'>" + d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "</option>");
		}
	} 

	function fillPages(dp){
	   $("#cboPages").find("option").remove();
	   $("#cboPages").append("<option value = '' data-code = ''></option>");
	   $.ajax({
	      url: APP_URL + "api/marketing/pages/get_all_rows.php"
	   }).done(function(data) {   
	      $.each(data.records, function(i, v) {  
	         if(v.name==dp){
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' selected>" + v.name + "</option>");
	         }else{
	            $("#cboPages").append("<option value= '" + v.name + "' data-code = '"+ v.id +"' >" + v.name + "</option>");
	         }
	      });
	   });
	}

	$('#cboMonth').on('change', function() {
        getAllTargetPage();
    });

    $('#cboPages').on('change', function() {
        getAllTargetPage();
    });

	function getAllTargetPage(){
		$("#loading").css("display", "block");
		var month = $("#cboMonth").val();
		var page_name = $("#cboPages").val();
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/marketing/target_pages/get_all_rows.php",
			data: JSON.stringify({ month: month, page_name: page_name})
		}).done(function(data) {
			$("#loading").css("display", "none");
			$.each(data.records, function(i, v) {
				console.log(v);
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.month + "</td>")
					.append("<td>" + v.page_name + "</td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:red;text-decoration:underline;' onclick='editTargetPages(\"" + v.month + "\", \"" + v.page_id + "\", \"" + v.p_like + "\", this)' data-name='p_like'>" + v.p_like + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:red;text-decoration:underline;' onclick='editTargetPages(\"" + v.month + "\", \"" + v.page_id + "\", \"" + v.p_reach + "\", this)' data-name='p_reach'>" + v.p_reach + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:red;text-decoration:underline;' onclick='editTargetPages(\"" + v.month + "\", \"" + v.page_id + "\", \"" + v.p_engagement + "\", this)' data-name='p_engagement'>" + v.p_engagement + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:red;text-decoration:underline;' onclick='editTargetPages(\"" + v.month + "\", \"" + v.page_id + "\", \"" + v.p_lead + "\", this)' data-name='p_lead'>" + v.p_lead + "</a></td>")
					.append("<td  style='text-align:right;'><a style='cursor:pointer;color:red;text-decoration:underline;' onclick='editTargetPages(\"" + v.month + "\", \"" + v.page_id + "\", \"" + v.p_booking + "\", this)' data-name='p_booking'>" + v.p_booking + "</a></td>")
			  	);
			});
		});
	}

	var PID="";
	var amount = 0;
	var MTh = "";
	var col_name = "";

	function editTargetPages(month, page_id, amount, obj){
		$("#myModalTargetEdit").modal('show');
		PID = page_id;
		MTh = month;
		col_name = $(obj).attr("data-name");
		var lab_name = '';
		if(col_name=='p_like'){
			lab_name = 'Like';
		}else if(col_name=='p_reach'){
			lab_name = 'Reach';
		}else if(col_name=='p_engagement'){
			lab_name = 'Engagement';
		}else if(col_name=='p_lead'){
			lab_name = 'Lead';
		}else{
			lab_name = 'Booking';
		}

		$("#mLabel").text(lab_name);
		$("#mtxtTitle").text(lab_name);
		$("#txtTarget").val(amount.replace(/,/g, ''));
	}

	function updateTarget(){ 
		var amount = parseInt($("#txtTarget").val().replace(/,/g, ''));
		// if(amount==0){
	 //  		bootbox.alert("Please fill the target sales.");
	 //  	}else{
		$.ajax({
			type: "POST",
			url: APP_URL + "api/marketing/target_pages/update.php",
			data: JSON.stringify({ page_id: PID, month: MTh, amount: amount, col_name: col_name }),
			success: function(data){
				if(data=="updated"){
				$("#myModalTargetEdit").modal('hide');
					getAllTargetPage();
				}else{
					bootbox.alert("Error on server side.");
				}
			}

		});
	  	// }  
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}
</script>
